<?
/* 
 * @author  Daniel Toma <dt@dnt.ro>
 * @version $Id$ 
 */ 
?>

<HTML>
<HEAD>
  <TITLE>splash</TITLE>
  <link rel="stylesheet" href="main.css">
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
</HEAD>
<BODY BGCOLOR="#EEEEEE" link="#111111"  alink="#111111"  vlink="#111111">
<table summary="" border=0 width=100% height=100%>
<tr><td align=center valign=middle>
				<a href="choise.php">
				<IMG SRC="img/splash.gif" WIDTH=400 HEIGHT=400 border=1>
				</a>
</td></tr>
</table>
</BODY>
</HTML>