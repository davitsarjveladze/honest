#!/bin/bash
mysql < create_db_mysql.sql
