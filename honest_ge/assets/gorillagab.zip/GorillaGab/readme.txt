<!--/***************** DO NOT REMOVE! *********************/---->
<!--/*   Script : gboard.cgi  Date : 12/15/2000                                                */---->
<!--/*   kmoo@k-moo.com     All Rights Reserved ...                                    */---->
<!--/*   http://www.10tons.com/                                                                     */---->
<!--/********************************************************/---->
Please leave the link on the program.

This set of small scripts is very easy to set up.
   What you should have is :
           1: gorilla.php3              permission...755
           2:gorilla2.php3             permission..755
           3:gorilla_main.php3      permission..755
           4:kmoo.gif                    permission..755
           5:blank.gif                     permission..755
           6:msg.txt                       permission..777

Open gorilla.php3.
there are several lines that need to be changed.

/*Dat file name. Make sure it is in the same folder*/
$talk_back_ok = "msg.txt";
/*Webmasters Image Location(put url not path)*/
$webmaster_image = "kmoo.gif";
/*Webmasters Name*/
$webmaster_name = "kmoo";
/*Webmasters Password*/
$pass = "061667";
/*messages displayed*/
$help_lenght = 20;
/*Home Long can the lake each message*/
$max_single_msg_lenght = 100000;


Once these are change the priogram is ready to go.
Now for linking to it what I would do is use this link below.
That way you control how it looks and so on. 
============Linking=================
<a href="location of gorilla_main.php3" target="view" onclick="open('location of gorilla_main.php3','view','height=475,width=300,scrollbars')">Gorilla Gab</a>
============Linking=================
There are a lot of things to do to it and I will add themto it. So please check back for any new version.
If you have any question send me and email at kmoo@k-moo.com








