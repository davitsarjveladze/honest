<?//-*- C++ -*-
/*   ********************************************************************   **
**   Copyright (C) 1995-2000 Michael Oertel                                 **
**   Copyright (C) 2000-     PHPOpenChat Development Team                   **
**   http://www.ortelius.de/phpopenchat/                                    **
**                                                                          **
**   This program is free software. You can redistribute it and/or modify   **
**   it under the terms of the PHPOpenChat License Version 1.0              **
**                                                                          **
**   This program is distributed in the hope that it will be useful,        **
**   but WITHOUT ANY WARRANTY, without even the implied warranty of         **
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   **
**                                                                          **
**   You should have received a copy of the PHPOpenChat License             **
**   along with this program.                                               **
**   ********************************************************************   */

/* 
 * Include some default values
 */
include("defaults_inc.php");

?>
<HTML>
<HEAD>
<TITLE><?echo $CHATNAME?></TITLE>
<META NAME="distribution" CONTENT="global">
<META NAME="author" CONTENT="Andre Leitenberger; andre.leitenberger@gmx.net">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
td { font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #ffffff; }
a:link { text-decoration: none; }
a:active { text-decoration: none; }
a:visited { text-decoration: none; }
a:hover { text-decoration: underline; }
-->
</style>
</HEAD>
<BODY bgcolor="#000000" link="#ffffff" alink="#ffffff" vlink="#ffffff" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td height="25" colspan="2" bgcolor="#000000" align="center">
      <span style="color:#000000;font-weight:bold;font-size:12px;vertical-align:middle;">
      <?
      echo '<a href="windows.php?menu=userprofile" target="main">'.$MY_PROFILE.'</a>&nbsp;&nbsp;&nbsp;';
      if(check_permissions($nick,$pruef)){
        echo '<a href="windows.php?menu=chatmail" target="main">'.$CHATMAIL.'</a>&nbsp;&nbsp;&nbsp;';
        echo '<a href="windows.php?menu=invite" target="main">'.$IGNORE_INVITE.'</a>&nbsp;&nbsp;&nbsp;';
        echo '<a href="windows.php?menu=friends" target="main">'.$NOTIFY.'</a>&nbsp;&nbsp;&nbsp;';
      }
      echo '<a href="windows.php?menu=toplist" target="main">'.$TOPLIST.'</a>&nbsp;&nbsp;&nbsp;';
      if(check_permissions($nick,$pruef)){
        echo '<a href="windows.php?menu=whoisonline" target="main">'.$WHOISONLINE.'</a>&nbsp;&nbsp;&nbsp;';
        echo '<a href="windows.php?menu=forum" target="main">'.$FORUM[title].'</a>&nbsp;&nbsp;&nbsp;';
      }
      echo '<a href="windows.php?menu=help" target="main">'.$HELP.'</a>&nbsp;&nbsp;&nbsp;';
      if(!check_permissions($nick,$pruef)){
        echo '<a href="windows.php?menu=forgotpwd" target="main">'.$FORGOTPWD.'</a>';
      }
      ?>
      </span>
    </td>
  </tr>
</table>
</BODY>
</HTML>

