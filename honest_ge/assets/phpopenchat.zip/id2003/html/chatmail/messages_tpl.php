<html>
<head>
<title><?echo $CHATMAIL?></title>
</head>
<body bgcolor="#F4F4F4" TEXT="#000000" LINK="#007b39" VLINK="#007b39" ALINK="#007b39" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="700" height="100%" align="center" cellspacing="0" cellpadding="5" border="0">
<tr><td align="center" valign="top">
<font face="arial, helvetica, sans-serif" size="2">[ <?echo $inbox_link?><b><?echo $INBOX?></b></a> | <?echo $write_mail_link?><b><?echo $WRITE_MAIL?></b></a> | <?echo $sent_mail_link?><b><?echo $SENT_MAIL?></b></a> ]</font><br>
<HR><br>
<FORM ACTION="chatmail_writemail.<?echo$FILE_EXTENSION?>" METHOD="POST">
<INPUT TYPE="hidden" NAME="nick" VALUE="<?echo$nick?>">
<INPUT TYPE="hidden" NAME="pruef" VALUE="<?echo$pruef?>">
<INPUT TYPE="hidden" NAME="<?=session_name()?>" VALUE="<?=session_id()?>">
<font face="arial, helvetica, sans-serif" size="2"><?echo $select_msg_to?></font>
<?echo $show_subjects?>
<?echo $content?>
</td></tr>
<tr><td align="center" valign="bottom">
<HR>
<font face="arial, helvetica, sans-serif" size="2">[ <?echo $inbox_link?><b><?echo $INBOX?></b></a> | <?echo $write_mail_link?><b><?echo $WRITE_MAIL?></b></a> | <?echo $sent_mail_link?><b><?echo $SENT_MAIL?></b></a> ]</font>
</td></tr></table>
</BODY>
</HTML>
