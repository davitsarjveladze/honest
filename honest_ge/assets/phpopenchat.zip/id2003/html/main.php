<?//-*- C++ -*-
/*   ********************************************************************   **
**   Copyright (C) 1995-2000 Michael Oertel                                 **
**   Copyright (C) 2000-     PHPOpenChat Development Team                   **
**   http://www.ortelius.de/phpopenchat/                                    **
**                                                                          **
**   This program is free software. You can redistribute it and/or modify   **
**   it under the terms of the PHPOpenChat License Version 1.0              **
**                                                                          **
**   This program is distributed in the hope that it will be useful,        **
**   but WITHOUT ANY WARRANTY, without even the implied warranty of         **
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   **
**                                                                          **
**   You should have received a copy of the PHPOpenChat License             **
**   along with this program.                                               **
**   ********************************************************************   */

/* 
 * Include some default values
 */
include("defaults_inc.php");

/*
 * Open a database connection
 * The following include returns a database handle
 */
include ("connect_db_inc.php");
$db_handle=connect_db($DATABASEHOST,$DATABASEUSER,$DATABASEPASSWD);
if(!$db_handle){
  exit;
}
?>
<HTML>
<HEAD>
<TITLE><?echo $CHATNAME?></TITLE>
<META NAME="distribution" CONTENT="global">
<META NAME="author" CONTENT="Andre Leitenberger; andre.leitenberger@gmx.net">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
td { font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #ffffff; }
-->
</style>
</HEAD>
<frameset rows="*,25" border="0" frameborder="0" framespacing="0">
  <frame name="main" src="windows.php?menu=<?echo $menu?>" scrolling="no" noresize>
  <frame name="navigation" src="navigation.php?menu=<?echo $menu?>" scrolling="no" noresize>
</frameset>
</HTML>

