<?//-*- C++ -*-
/*   ********************************************************************   **
**   Copyright (C) 1995-2000 Michael Oertel                                 **
**   Copyright (C) 2000-     PHPOpenChat Development Team                   **
**   http://www.ortelius.de/phpopenchat/                                    **
**                                                                          **
**   This program is free software. You can redistribute it and/or modify   **
**   it under the terms of the PHPOpenChat License Version 1.0              **
**                                                                          **
**   This program is distributed in the hope that it will be useful,        **
**   but WITHOUT ANY WARRANTY, without even the implied warranty of         **
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   **
**                                                                          **
**   You should have received a copy of the PHPOpenChat License             **
**   along with this program.                                               **
**   ********************************************************************   */

/* 
 * Include some default values
 */
include("defaults_inc.php");

/*
 * Open a database connection
 * The following include returns a database handle
 */
include ("connect_db_inc.php");
$db_handle=connect_db($DATABASEHOST,$DATABASEUSER,$DATABASEPASSWD);
if(!$db_handle){
  exit;
}
?>
<HTML>
<HEAD>
<TITLE><?echo $CHATNAME?></TITLE>
<META NAME="distribution" CONTENT="global">
<META NAME="author" CONTENT="Andre Leitenberger; andre.leitenberger@gmx.net">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
td { font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #ffffff; }
-->
</style>
</HEAD>
<frameset rows="55,*" border="0" frameborder="0" framespacing="0">
  <frame name="maininfo" src="main_info.php?menu=<?echo $menu?>" scrolling="no" noresize>
  <?
  if($menu=="register"){
    echo '<frame name="plugin" src="register.php" scrolling="auto" noresize>';
  }
  if($menu=="userprofile"){
    echo '<frame name="plugin" src="user_profile.php" scrolling="auto" noresize>';
  }
  if($menu=="chatmail"){
    echo '<frame name="plugin" src="chatmail/chatmail_inbox.php" scrolling="auto" noresize>';
  }
  if($menu=="invite"){
    echo '<frame name="plugin" src="invite.php" scrolling="auto" noresize>';
  }
  if($menu=="friends"){
    echo '<frame name="plugin" src="friends.php?action=list" scrolling="auto" noresize>';
  }
  if($menu=="toplist"){
    echo '<frame name="plugin" src="toplist.php" scrolling="auto" noresize>';
  }
  if($menu=="whoisonline"){
    echo '<frame name="plugin" src="whoisonline.php" scrolling="auto" noresize>';
  }
  if($menu=="forum"){
    echo '<frame name="plugin" src="forum/forum.php" scrolling="auto" noresize>';
  }
  if($menu=="help"){
    echo '<frame name="plugin" src="help.php" scrolling="auto" noresize>';
  }
  if($menu=="forgotpwd"){
    echo '<frame name="plugin" src="sendpwd.php" scrolling="auto" noresize>';
  }
  ?>
</frameset>
</HTML>

