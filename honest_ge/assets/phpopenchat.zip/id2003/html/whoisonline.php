<?//-*- C++ -*-
/*   ********************************************************************   **
**   Copyright (C) 1995-2000 Michael Oertel                                 **
**   Copyright (C) 2000-     PHPOpenChat Development Team                   **
**   http://www.ortelius.de/phpopenchat/                                    **
**                                                                          **
**   This program is free software. You can redistribute it and/or modify   **
**   it under the terms of the PHPOpenChat License Version 1.0              **
**                                                                          **
**   This program is distributed in the hope that it will be useful,        **
**   but WITHOUT ANY WARRANTY, without even the implied warranty of         **
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   **
**                                                                          **
**   You should have received a copy of the PHPOpenChat License             **
**   along with this program.                                               **
**   ********************************************************************   */

/* 
 * Include some default values
 */
include("defaults_inc.php");

/**
 * Check for access permissions of this page
 *
 * compare the given and the calculated checksum,
 * if they don't match the user has no permissions
 * and the script ends by printing a status header of 204
 * (no content change by client browser)
 */
if(!check_permissions($nick,$pruef)){
  //the user has no access permission for this page
  header("Status: 204 OK");//browser don't refresh his content
  exit;
}

/*
 * Open a database connection
 * The following include returns a database handle
 */
include ("connect_db_inc.php");
$db_handle=connect_db($DATABASEHOST,$DATABASEUSER,$DATABASEPASSWD);
if(!$db_handle){
  exit;
}
?>
<HTML>
<HEAD>
<TITLE><?echo $CHATNAME?></TITLE>
<META NAME="distribution" CONTENT="global">
<META NAME="author" CONTENT="Andre Leitenberger; andre.leitenberger@gmx.net">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
td { font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #ffffff; }
a:hover { text-decoration: none; }
-->
</style>
<script language="JavaScript" type="text/javascript">
<!--
function OpenUserpage(file) {
  var newWindow;
  newWindow=window.open(file,"userpage","scrollbars=yes,directories=no,width=640,height=480")
  if (newWindow != null && newWindow.opener == null)
    newWindow.opener=window
}
// -->
</script>
</HEAD>
<BODY bgcolor="#284628" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" cellspacing="0" cellpadding="5" border="0">
  <tr>
    <td align="center">
      <TABLE width="500" border="0" cellspacing="0" cellpadding="1">
	<?
	$channelresult = mysql_query("SELECT count(*) as count, Raum FROM chat GROUP BY Raum ORDER BY count desc",$db_handle);
	while($row = mysql_fetch_object($channelresult)){
		$i=0;
		$raum = $row->Raum;
		$chatterinroom = mysql_query("SELECT Nick FROM chat WHERE Raum='$raum' ORDER BY Nick");
		echo '<TR><TD width="125"><br><strong>'.$raum.':</strong></TD><TD width="125"></TD><TD width="125"></TD><TD width="125"></TD></TR>';
		echo '<TR><TD colspan="4"><HR></TD>';
		while($nickrow = mysql_fetch_object($chatterinroom)){
			if($i % 4 ==0){echo '</TR><TR>';}
			$shownick=$nickrow->Nick;
			$nick_color = @mysql_result(mysql_query("SELECT color FROM chat_data WHERE Nick='$shownick'",$db_handle),0,"color");
			if($nick_color==''){$nick_color = '#e1e1e1';}
			if($ENABLE_USERPAGES){
			  echo '<td><a href="javascript:OpenUserpage(\'userpage.php?'.session_name().'='.session_id().'&user='.urlencode($shownick).'\')"><FONT COLOR="'.$nick_color.'">';
			  echo str_replace(" ","&nbsp;",$shownick);
			  echo '</font></a></td>';
			}else{
			  echo '<td><FONT COLOR="'.$nick_color.'">'.str_replace(" ","&nbsp;",$shownick).'</font></td>';
			}
			$i++;
		}
		if($i % 4 != 0){
        		echo '</tr>';
        	}
		echo '</TD></TR>';
	}
echo '</TABLE>';
mysql_close($db_handle);
?>
</td>
</tr>
</table>
</BODY>
</HTML>
