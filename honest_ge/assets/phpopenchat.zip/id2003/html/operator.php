<? // -*- C++ -*-
/*   ********************************************************************   **
**   Copyright (C) 1995-2000 Michael Oertel                                 **
**   Copyright (C) 2000-     PHPOpenChat Development Team                   **
**   http://www.ortelius.de/phpopenchat/                                    **
**                                                                          **
**   This program is free software. You can redistribute it and/or modify   **
**   it under the terms of the PHPOpenChat License Version 1.0              **
**                                                                          **
**   This program is distributed in the hope that it will be useful,        **
**   but WITHOUT ANY WARRANTY, without even the implied warranty of         **
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   **
**                                                                          **
**   You should have received a copy of the PHPOpenChat License             **
**   along with this program.                                               **
**   ********************************************************************   */


/**
 * Include default values
 */
include "defaults_inc.php";

//start session
if($ENABLE_SESSION){
  @session_start();
}

/**
 * Check for access permissions of this page
 *
 * compare the given and the calculated checksum,
 * if they don't match the user has no permissions
 * and the script ends by printing a status header of 204
 * (no content change by client browser)
 */
if(!check_permissions($nick,$pruef)){
  //the user has no access permission for this page
  header("Status: 204 OK\r\n");//browser don't refresh his content
  exit;
}

/**
 * Open a database connection
 *
 * This include returns a database identifier '$db_handle'
 * used by some database querys.
 */
include ("connect_db_inc.php");
$db_handle=connect_db($DATABASEHOST,$DATABASEUSER,$DATABASEPASSWD);
if(!$db_handle){
  exit;
}

$result=mysql_query("SELECT count(*) AS count FROM paten WHERE Nick = '$nick'",$db_handle);
$pate=mysql_result($result,0,"count");
if(!$pate){
  exit;
}
mysql_free_result($result);

// Function to input a text line in the database
include "write_line_inc.php";

if($ENABLE_SESSION){
  $permissions = '<INPUT TYPE="hidden" NAME="'.session_name().'" VALUE="'.session_id().'">';
}else{
  $permissions = '<INPUT TYPE="hidden" NAME="nick" VALUE="'.$nick.'"><INPUT TYPE="hidden" NAME="pruef" VALUE="'.$pruef.'">';
}

// ------------------------------------

// read out the button-variables for the action-switch
if ($op_info) { $action="info"; }
if ($op_kick) { $action="kick"; }

switch ($action)
{
  case "info":

      if ($chatter)
      {
        $result = mysql_query("select Email from chat_data where Nick = '$chatter'",$db_handle);
        $email = mysql_result($result,0,"Email");

        $result = mysql_query("SELECT max(kicked) as kicked FROM chat_data WHERE Email ='$email'",$db_handle);
        $a = '';
        $a = mysql_fetch_array($result);
        $kicked = $a['kicked'];
        $info_nextkicktime = $KICKTIME * pow(3,$kicked);

        $MSG_OP_INFOTEXT  = "$MSG_OP_INFOTEXT_INFOABOUT <b>$chatter</b><br><br>";
        $MSG_OP_INFOTEXT .= "$MSG_OP_INFOTEXT_KICKSSOFAR $kicked<br><br>";
        $MSG_OP_INFOTEXT .= "$MSG_OP_INFOTEXT_NEXTKICKTIME $info_nextkicktime";
      }
      else
      {
        $MSG_OP_INFOTEXT = $MSG_OP_INFOTEXT_GENERAL;
      }

    break;

  case "kick":

    if ($chatter)
    {
      $result=mysql_query("SELECT count(*) AS count FROM paten WHERE Nick = '$chatter'",$db_handle);
      $patencheck=mysql_result($result,0,"count");
      if($patencheck==0)
      {

        // check if another operator has already kicked the user to deny double kicks
        $result=mysql_query("SELECT User_busy FROM chat WHERE Nick='$chatter'",$db_handle);
        $temp = mysql_fetch_array($result);
        $chatter_status = $temp["User_busy"];

        if ( ! $chatter_status == 2)
        {
          $result = mysql_query("select Email from chat_data where Nick = '$chatter'",$db_handle);
          $email = mysql_result($result,0,"Email");
          $result = mysql_query("SELECT max(kicked) as kicked FROM chat_data WHERE Email ='$email'",$db_handle);
          $a = '';
          $a = mysql_fetch_array($result);
          $kicked = $a['kicked']+1;
          $result=mysql_query("UPDATE chat SET User_busy=2 WHERE Nick='$chatter'",$db_handle);

          if ($permanent) { $kicked=20; }
          $result=mysql_query("UPDATE chat_data SET kicked = $kicked, last_kicktime=unix_timestamp() WHERE Nick='$chatter'",$db_handle);

          $channel=mysql_result(mysql_query("SELECT Raum FROM chat WHERE Nick='$chatter'",$db_handle),0,"Raum");
          schreib_zeile("<!-- ||0|0|0|--><b><font color=#88EFEF>$MODERATOR_NAME:</font></b> <STRONG>$chatter</STRONG> <EM>$KICKED</EM>!",$channel);

          $info_kicktime = $KICKTIME * pow(3,$kicked-1);

          $MSG_OP_INFOTEXT  = "$chatter $MSG_OP_INFOTEXT_KICKED<br><br>";
          $MSG_OP_INFOTEXT .= "$MSG_OP_INFOTEXT_KICKCOUNT $kicked<br><br>";
          $MSG_OP_INFOTEXT .= "$MSG_OP_INFOTEXT_KICKTIME $info_kicktime";

        }
        else
        {
          $MSG_OP_INFOTEXT = "$chatter $MSG_OP_INFOTEXT_ALREADYKICKED";
        }
      }
    }
    else
    {
        $MSG_OP_INFOTEXT = $MSG_OP_INFOTEXT_GENERAL;
    }

    break;

    default:
      $MSG_OP_INFOTEXT = $MSG_OP_INFOTEXT_GENERAL;
      break;
}

    // fill the chatterlist with nicknames of the current users in the chat.
    // Chatters who are already kicked out are not showed in the list any more.
    $nick_result=mysql_query("SELECT Nick FROM chat WHERE USER_BUSY <> 2 ORDER BY Nick",$db_handle);
    $select_of_all_chatters = "<SELECT SIZE=\"12\" class=\"chatterlist\" NAME=\"chatter\">";

    while($i=mysql_fetch_array($nick_result))
    {
      $temp=$i["Nick"];

      $operator_result=mysql_query("SELECT count(*) AS count FROM paten WHERE Nick = '$temp'",$db_handle);
      $patencheck=mysql_result($operator_result,0,"count");

      if($patencheck==0)
      {
          $select_of_all_chatters .= "<OPTION VALUE=\"";
          $select_of_all_chatters .= $i["Nick"];
          $select_of_all_chatters .= "\">";
          $select_of_all_chatters .= $i["Nick"];
          $select_of_all_chatters .= "</OPTION>";
      }
    }
    $select_of_all_chatters .= "</SELECT>";

    $result=mysql_query("SELECT Allow FROM channels WHERE Name = '$nick'",$db_handle);
    if(mysql_num_rows($result)>0){$kick = mysql_result($result,0,"Allow");}

    $result=mysql_query("SELECT Allow FROM channels WHERE Name='$nick'",$db_handle);
    if(mysql_num_rows($result)>0){ $tmp=mysql_result($result,0,"Allow"); }

    mysql_free_result($result);
    mysql_close($db_handle);


// include template file
include('operator_tpl.'.$FILE_EXTENSION);

?>