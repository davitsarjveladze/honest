<?//-*- C++ -*-
/*   ********************************************************************   **
**   Copyright (C) 2000-     PHPOpenChat Development Team                   **
**   http://www.ortelius.de/phpopenchat/                                    **
**                                                                          **
**   This program is free software. You can redistribute it and/or modify   **
**   it under the terms of the PHPOpenChat License Version 1.0              **
**                                                                          **
**   This program is distributed in the hope that it will be useful,        **
**   but WITHOUT ANY WARRANTY, without even the implied warranty of         **
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   **
**                                                                          **
**   You should have received a copy of the PHPOpenChat License             **
**   along with this program.                                               **
**   ********************************************************************   */
/* 
 * Include some default values
 */
include ('defaults_inc.php');

if(!check_permissions($nick,$pruef)){
	echo ':-p';
	exit;
}

 /**
 * Open a database connection
 *
 * This include returns a database identifier '$db_handle'
 * used by some database querys.
 */
include ("connect_db_inc.php");
$db_handle=connect_db($DATABASEHOST,$DATABASEUSER,$DATABASEPASSWD);
if(!$db_handle){
  exit;
}

if($ENABLE_SESSION){
  $exit_link = "input.$FILE_EXTENSION?Exit=1&amp;".session_name()."=".session_id();
}else{
  $exit_link = "input.$FILE_EXTENSION?Exit=1&amp;Nick=$nickcode&amp;pruef=$pruef";
}
if($BUTTON_HELP){
  $help_button = nl.tab.tab.tab.'<a href="#" NAME="OpenWin" onClick="OpenMainMenu(\'main.'.$FILE_EXTENSION.'?menu=help\')">'.$HELP.'</a>';
}else{
  $help_button = '';
}
if($pruef && $BUTTON_FORUM){
  if($ENABLE_SESSION){
    $forum_button = nl.tab.tab.tab.'<a href
	="#" NAME="OpenWin" onClick="OpenMainMenu(\'main.'.$FILE_EXTENSION.'?menu=forum&'.session_name().'='.session_id().'\')">'.$FORUM[title].'</a>';
  }else{
    $forum_button = nl.tab.tab.tab.tab.'<a href="#" NAME="OpenWin" onClick="OpenMainMenu(\'main.'.$FILE_EXTENSION.'?menu=forum&nick='.$nickcode.'&pruef='.$pruef.'\')">'.$FORUM[title].'</a>';
  }
}else{
  $forum_button = '';
}   
if($BUTTON_MESSAGES){
  if($ENABLE_SESSION){
    $messages_button = '<a href="#" NAME="OpenWin" onClick="OpenMainMenu(\'main.'.$FILE_EXTENSION.'?menu=chatmail&'.session_name().'='.session_id().'\')">'.$CHATMAIL.'</a>';
  }else{
    $messages_button = '<a href="#" NAME="OpenWin" onClick="OpenMainMenu(\'main.'.$FILE_EXTENSION.'?menu=chatmail&nick='.$nickcode.'&pruef='.$pruef.'\')">'.$CHATMAIL.'</a>';
  }
}
if($BUTTON_IGNORE){
  if($ENABLE_SESSION){
    $ignore_invite_button = '<a href="#" NAME="OpenWin" onClick="OpenMainMenu(\'main.'.$FILE_EXTENSION.'?menu=invite&'.session_name().'='.session_id().'\')">'.$IGNORE_INVITE.'</a>';
  }else{
    $ignore_invite_button = '<a href="#" NAME="OpenWin" onClick="OpenMainMenu(\'main.'.$FILE_EXTENSION.'?menu=invite&nick='.$nickcode.'&pruef='.$pruef.'\')">'.$IGNORE_INVITE.'</a>';
  }
}
if($BUTTON_NOTIFY){
  if($ENABLE_SESSION){
    $button_notify      = '<a href="#" NAME="OpenWin" onClick="OpenMainMenu(\'main.'.$FILE_EXTENSION.'?menu=friends&action=list&'.session_name().'='.session_id().'\')">'.$NOTIFY.'</a>';
  }else{
    $button_notify      = '<a href"#"  NAME="OpenWin" onClick="OpenMainMenu(\'main.'.$FILE_EXTENSION.'?menu=friends&action=list&nick='.$nickcode.'&pruef='.$pruef.'\')">'.$NOTIFY.'</a>';
  }
}
if($BUTTON_WHOISONLINE){
  if($ENABLE_SESSION){
    $button_whoisonline      = '<a href="#" NAME="OpenWin" onClick="OpenMainMenu(\'main.'.$FILE_EXTENSION.'?menu=whoisonline&'.session_name().'='.session_id().'\')">'.$WHOISONLINE.'</a>';
  }else{
    $button_whoisonline      = '<a href="#" NAME="OpenWin" onClick="OpenMainMenu(\'main.'.$FILE_EXTENSION.'?menu=whoisonline&nick='.$nickcode.'&pruef='.$pruef.'\')">'.$WHOISONLINE.'</a>';
  }
}

$result=mysql_query("SELECT count(*) AS count FROM paten WHERE Nick = '$nick'",$db_handle);
$pate=mysql_result($result,0,"count");
if($pate)
  {
    if($BUTTON_OPERATOR){
      if($ENABLE_SESSION){
        $button_operator      = '<a href="#" NAME="OpenWin" onClick="OpenMainMenu(\'operator.'.$FILE_EXTENSION.'?'.session_name().'='.session_id().'\')">'.$MSG_OP_TITLE.'</a>';
      }else{
        $button_operator      = '<a href="#" NAME="OpenWin" onClick="OpenMainMenu(\'operator.'.$FILE_EXTENSION.'?nick='.$nickcode.'&pruef='.$pruef.'\')">'.$MSG_OP_TITLE.'</a>';
      }
  }
}
if($CHANGE_SCROLLING){
  if($scroll=="0"){$scroll_off_status = 'SELECTED';}
  if($scroll=="1"){$scroll_on_status1  = 'SELECTED';}
  if($scroll=="2"){$scroll_on_status2  = 'SELECTED';}
  if($scroll=="3"){$scroll_on_status3  = 'SELECTED';}
  $switch_auto_scrolling   = $AUTOSCROLLING.'<BR>';
  $switch_auto_scrolling  .= '<SELECT Id="scroll" NAME="scroll" ';
  $switch_auto_scrolling  .= ' onChange="scroll_me();"';
  $switch_auto_scrolling  .= '>';
  $switch_auto_scrolling  .= '<OPTION VALUE=1 '.$scroll_on_status1.'>'.$ON.'</OPTION>';
  $switch_auto_scrolling  .= '<OPTION VALUE=2 '.$scroll_on_status2.'>'.$ON1.'</OPTION>';
  $switch_auto_scrolling  .= '<OPTION VALUE=3 '.$scroll_on_status3.'>'.$ON2.'</OPTION>';
  $switch_auto_scrolling  .= '<OPTION VALUE=0 '.$scroll_off_status.'>'.$OFF.'</OPTION>';
  $switch_auto_scrolling  .= '</SELECT>';
  $switch_auto_scrolling  .= nl.'<SCRIPT LANGUAGE="javascript" TYPE="text/javascript">scroll_me();</SCRIPT>'.nl;
}else{
  $switch_auto_scrolling   = '<input name="scroll" type="hidden" value="1">';
  $switch_auto_scrolling  .= '<SCRIPT LANGUAGE="javascript">scroll_me();</SCRIPT>';
}
include('static_tpl.'.$FILE_EXTENSION);
?>
