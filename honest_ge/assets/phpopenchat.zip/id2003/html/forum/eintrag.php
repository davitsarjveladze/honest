<?//-*- C++ -*-
/*   ********************************************************************   **
**   Copyright (C) 1995-2000 Mirko Giese                                    **
**   Copyright (C) 2000-     PHPOpenChat Development Team                   **
**   http://www.ortelius.de/phpopenchat/                                    **
**                                                                          **
**   This program is free software. You can redistribute it and/or modify   **
**   it under the terms of the PHPOpenChat License Version 1.0              **
**                                                                          **
**   This program is distributed in the hope that it will be useful,        **
**   but WITHOUT ANY WARRANTY, without even the implied warranty of         **
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   **
**                                                                          **
**   You should have received a copy of the PHPOpenChat License             **
**   along with this program.                                               **
**   ********************************************************************   */
include "defaults_inc.php";

//start session
if($ENABLE_SESSION){
  @session_start();
}

//Check for access permissions of this page
if(!check_permissions($nick,$pruef)){
  //the user has no access permission for this page
  header("Status: 204 OK\r\n");//browser doesn't refresh his content
  exit;
}

/*
 * Open a database connection
 * The following include returns a database handle
 */
include ("connect_db_inc.php");
$db_handle=connect_db($DATABASEHOST,$DATABASEUSER,$DATABASEPASSWD);
if(!$db_handle){
  exit;
}

$nickcode=urldecode($nick);
?>
<!DOCTYPE HTML PUBLIC "-//AdvaSoft//DTD HTML 3.2 extended 961018//EN">
<HTML>
<HEAD>
<TITLE><? echo $FORUM[title];?></TITLE>
<style type="text/css">
<!--
.text { font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #000000; }
td { font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #ffffff; }
-->
</style>
</HEAD>
<body bgcolor="#284628" TEXT="#FFFFFF" LINK="#66B886" VLINK="#66B886" ALINK="#66B886" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<TABLE WIDTH="100%" CELLPADDING="5" CELLSPACING="0" BORDERS="0">
  <tr>
    <td align="left">
      <?
      if($kommentar!=""){
  	$kommentar=htmlspecialchars($kommentar);
  	$Vorname=htmlspecialchars($Vorname);
  	$email=htmlspecialchars($email);
  	$Homepage=htmlspecialchars($Homepage);
  	$eintrag=mysql_query("insert into chat_forum ( DATE,NAME, VORNAME, EMAIL,HOMEPAGE,EIGENE_URL,KOMMENTAR,HOST,THEMA) values (now(),'$nickcode', '$Vorname','$email', '$Homepage', '$Path_Dir', '$kommentar','$REMOTE_ADDR','$thema')",$db_handle);
  	echo '<font style="font-size: 14px;"><b>'.$FORUM[save_message].'</b></font><br><br>';
      }else{	
  	echo '<font style="font-size: 14px; color: #FF0000;"><b>'.$FORUM[save_message_empty].'</b></font><br><br>';
      }
      ?>
      <table cellpadding="3" cellspacing="0" borders="0">
        <tr>
          <td width="120"><b><?echo $FORUM[save_nickname]?></b></td>
          <td><?echo $nickcode?></td>
        </tr>
        <tr>
          <td width="120"><b><?echo $FORUM[save_email]?></b></td>
          <td><a href="mailto:<?echo $email?>"><?echo $email?></a></td>
        </tr>
        <tr>
          <td width="120"><b><?echo $FORUM[save_homepage]?></b></td>
          <td><a href="<?echo $Homepage?>"><?echo $Homepage?></a></td>
        </tr>
        <tr>
          <td width="120"><b><?echo $FORUM[write_topic]?></b></td>
          <td><?echo $thema?></td>
        </tr>
        <tr>
          <td width="120"><b><?echo $FORUM[save_comment]?></b></td>
          <td><?echo $kommentar?></td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</BODY>
</HTML>
