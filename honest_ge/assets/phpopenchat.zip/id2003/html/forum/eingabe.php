<?//-*- C++ -*-
/*   ********************************************************************   **
**   Copyright (C) 1995-2000 Mirko Giese                                    **
**   Copyright (C) 2000-     PHPOpenChat Development Team                   **
**   http://www.ortelius.de/phpopenchat/                                    **
**                                                                          **
**   This program is free software. You can redistribute it and/or modify   **
**   it under the terms of the PHPOpenChat License Version 1.0              **
**                                                                          **
**   This program is distributed in the hope that it will be useful,        **
**   but WITHOUT ANY WARRANTY, without even the implied warranty of         **
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   **
**                                                                          **
**   You should have received a copy of the PHPOpenChat License             **
**   along with this program.                                               **
**   ********************************************************************   */
include "defaults_inc.php";

//start session
if($ENABLE_SESSION){
  @session_start();
}

//Check for access permissions of this page
if($nick && !check_permissions($nick,$pruef)){
  //the user has no access permission for this page
  header("Status: 204 OK\r\n");//browser doesn't refresh his content
  mysql_close($db_handle);
  exit;
}

$nickcode=urlencode($nick);
?>
<!DOCTYPE HTML PUBLIC "-//AdvaSoft//DTD HTML 3.2 extended 961018//EN">
<HTML>
<HEAD>
<TITLE><?echo$FORUM[title]?></TITLE>
<style type="text/css">
<!--
.text { font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #000000; }
td { font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #ffffff; }
-->
</style>
</HEAD>
<body bgcolor="#284628" TEXT="#FFFFFF" LINK="#66B886" VLINK="#66B886" ALINK="#66B886" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<TABLE WIDTH="100%" CELLPADDING="5" CELLSPACING="0" BORDERS="0">
  <tr>
    <td align="left">
      <font style="font-size: 14px;"><b><?echo $FORUM[write_topic]?><?echo $thema?></b></font> 
      <FORM ACTION="eintrag.<?=$FILE_EXTENSION?>" METHOD="POST">
        <TABLE>
          <TR>
            <TD WIDTH="120"><?echo $FORUM[save_nickname];?></TD>
            <TD><?echo $FORUM[save_email];?></TD>
            <TD><?echo $FORUM[save_homepage];?></TD>
          </TR>
          <TR>
            <TD><b><?echo $nick?></b></TD>
            <TD><INPUT TYPE="text" NAME="email"></TD>
            <TD><INPUT TYPE="text" NAME="Homepage"></TD>
          </TR>
          <TR>
            <TD COLSPAN="3"><BR><?echo $FORUM[write_comment];?></TD>
          </TR>
          <TR>
            <TD COLSPAN="3"><TEXTAREA NAME="kommentar" COLS=50 ROWS=10 wrap=virtual></TEXTAREA></TD>
          </TR>
          <TR>
            <TD COLSPAN="3"><INPUT TYPE=submit VALUE="<?echo $FORUM[write_submit];?>"></TD>
  	  </TR>
	  <?
	  if($ENABLE_SESSION){
  	    echo '<INPUT TYPE="hidden" NAME="'.session_name().'" VALUE="'.session_id().'">';
	  }else{
  	    echo '<INPUT TYPE="hidden" NAME="nick" VALUE="'.$nick.'">';
  	  }
  	  ?>
  	  <input type="hidden" name="thema" value="<?echo $thema?>">
          <input type="hidden" name="pruef" value="<?echo $pruef?>">
	</FORM>
      </TABLE>
    </td>
  </tr>    
</BODY>
</HTML>
