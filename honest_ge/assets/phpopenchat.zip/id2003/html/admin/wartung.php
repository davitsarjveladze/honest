<?//-*- C++ -*-
/*   ********************************************************************   **
**   Copyright (C) 1995-2000 Mirko Giese                                    **
**   Copyright (C) 2000-     PHPOpenChat Development Team                   **
**   http://www.ortelius.de/phpopenchat/                                    **
**                                                                          **
**   This program is free software. You can redistribute it and/or modify   **
**   it under the terms of the PHPOpenChat License Version 1.0              **
**                                                                          **
**   This program is distributed in the hope that it will be useful,        **
**   but WITHOUT ANY WARRANTY, without even the implied warranty of         **
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   **
**                                                                          **
**   You should have received a copy of the PHPOpenChat License             **
**   along with this program.                                               **
**   ********************************************************************   */
include "defaults_inc.php";

/*
 * Open a database connection
 * The following include returns a database handle
 */
include ("connect_db_inc.php");
$db_handle=connect_db($DATABASEHOST,$DATABASEUSER,$DATABASEPASSWD);
if(!$db_handle){
  exit;
}
# check first if this is a call with parameters. theme should show this
if(!$theme && $new!=1){
	$result=mysql_query("select distinct THEMA from chat_forum",$db_handle);
	# now privide the admin with the available options
	$interface ='<table border=0><tr><th>Forum-Name</th><th></th><th></th></tr>';
	while($a=mysql_fetch_array($result)){
		$interface .= '<tr><td>'.$a[THEMA].'</td><td><a href=wartung.php?theme='.$a[THEMA].'&todo=edit>edit</a></td><td> <a href=wartung.php?theme='.$a[THEMA].'&todo=delete>delete</a></td></tr>';
	}
	$interface .= '</table>';

}else{
	if($todo=='edit'){
		$result=mysql_query("select NAME,NUMMER from chat_forum where THEMA='$theme' order by DATE",$db_handle);
		 $interface='<table border=0><tr><th>Nickname</th><th></th><th></th></tr>';
        	while($a=mysql_fetch_array($result)){
                	$interface .= '<tr><td>'.$a[NAME].'</td><td><a href=wartung.php?theme='.$theme.'&id='.$a[NUMMER].'&todo=change>change message</a></td><td> <a href=wartung.php?theme='.$theme.'&id='.$a[NUMMER].'&todo=change>delete message</a></td></tr>';
        	}
        	$interface .= '</table>';

	}elseif($todo=='delete'){
		if($confirm==1){
			$result=mysql_query("delete from chat_forum where THEMA='$theme'",$db_handle);
			$interface=$theme.' deleted. click <a href=wartung.php>here</a> to go back.';
		}else{
			$interface='Sure to delete '.$theme.'?<a href="wartung.php?todo=delete&confirm=1&theme='.$theme.'">YES</a> | <a href="wartung.php">NO</a>';
		}
	}elseif($todo=='change'){
		if($confirm==1){
			$result=mysql_query("update chat_forum set NAME='$name', EMAIL='$email', HOMEPAGE='$homepage', KOMMENTAR='$kommentar' where NUMMER=$id",$db_handle);
		}elseif($confirm==2){
			$result=mysql_query("delete from chat_forum where NUMMER=$id",$db_handle);
			header("location: wartung.php?interface=Message deleted");
		}
		$result=mysql_query("select * from chat_forum where NUMMER=$id",$db_handle);
		$a=mysql_fetch_array($result);
		$interface='<form method=post><input type=hidden name=id value="'.$a[NUMMER].'">';
		$interface .= '<h2>Message from'.$a[NAME].'</h2>';
		$interface .= '<table border=0><tr><td>Nick</td><td><input name=name value="'.$a[NAME].'"></td></tr>';
		$interface .= '<tr><td>Email</td><td><input name=email value="'.$a[EMAIL].'"></td></tr>';
		$interface .= '<tr><td>Homepage</td><td><input name=homepage value="'.$a[HOMEPAGE].'"></td></tr>';
		$interface .= '<tr><td>Message</td><td><textarea name=kommentar wrap=virtual rows=5 cols=40>'.$a[KOMMENTAR].'</textarea></tr>';
		$interface .= '<tr><td><input type=hidden name=todo value="change"><input type=hidden name=confirm value=1><input type=submit value="change"></td></form><form method=post><input type=hidden name=id value="'.$a[NUMMER].'"><input type=hidden name=todo value="change"><input type=hidden name=confirm value="2"><td><input type=submit value="delete this message"></td></tr></form></table>';
	}

}
if($new){#they want create a new theme
	if($confirm==1){
		$result=mysql_query("insert into chat_forum set DATE=now(), NAME='Forum Admin', KOMMENTAR='Welcome to $newtheme', THEMA='$newtheme'");
	}
	$interface  = '<form method=post><input type=hidden name=confirm value=1>';
	$interface .= '<table border=0>';
	$interface .= '<tr><td>New Theme name</td><td><input name=newtheme></td></tr>';
	$interface .= '<input type=submit value="create"></table>';
}

?>
<!DOCTYPE HTML PUBLIC "-//AdvaSoft//DTD HTML 3.2 extended 961018//EN">

<HTML>
<HEAD>
<TITLE>Administrate Forum</TITLE>
</HEAD>

<BODY>
<h1>Administrate Forum</h1>
<a href=index.php>Admin's Home</a> | <a href=wartung.php>ForumAdmin's Home</a> | <a href=wartung.php?new=1>New Theme</a><br>
<?echo $interface;?>
</BODY>
</HTML>
