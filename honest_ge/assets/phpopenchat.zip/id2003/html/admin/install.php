<?//-*- C++ -*-
/*   ********************************************************************   **
**   Copyright (C) 2002 PHPOpenChat Development Team                        **
**   http://www.ortelius.de/phpopenchat/                                    **
**                                                                          **
**   This program is free software. You can redistribute it and/or modify   **
**   it under the terms of the PHPOpenChat License Version 1.0              **
**                                                                          **
**   This program is distributed in the hope that it will be useful,        **
**   but WITHOUT ANY WARRANTY, without even the implied warranty of         **
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   **
**                                                                          **
**   You should have received a copy of the PHPOpenChat License             **
**   along with this program.                                               **
**   ********************************************************************   */

function my_connect($host,$user, $password)
{
  $con = @mysql_connect($host,$user,$password);
	if(!$con){
    die("error connecting to the database");
		return false;
  }else{
    return $con;
  }
}

// look if include-path is set right for the chat
session_start();

session_register('os','dir_char','default_inc','host','user','password','step');
if(!$default_inc){
	$inc_path=ini_get('include_path');
  //echo $inc_path;
	$os=substr(PHP_OS,0,3);
	if(substr($os,0,3)=='WIN'){ //a windows-system is used
		$array=explode(';',$inc_path);
		$os='win';
		$dir_char='\\';
	}else{ //seems to be a *nix-system
		$array=explode(':',$inc_path);
		$os='unix';
		$dir_char = '/';
	}
	$i=TRUE;
  $array[] = '..'.$dir_char.'..';
  $array[] = '..'.$dir_char.'..'.$dir_char.'includes';
	while((list($key,$value)=each($array)) && $i){
		echo "i try $value$dir_char ...<br>";
		if(file_exists($value.$dir_char.'defaults_inc.php')){ //we got it!
			$i=FALSE;
			echo "file found under $value";
			$default_inc=realpath($value.$dir_char.'defaults_inc.php');
		}
	}
}

// ok, we have the default_inc, lets read it
$file = file($default_inc);

if(!$action){ //initial reading of the script
  $step = 1;
	$output .= '<tr><td colspan=3>Hi! This is the PHPOpenChat-Installer.<p> First of all, there are two things to do before you can start the installation!<ul><li>create a database account preconditioned you have permissions to access an existing mysql-database. If not, you have to install a mysql-database first</li><li>Enable write access to <ul><li>/your/path/to/<i>&lt;phpopenchat-2.x.x&gt;</i>/includes/defaults_inc.php</li><li>/your/path/to/<i>&lt;phpopenchat-2.x.x&gt;</i>/html/.htaccess</li></ul>Certainly for the installation procedure only.</li></ul>Please fill out the following form to setup the database connection for your new chat.
</td></tr>';
	$output .= '<tr><td>Username:</td><td><input type="text" name=user></td></tr>';
	$output .= '<tr><td>Password:</td><td><input type="password" name=password></td></tr>';
	$output .= '<tr><td>Databasehost:</td><td><input name=host value="localhost"> Your database is\'nt on the same host as your webserver? In this case change "localhost" to your mysql-database-hostname.</td></tr>';
	$output .= '<tr><td colspan=2><input type=submit value="Continue"></td></tr>';
	$hidden_form .= '<input type=hidden name=action value="read_database">';
}elseif($action=='read_database'){
	$con = my_connect($host,$user,$password);
	if(!$con){
		$output .= '<tr><td>sorry, but the connection failed. try it once again</td></tr>';
		$head .= '<meta http-equiv="refresh" content="3; URL=install.php"> ';
	}else{
    $step = 2;
		$hidden_form .= '<input type=hidden name=action value="create_database">';
		$result = mysql_list_dbs($con); //get all databasese
		$output .= '<tr><td colspan=2>Please select a database, if you want to use an existing database for the chat.<br>
                    If not, fill in a new databasename in the text field below to create a new database (table space).</td></tr>';
		$output .= '<tr><td>existing database: <select name=database><option value="0">select DB';
		while($row=mysql_fetch_array($result)){
			$output .= '<option value="'.$row[Database].'">'.$row[Database];
		}
		$output .= '</select></td><td>new database: <input name="new_database"></td></tr>';
		$output .= '<tr><td colspan=2><input type=submit value="continue"></td></tr>';
	}
}elseif($action=='create_database'){
	if($database && !$new_database){
		$hidden_form .= '<input type=hidden name="database" value="'.$database.'">';
		session_register('database');
    $step = 3;
		$output .= '<tr><td>ok, there is no need to create a new database (table space). Click me to the next form...</td></tr>';
	}elseif($new_database!=""){
		$con = my_connect($host,$user,$password);
		if(mysql_create_db($new_database,$con)){
      echo "Database created successfully\n";
      $database = $new_database;
      session_register('database');
    }else{
      echo "Error creating database: %s\n".mysql_error();
      echo "</table></body></html>";
      exit;
    }
    $step = 3;
		$output .= '<tr><td>ok, the new database is created, click me to the next form...</td></tr>';
		$hidden_form .= '<input type=hidden name="database" value="'.$new_database.'">';
	}else{
		$output .= '<tr><td>you did not select any existing database nor gave me a name for a new. i cant work this way ;-)
                    </td></tr>';
	}

	$hidden_form .= '<input type=hidden name="action" value="insert_data">';
	$output .= '<tr><td><input type=submit value="lets go on"></td></tr>';
}elseif($action=='insert_data'){
	//we need the db.schema-file. if the user did not change anything (what i hope) it is quite easy to find it
	if(!file_exists('../../db.schema')){
		$output .= '<tr><td> could not find the db.schema-file. this could mean, that you have change something with 
                    that installation. specify the file by "hand" (to come)</td></tr>';
	}else{
		$sql_file = '../../db.schema';
		$con = my_connect($host,$user,$password);
		if(mysql_select_db($database,$con)){
			include 'read_dump.php';
		}
		if($db_success){
			// ok, the database is installed
			$output .= '<tr><td>OK, tables created. Click to go to the <input type="submit" name="submit" value="next step">
                        </td></tr>';
			$hidden_form .= '<input type="hidden" name="action" value="ask_details">';
      $step = 4;
		}else{
			$output .= '<tr><td>Error creating the tables. Maybe you try it <a href="install.php">again</a> 
                        or you have to try it manually</td></tr>';
      session_destroy();
		}
	}

}elseif($action == 'ask_details'){
  $step = 5;
  $output .= '<tr><td colspan="2">Now some details about your installation:</td></tr>';
  $output .= '<tr><td valign="top">Name of your first channel: </td><td><input name="entrychannel" value="Channel_1"></td></tr><tr><td colspan="2">&nbsp;</td></tr>';
  $output .= '<tr><td valign="top">Passphrase for your chat (Used to calculate the checksums of the nicknames).<br>Change this sentence to what ever you want, but change it! </td><td valign="top"><input type="text" name="passphrase" value="Glue, strong stuff!"></td></tr><tr><td colspan="2">&nbsp;</td></tr>';
  // not yet ready
  $output .= '<tr><td valign="top">Chat language</td><td>
              <select name="language">
                <option value="dutch">dutch 
                <option value="english" selected>english
                <option value="french">francaise
                <option value="german">deutsch
                <option value="russian">russian
                <option value="spanish">spanish
              </select>
        (there are some more language-files on our 
        <a href="http://www.ortelius.de/phpopenchat/" target="_blank">Homepage</a>, 
        please download them manually and edit <i>&lt;phpopenchat-2.x.x&gt;</i>/includes/defaults_inc.php to change the language of your chat.)</td></tr>';

  $output .= '<tr><td colspan="2"><br>Now it\'s nessesary to setup the php-include-path. This path must contain the path to the PHPOpenChat-includes (<i>&lt;phpopenchat-2.x.x&gt;</i>/includes).<br>
              There are two ways to setup this:<ul>
              <li>create a file named ".htaccess" in <i>&lt;phpopenchat-2.x.x&gt;</i>/html containing "php_value include_path=".:/your/path/to/<i>&lt;phpopenchat-2.x.x&gt;</i>/includes/".
              <p><b>NOTE:</b>Your webserver has to accept changes made by .htaccess-files!</p>
              (read <a href="http://httpd.apache.org/docs/configuring.html#htaccess" target="_blank">webserver-docu</a> if you don\'t know any thing about this configuration files.)</li><li>edit your php.ini and add /your/path/to/<i>&lt;phpopenchat-2.x.x&gt;</i>/html to the include_path</li></ul>
              Do you like to create a .htaccess file whithin your <i>&lt;phpopenchat-2.x.x&gt;</i>/html directory by the PHPOpenChat-installer?<p>
             <b>NOTE</b>: For the next step the webserver <i>must have write access</i> to the following files:
              <ul>
               <li>/your/path/to/<i>&lt;phpopenchat-2.x.x&gt;</i>/html/.htaccess</li>
               <li>/your/path/to/<i>&lt;phpopenchat-2.x.x&gt;</i>/includes/defaults_inc.php</li>
              </ul>
              </p></td></tr>';


  $output .= '<tr><td>Create .htaccess-file?</td><td>Yes:<input type="radio" name="htaccess" value="true" checked> No:<input 
                type="radio" name="htacceses" value="false"></td></tr>';
  $output .= '<tr><td><input type="submit" value="submit"></td></tr>';
  $hidden_form .= '<input type="hidden" name="action" value="do_details">';
}elseif($action == 'do_details'){
    //parse the default_inc and change it the way the user wants to
    $con = my_connect($host,$user,$password);
    foreach($file as $k => $v){

        if(ereg('^\$ENTRYCHANNELNAME',$v)){
            $file_output .= '$ENTRYCHANNELNAME = \''.$entrychannel."';\n";
            //check if entrychannel is already in database
            $query = "select count(*) as count from channels where name = '$entrychannel'";
            $insert_entrychannel = mysql_result(mysql_db_query($database,$query,$con),0,'count');
            if(!$insert_entrychannel){
                //insert entry-channel, what is really only a rename of the default channel
                $query = "update channels set name = '$entrychannel' where name = 'Channel_1'";
                $result = mysql_db_query($database,$query,$con);
            }
        }elseif(ereg('^\$pass_phrase',$v)){
          $file_output .= '$pass_phrase = \''.$passphrase."';\n";

        }elseif(ereg('^\$DATABASENAME',$v)){
          $file_output .= '$DATABASENAME = \''.$database."';\n";

        }elseif(ereg('^\$DATABASEUSER',$v)){
          $file_output .= '$DATABASEUSER = \''.$user."';\n";

        }elseif(ereg('^\$DATABASEPASSWD',$v)){
          $file_output .= '$DATABASEPASSWD = \''.$password."';\n";

        }elseif(ereg('^\$DATABASEHOST',$v)){
          $file_output .= '$DATABASEHOST = \''.$host."';\n";

        }elseif(ereg('^.?.?include ',$v)){
          $tmp_output  = ereg_replace("^include ","//include ",$v);
          $file_output .= str_replace('//include "'.$language,'include "'.$language,$tmp_output);

        }else{
            $file_output .= $v;
        }
    }
    //open default_inc.php and overwrite it
    $fp = fopen($default_inc,'w+');
    if(fwrite($fp,$file_output)){
        $output .= '<tr><td>default_inc.php changes successfully</td></tr>';
    }else{
        $output .= '<tr><td>Error changing defauls_inc.php, please make the changes manually</td></tr>';
    }
    fclose($fp);
    //now create a .htaccess-file, if desired
    if($htaccess){
        if($os == 'win'){
            $seperator = ';';
        }else{
            $seperator = ':';
        }
        $fp1 = @fopen('../.htaccess','w+');
               
        $inc_path = substr($default_inc,0,strrpos($default_inc,$dir_char));

        if(@fwrite($fp1,'php_value include_path ".'.$seperator.$inc_path.'"')){
            $output .= '<tr><td>.htaccess-file created successfully.';
            if($os=='unix'){
              echo '<b>NOTE: Do a "chmod 644 .htaccess" in <i>&lt;phpopenchat-2.x.x&gt;</i>/html and<br> in <i>&lt;phpopenchat-2.x.x&gt;</i>/includes "chmod 644 defaults_inc.php"</b>';
            }
            $output .= '</td></tr>';
        }else{
            $output .= '<tr><td>Error creating .htaccess-file, please make the changes manually</td></tr>';
        }
        @fclose($fp1);
        $output .= '<tr><td><br>ok, thats it. now <a href="../">go back</a> to the homepage of your chat and check the installation. <br> very useful hint: if during this installation something was unsucessfully, believe it!
                    we give our best to make this as automatic as possible, but... strange thinks happen...<br>
                    <br><b>IMPORTANT</b><br>
                    this was only a very low-level-installation. please <font color="red">think about security and protect your admin-directory</font>. Edit 
                    templates to give your chat an individual face. create channels and godfathers(Operators) with the <a href="index.php">admin-tool</a>. For a full setup edit <i>&lt;phpopenchat-2.x.x&gt;</i>/includes/defaults_inc.php<br>
                    last but not least: have fun with our chat ;-)<br>
                    PHPOpenChatTeam</td></tr>';
session_destroy();
    }
}

$steps[] = 1;
$steps[] = 2;
$steps[] = 3;
$steps[] = 4;
$steps[] = 5;
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>PHPOpenChat Installation</title>
	<?=$head?>
</head>

<body>
<h2>PHPOpenChat Installer</h2>
Step: 
<?
reset($steps);
do{
  echo "&nbsp;<b>";
  if(current($steps)==$step){
    echo "<font color=\"red\">";
    echo current($steps);
    echo "</font>";
  }else{
    echo current($steps);
  }
 echo "</b>&nbsp;";
}while(next($steps));
?>

<table border=1>
<form action="install.php" method="post">
<?=$hidden_form?>
<?=$output?>
</form>
</table>

</body>
</html>
