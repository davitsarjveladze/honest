<?//-*- C++ -*-
/*   ********************************************************************   **
**   Copyright (C) 2001-     PHPOpenChat Development Team                   **
**   http://www.ortelius.de/phpopenchat/                                    **
**                                                                          **
**   This program is free software. You can redistribute it and/or modify   **
**   it under the terms of the PHPOpenChat License Version 1.0              **
**                                                                          **
**   This program is distributed in the hope that it will be useful,        **
**   but WITHOUT ANY WARRANTY, without even the implied warranty of         **
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   **
**                                                                          **
**   You should have received a copy of the PHPOpenChat License             **
**   along with this program.                                               **
**   ********************************************************************   */
/*
 * this script should make all the tasks, which are needed to run daily or monthly
 *
 *
 *
 */
include 'defaults_inc.php';
include 'connect_db_inc.php';
$db_handle=connect_db($DATABASEHOST,$DATABASEUSER,$DATABASEPASSWD);

# you have a hughe chat? this script may take some time...
set_time_limit(0);

# delete all messages in message-board which are older than max-forumdate * 2
$result = mysql_query ("delete from chat_forum where TO_DAYS(NOW()) - TO_DAYS(DATE) >= ($FORUMDATE * 2) ");

# delete all registered users which where longer than max_lifetime not here, but don't delete superuser
$MAX_LIFETIME = 120;  //sets, how many days a login is registered without logging in. maybe this should rather be in defaults_inc
# mysql has no subselects :-(
$result = mysql_query("select distinct chat_data.Nick as Nick from chat_data left join paten using (Nick) where (from_unixtime(Zeit) <= (now() - INTERVAL $MAX_LIFETIME DAY))  && paten.Nick is NULL ",$db_handle);
$i = 1;
$num = mysql_num_rows($result);
$where = "''";
while ($a = mysql_fetch_array($result)){
	$where .= ",'".stripslashes($a[Nick])."'";
}

if($where == ''){
	$where = "''";
}
$result = mysql_query ("delete from chat_data where Nick in ($where) ");
#delete all not-confirmed user after 7 days
$result = mysql_query(" delete from chat_data where kicked=-1 AND from_unixtime(Zeit) < (now() - INTERVAL  7 DAY)",$db_handle);
# delete also chat_mail to this user
$MAX_MAILTIME = 30; //sets, how many days chat-mail will be stored.
$result = mysql_query("delete from chat_mail where NICK in ($where) OR SENDER in ('$where')");
$result = mysql_query("delete from chat_mail where  (TIME < DATE_FORMAT(now(),\"%Y-%m-%d\") - INTERVAL $MAX_MAILTIME day)",$db_handle);
# delete welcome-messages after 10 days
$resul = mysql_query("delete from chat_mail where (TIME < DATE_FORMAT(now(),\"%Y-%m-%d\") - INTERVAL 10 day) AND sender = 'Chat-Team'",$db_handle); 

# delete also chat_notify-users wich are no longer registered
$result = mysql_query("delete from chat_notify where Nick in ($where)");

# delete all notifies to users which are not longer in chat_data
$query = 'select chat_notify.Friend as Nick from chat_notify left join chat_data on chat_data.Nick = chat_notify.Friend where chat_data.Nick is NULL ';
$result = mysql_query($query,$db_handle);
unset($where);
while($r_array = mysql_fetch_array($result)){
  if(!$where){
    $where = "'".stripslashes($r_array[Nick])."'";
  }else{
    $where .= ",'".stripslashes($r_array[Nick])."'";
  }
}
$query = 'delete from chat_notify where Friend in ('.$where.')';
$result = mysql_query($query,$db_handle);

# delete userpags from not longer existing users
$result = mysql_query("select chat_userpages.Nick from chat_userpages left join chat_data using (Nick) where chat_data.Nick is NULL",$db_handle);
unset($where);
while($r_array = mysql_fetch_array($result)){
  if(!$where){
    $where = "'".stripslashes($r_array[Nick])."'";
  }else{
    $where .= ",'".stripslashes($r_array[Nick])."'";
  }
}
$query = 'delete from chat_userpages where Nick in ('.$where.')';
$result = mysql_query($query,$db_handle);
#delete guestbook-entries from users no longer exists
$query = 'delete from chat_gb where NICK in ('.$where.') OR USER in ('.$where.')';
$result = mysql_query($query,$db_handle);
# delete user channels when nobody is in
$result = mysql_query ("delete from channels where User_Channel != 0 && Teilnehmerzahl = 0");

# in every 1st of month we want halve the top-list
if(date('j') == 1){
	$result = mysql_query ('update chat_data set Online = (Online / 2) ');
}

//a list of all t ables. add, delete and edit only here
$channel_array = array('channels','chat','chat_data','chat_forum','chat_mail','chat_messages','chat_notify','comoderators','paten','vip','chat_userpages','chat_gb');

# mow lets optimize the tables. after a long chat-day there are many deleted rows...
while(list($key,$value)=each($channel_array)){
	$result = mysql_query("optimize table $value");
	
}

#####
# uncomment this only if you have a unix-system and you know what you are doing
#####
/*
// create a new table-dump and move the last 4 dumps
if(file_exists("./dump4.sql.gz")){
	copy("./dump4.sql.gz","./dump5.sql.gz");
}
if(file_exists("./dump3.sql.gz")){
	copy("./dump3.sql.gz","./dump4.sql.gz");
}
if(file_exists("./dump2.sql.gz")){
	copy("./dump2.sql.gz","./dump3.sql.gz");
}
if(file_exists("./dump1.sql.gz")){
	copy("./dump1.sql.gz","./dump2.sql.gz");
}
exec("mysqldump -u $DATABASEUSER --password='$DATABASEPASSWD' phpopenchat > dump1.sql");
exec("gzip -c /usr/local/www/htdocs/service/dump1.sql > /usr/local/www/htdocs/service/dump1.sql.gz");
	
#}
*/
?>
