<? // -*- C++ -*-
/*   ********************************************************************   **
**   Copyright (C) 1995-2000 Michael Oertel                                 **
**   Copyright (C) 2000-     PHPOpenChat Development Team                   **
**   http://www.ortelius.de/phpopenchat/                                    **
**                                                                          **
**   This program is free software. You can redistribute it and/or modify   **
**   it under the terms of the PHPOpenChat License Version 1.0              **
**                                                                          **
**   This program is distributed in the hope that it will be useful,        **
**   but WITHOUT ANY WARRANTY, without even the implied warranty of         **
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   **
**                                                                          **
**   You should have received a copy of the PHPOpenChat License             **
**   along with this program.                                               **
**   ********************************************************************   */

/**
 * Include default values
 */
include "defaults_inc.php";

/**
 * Open a database connection
 *
 * This include returns a database identifier '$db_handle'
 * used by some database querys.
 */
include ("connect_db_inc.php");
$db_handle=connect_db($DATABASEHOST,$DATABASEUSER,$DATABASEPASSWD);
if(!$db_handle){
  exit;
}

$result_chat = mysql_query("SELECT Nick, Email, Online FROM chat_data where Nick='$user'",$db_handle);
if(mysql_num_rows($result_chat)<1){
  $no_user = TRUE;
}

$result_userpage = mysql_query("SELECT * FROM chat_userpages where Nick='$user'",$db_handle);
$chatuserdata = mysql_fetch_array($result_chat);
$userpagedata = mysql_fetch_array($result_userpage);
mysql_free_result($result_chat);
mysql_free_result($result_userpage);
$result = mysql_query("SELECT count(*) AS count FROM chat_data WHERE Online >= $chatuserdata[Online]",$db_handle);
$toplistplace = @mysql_result($result,0,"count");
$result = mysql_query("SELECT Nick FROM chat where Nick='$user'",$db_handle);
if(mysql_num_rows($result)>0){
  $online_status = '<font color="#009900"><b>Online</b></font>';
}else{
  $online_status = '<font color="#FF0000">Offline</font>';
}
mysql_free_result($result);

$result = mysql_query("SELECT Friend FROM chat_notify where Nick='$user'",$db_handle);
while($friends=mysql_fetch_object($result)){
  $list_friends .= '<a href="javascript:OpenUserpage(\'userpage.php?user='.urlencode($friends->Friend).'\')">'.$friends->Friend.'</a> &nbsp;';
}
mysql_free_result($result);

if($userpagedata[Gender]=='male'){
  $gender = $MSG_REGISTER_MALE;
}elseif($userpagedata[Gender]=='female'){
  $gender = $MSG_REGISTER_FEMALE;
}else{
  $gender = 'n/a';
}

$current_date = date("Ymd",time());
if($userpagedata[Birthdate] != "" && $userpagedata[Birthdate] > 0){
  $show_age = substr(($current_date - $userpagedata[Birthdate]),0,2);
}

$show_birthdate = substr($userpagedata[Birthdate],6,2).".".substr($userpagedata[Birthdate],4,2).".".substr($userpagedata[Birthdate],0,4);

?>
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<html>
<head>
<title><?=$UP_FROM?> <?echo $user?></title>
<style type="text/css">
<!--
.text { font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
.header { font-family: Arial, Helvetica, sans-serif; font-size: 16px; }
td { font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
a:hover { text-decoration: none; }
-->
</style>
<script language="JavaScript" type="text/javascript">
<!--
function OpenUserpage(file) {
  var newWindow;
  newWindow=window.open(file,"userpage","scrollbars=yes,directories=no,width=640,height=480")
  if (newWindow != null && newWindow.opener == null)
    newWindow.opener=window
}
// -->
</script>
</head>
<body bgcolor="#284628" TEXT="#FFFFFF" LINK="#66B886" VLINK="#66B886" ALINK="#66B886" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" CLASS="text">
<?
if($no_user){
	echo $UP_UNKNOWN_USER;
  echo '<br>';
  echo $INVALID_NICK;
	exit;
}
?>

<table width="100%" cellspacing="0" cellpadding="5" border="0">
<tr>
<td bgcolor="#000000" align="left" class="header">
<b><font color="#ffffff"><?echo $chatuserdata[Nick]?></font></b> - <font style="font-size: 12px;"><?=$UP_TOPLISTPLACE?>: <?=$toplistplace;?></font>
</td>
<td bgcolor="#000000" align="right" class="header">
<?echo $online_status?>
</td>
</tr>
<tr>
<td colspan="2" bgcolor="#555555" align="left">
<i><?echo $userpagedata[Theme]?></i>
</td>
</tr>
</table>
<table width="100%" cellspacing="0" cellpadding="0" border="0">
<tr>
<td width="400" align="left" valign="top">
<table width="100%" cellspacing="0" cellpadding="5" border="0">
<tr><td><b><?=$UP_INFO?>:</b><br><?=nl2br($userpagedata['Info']);?></td></tr>
<tr><td><b><?=$UP_HOBBY?>:</b><br><?=nl2br($userpagedata['Hobbies']);?><br></td></tr>
<tr>
<td>
<?
if($userpagedata['Show_Email']){?>
	<a href="mailto:<?echo $chatuserdata[Email]?>"><?echo $chatuserdata[Email]?></a><br><br>
<?}
if($userpagedata['Homepage']){
?>
	<a href="http://www.schulhofchat.de/jump.php?url=<?echo $userpagedata[Homepage]?>" target="_blank">Homepage</a><br><br>
<?}?>
ICQ: <?if($userpagedata['ICQ']){echo $userpagedata['ICQ'];}else{echo 'n/a';}?><br>
<?=$UP_SEX?>: <?echo $gender;?><br>
<?if($userpagedata['Show_Birthdate']){?>
  <?=$UP_BIRTHDATE?>: <?if($show_birthdate!='..'){echo $show_birthdate;}else{ echo 'n/a';}?><br>
  <?=$UP_AGE?>: <?if($show_age){echo $show_age;}else{echo 'n/a';}?><br>
<?}?>
<?=$UP_HOME?>: <?if($userpagedata['City']){echo $userpagedata[City];}else{echo 'n/a';}?>
</td>
</tr>
</table>
</td>
<td width="230" align="right">
<?if($userpagedata[Picture] != 'http://' && $userpagedata[Picture] != ''){?>
<img src="<?echo $userpagedata[Picture]?>" width="175" height="210" alt="<?echo $user?>">
<?}?>
</td>
</tr>
</table>
<br>
<table width="100%" cellspacing="0" cellpadding="5" border="0"> 
<?if($userpagedata['Show_Friends']){?>
<tr>
<td width="120" valign="top" bgcolor="#000000"><?=$UP_FRIENDS?><br><?=$CHATNAME?>:</td>
<td width="500" bgcolor="#000000">
<?echo $list_friends;?>
</td>
</tr>
<?}?>
</table>
<?
if(!$HTTP_SESSION_VARS['nick']){
	$action = '';
}

switch ($action){

  case "gb_entry":
    include("gb_entry_tpl.php");
    break;
  	
  case "gb_save":
    function strmaxwordlen($input,$len){
      $l=0;
      $output="";
      for ($i=0; $i<strlen($input); $i++){
        $char=substr($input,$i,1);
        if ($char != " ") { $l++; } else { $l = 0; }
        if ($l == $len) { $l = 0; $output .= " "; }
        $output .= $char ;
      }
      return($output);
    }
    if ($text==""){
      echo '<font class="error">'.$UP_GB_ERROR.'!</font><BR><BR>';
      include("gb_entry_tpl.php");
    }else{
      $text=ereg_replace("(\n|\n\015|\015\n|\|)","<BR>",strmaxwordlen(htmlentities(stripslashes($text),ENT_QUOTES),50));
      $update = mysql_query("INSERT INTO chat_gb (USER,NICK,DATE,COMMENT)VALUES('$user','$nick',CURRENT_TIMESTAMP(),'".$text."')",$db_handle);
      echo '<BR>'.$user.' - '.$UP_GB_SAVED.'...<BR><BR>';
      echo '<FORM ACTION="./userpage.php?user='.$user.'" METHOD="post">';
      echo '<INPUT TYPE="submit" VALUE="'.$UP_GB_BACK.'"></FORM></CENTER>';
    }
    break;
  	 	
  default:
    $count = mysql_query("SELECT count(*) as count FROM chat_gb WHERE USER='$user'",$db_handle);
    $msg_count = mysql_result($count,0,'count');
    $limit = 10;
    if(isset($nav)){
      switch ($nav) {
                    case first:
                        $msg_start = 1;
                        break;
                    case prev:
                        if ($msg_start - $limit > 1) { $msg_start = $msg_start - $limit; }
                        break;
                    case next:
                        $msg_start = $msg_start + $limit +1;
                        if ($msg_start > $msg_count) { $msg_start = 1; }
                        break;
                    case last:
                        $msg_start = $msg_count - $limit +1;
                        if ($msg_start < 0) {$msg_start=1; }
                        break;
                }
        }

        // number of pages
        $num_pages = ceil($msg_count / $limit);

        if ( ! isset ($page)) { $page = 1; }
        if ($page > $num_pages) { $page=1; }
        $msg_start = $page * $limit - $limit +1 ;

        // set start-message if not set
        if ( ! isset ($msg_start)) { $msg_start = 1; }

        // set stop-message
        $msg_stop = $msg_start + $limit -1 ;

        // if $msg_start is invalid set it to 1
        if ($msg_start > $msg_count) { $msg_start = 1; }

        // if $msg_start is invalid set it to 1
        if ($msg_stop > $msg_count) { $msg_stop = $msg_count; }

        // set start-message for the database
        $sql_start = $msg_start -1;

        // select a number of messages in range of $msg_start to $msg_stop
        //delete if it was wished
        $result = mysql_query("delete from chat_gb where ID = '$delete' && USER = '".$HTTP_SESSION_VARS['nick']."'",$db_handle);
        $result = mysql_query("SELECT * FROM chat_gb WHERE USER='$user' ORDER BY ID DESC LIMIT $sql_start, $limit",$db_handle);
        echo '<TABLE WIDTH="100%" cellspacing="0" cellpadding="5" border="0">';
        if($nick){
          echo '<TR><TD COLSPAN="2" ALIGN="LEFT"><A HREF="userpage.php?user='.$user.'&action=gb_entry"><b>'.$UP_GB_SIGNHERE.'...</b></A></TD></TR>';
        }else{
	  echo '<tr><td colspan="2" align="left"><b>'.$UP_GB_NOTLOGGEDIN.'.</b></td></tr>';
	}
	echo '<TR><TD ALIGN="LEFT">'.$UP_GB_MSGCOUNT.': <b>'.$msg_count.'</b></TD>';
	
	if ($msg_count > $limit){
          echo '<TD ALIGN="RIGHT">';
          echo $UP_GB_MOVE.': ';
          for($quark = 1; $quark < $num_pages + 1; $quark++){
            echo '<a href="userpage.php?user='.urlencode($user).'&page='.$quark.'">';
            if ($quark == $page){
              echo '<b><font color="#66CC88">'; 
            }
            echo $quark;
            if ($quark == $page){
              echo '</b></font>'; 
            }
            echo '</a>&nbsp;';
	  }
	  echo '</FONT></TD></TR>';
	}
	echo '</TABLE><BR>';
			 	
//show guestbook
        while($data=mysql_fetch_array($result)){
          $gb_date = $data[DATE];
       		$showdate  = substr($gb_date,8,2).".";
      		$showdate .= substr($gb_date,5,2).".";
      		$showdate .= substr($gb_date,0,4)." um ";
      		$showdate .= substr($gb_date,11,5).' Uhr';
       		echo '<table cellspacing="0" cellpadding="5" border="0"><tr><td>';
      		echo '<a href="userpage.php?user='.urlencode($data['NICK']).'"><b>'.$data['NICK'].'</b></a>'.$UP_BG_WROTE ;
      		echo $showdate.'<br>'; 
      		echo $data['COMMENT'];
          if($user == $HTTP_SESSION_VARS['nick']){ // it is tha page from user self
            echo '<br><a href="userpage.php?user='.urlencode($user).'&delete='.$data['ID'].'&'.session_name().'='.session_id().'" onClick="return confirm(\''.$UP_GB_CONFIRM_DELETE.'\');"><font color="red">'.$UP_GB_DELETE.'</font></a>';
          }
         	echo '</td></tr></table><br>';
        }
}
mysql_close($db_handle);
?>
</body>
</html>
