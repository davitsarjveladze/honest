<?//-*- C -*-
/*   ********************************************************************   **
**   Copyright (C) 1995-2000 Michael Oertel                                 **
**   Copyright (C) 2000-     PHPOpenChat Development Team                   **
**   http://www.ortelius.de/phpopenchat/                                    **
**                                                                          **
**   This program is free software. You can redistribute it and/or modify   **
**   it under the terms of the PHPOpenChat License Version 1.0              **
**                                                                          **
**   This program is distributed in the hope that it will be useful,        **
**   but WITHOUT ANY WARRANTY, without even the implied warranty of         **
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   **
**                                                                          **
**   You should have received a copy of the PHPOpenChat License             **
**   along with this program.                                               **
**   ********************************************************************   */

include("defaults_inc.php");

/*
 * Open a database connection
 * The following include returns a database handle
 */
include ("connect_db_inc.php");
$db_handle=connect_db($DATABASEHOST,$DATABASEUSER,$DATABASEPASSWD);
if(!$db_handle){
  exit;//the error message is printed in connect_db_inc.php
}

if(!$pruef){
  $Passwort2=$Passwort;
}else{
  //Check for access permissions of this page
  if($nick && !check_permissions($nick,$pruef)){
    //the user has no access permission for this page
    header("Status: 204");//browser don't refresh his content
    mysql_close($db_handle);
    exit;
  }
}

function login (){
  global $nick,$FILE_EXTENSION,$NICK_NAME,$PASSWORD,$USERPROFILE;
  echo '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
  <html>
  <head>
  <title>'.$USERPROFILE.'</title>
  <style type="text/css">
  <!--
  .text { font-family: Arial, Helvetica, sans-serif; font-size: 12px }
  -->
  </style>
  </head>
  <BODY BGCOLOR="#F4F4F4" TEXT="#000000" LINK="#0000FF" VLINK="#0000FF" ALINK="#0000FF" class="text">
  <TABLE width="400" border="0" cellspacing="0" cellpadding="0" align="center" class="text">
    <TR>
      <TD>
        <TABLE border="0" align="center">
        <FORM ACTION="user_profile.'.$FILE_EXTENSION.'" METHOD="POST">
        <TR>
        <TD ALIGN=RIGHT class="text">'.$NICK_NAME.':</TD>
        <TD><INPUT NAME="Nick" TYPE="text" VALUE="'.$nick.'"></TD>
        </TR>
        <TD ALIGN=RIGHT class="text">'.$PASSWORD.':</TD>
        <TD><INPUT NAME="Passwort" TYPE="password" VALUE=""></TD>
        </TR>
        <TR>
        <TD></TD>
        <TD><INPUT TYPE="submit" VALUE="Login"></TD>
        </TR>
        </FORM>
        </TABLE>
      </TD>
    </TR>
  </TABLE>
  </BODY>
  </HTML>';
  exit;
}
function print_file($file,$type,$mode){
  
  if($file){
    if(ereg("image", $type)){
      $site_img = '<img src="' . $file . '" border="0" ';
    }else{
      $userfile = fopen($file, "r");
      while(!feof($userfile)) {
	$line = fgets($userfile, 255);
	switch($mode){
	case 1:
	  $site .= $line;
	  break;
	case 2:
	  $site .= nl2br(ereg_replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;", htmlentities($line)));
	  break;
	}	
      }
    }
  }
}

function UploadImage(){
  global $SEND_IMG,$CHOOSE_IMG,$ENABLE_SESSION,$SCRIPT_NAME,$nick,$pruef;
  echo '<table><tr valign="middle"><td class="text">
	<form enctype="multipart/form-data" action="'.$SCRIPT_NAME.'" method="post">
        <input type="hidden" name="img" value="">';
  if(!$ENABLE_SESSION){
    global $nick,$pruef;
    echo '<input type="hidden" name="nick"  value="$nick">
          <input type="hidden" name="pruef" value="$pruef">';
  }
  echo '<INPUT TYPE="hidden" NAME="nick" VALUE="'.$nick.'">
  <INPUT TYPE="hidden" NAME="pruef" VALUE="'.$pruef.'">
  <font style="font-size: 12px;"><b>'.$CHOOSE_IMG.':</b></td><td> 
  <input name="incom_img" type="file">&nbsp;&nbsp;&nbsp;&nbsp;</font></td></tr>
  <tr><td colspan="2" align="center"><br><input type="hidden" name="op" value="PreviewUpload" >
  <INPUT type="submit" value="'.$SEND_IMG.'"></td></tr></form></table>';
}

function PreviewUpload($img,$incom_img){
  global $nick;
  
  $PATH = "images/chatter/";

  if($incom_img != "none"){	
    require("fileupload_class.php");
    
    $FILENAME = "incom_img";
    //$ACCEPT = "image/gif,image/jpeg";
    $ACCEPT = "image/gif";
    $EXTENSION = "";
    $SAVE_MODE = 1;
    
    $upload = new uploader;
    global $USERIMG_MAX_BYTES,$USERIMG_IMGSIZE_X,$USERIMG_IMGSIZE_Y;
    $upload->max_filesize($USERIMG_MAX_BYTES);
    $upload->max_image_size($USERIMG_IMGSIZE_X,$USERIMG_IMGSIZE_Y);
    $upload->save_name(strtolower(str_replace(' ','_',$nick)));
    
  }else{
    $image_name = $img;
  }

  $site = '';
  if ($incom_img != "none") {
    $file_accepted = $upload->upload("$FILENAME", "$ACCEPT", "$EXTENSION");
    if($file_accepted) {
      if($upload->save_file("$PATH", $SAVE_MODE)) {
	print_file($upload->new_file, $upload->file["type"], 2);
	$image_name = $upload->file["name"];
	//$site .= "new file: <img src='$PATH$image_name' border=0>";
	global $NEW_IMG_HINT;
	$site .= $NEW_IMG_HINT;
      }
    }elseif($file_accepted==-1){
      
    }elseif($file_accepted==-2){
      
    }
  } elseif ($img != "") {
    $site .= "<img src='$PATH$img' border=0>";
  } 
  
  /* if errors on upload - start */
  if($upload->errors){
    global $MAX_FILE_EXCEEDED,$MAX_SIZE_EXCEEDED,$HINT_IMG_SIZE,$USERIMG_IMGSIZE_X,$USERIMG_IMGSIZE_Y,$ALLOWED,$MIME_ERROR;
    while(list($key, $var) = each($upload->errors)){
      $var = str_replace('[FS_ERROR]',$MAX_SIZE_EXCEEDED.' ('.$ALLOWED.': '.$USERIMG_IMGSIZE_X.'x'.$USERIMG_IMGSIZE_Y.') '.$HINT_IMG_SIZE.' ',$var);
      $var = str_replace('[KB_ERROR]',$MAX_FILE_EXCEEDED.' ',$var);
      $var = str_replace('[MIME_ERROR]',$MIME_ERROR.' ',$var);
      $site .= "<font color=red><p>" . $var . "<br></font>";
    }
  }
  if($NEW_NAME){
    $site .= "<p>Name of image save: <b>$NEW_NAME</b></p>";
  }
  /* if errors on upload - end */
  
  $site .= "$site_img<br><br>";
  echo $site;
  
  UploadImage();
}

if(!$nick && !$nick){
  login();
}else{
  $result_chat=mysql_query("SELECT * FROM chat_data WHERE Nick='$nick'",$db_handle);
  $result_userpage=mysql_query("SELECT * FROM chat_userpages WHERE Nick='$nick'",$db_handle);
  $chatuserdata=mysql_fetch_array($result_chat);
  $userpagedata=mysql_fetch_array($result_userpage);
  if(mysql_num_rows($result_chat)<1){
    login();
    exit;
  }
  $passwort_db=mysql_result($result_chat,0,"Passwort");
  if($passwort_db==$SPERRPASSWORT){
    echo '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
    <html>
    <head>
    <title>'.$USERPROFILE.'</title>
    <style type="text/css">
    <!--
    .text { font-family: Arial, Helvetica, sans-serif; font-size: 12px }
    -->
    </style>
    </head>
    <body bgcolor="#F4F4F4" TEXT="#000000" LINK="#0000FF" VLINK="#0000FF" ALINK="#0000FF" class="text">
    <table border="0" cellspacing="0" cellpadding="0" width="600">
      <tr>
        <TD class="text">
          '.$BANNED_MSG.'<BR><BR>
        </TD>
      </tr>
      <tr>
        <TD class="text" align="center">
          <HR><BR>
          <font style="font-size: 14px;" class="text">< <A HREF="index.php">Zur�ck</A> ></font>
        </TD>
      </TR>
    </TABLE>
    </BODY></HTML>';
    exit;
  }
  if(($passwort_db!=$Passwort)&&(!$pruef)){
    login();
  }else{
    $pruef=Crypt($nick,$salt_nick);
    if($$ENABLE_SESSION){
      session_register('pruef','nick');
    }
    echo '
    <!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
    <html>
    <head>
    <title>'.$USERPROFILE.'</title>
    <style type="text/css">
    <!--
    body { font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #ffffff }
    td { font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #000000 }
    -->
    </style>
    <script language="JavaScript" type="text/javascript">
    <!--
    function OpenUserpage(file) {
      var newWindow;
      newWindow=window.open(file,"userpage","scrollbars=yes,directories=no,width=640,height=480")
      if (newWindow != null && newWindow.opener == null)
        newWindow.opener=window
    }
    // -->
    </script>
    </head>
    <BODY bgcolor="#F4F4F4" TEXT="#000000" LINK="#0000FF" VLINK="#0000FF" ALINK="#0000FF" class="text">';
           
    if($pruef && $eintragen){
      $birthdate = $year*10000 + $month*100 + $day;
      if($Passwort!=$Passwort2){
        echo "<FONT COLOR=#FF0000>$FEHLER:</FONT> $PWD_DONT_MATCH<BR>";
      }elseif(!$Passwort){
        echo "<FONT COLOR=#FF0000>$FEHLER:</FONT> $NO_EMPTY_PWD<BR>";
      }elseif($eintragen && $Passwort && $Passwort2){
        $update=mysql_query("UPDATE chat_data SET Passwort='$Passwort', Email = '$Email' WHERE Nick='$nick'",$db_handle);
        if($pgender != 'female' && $pgender != 'male'){
          $pgender = '';
        }

        $query = "UPDATE chat_userpages 
                    SET 
                        Info = '".htmlentities($Info,ENT_QUOTES )."', 
                        Hobbies = '".htmlentities($Hobbies,ENT_QUOTES )."', 
                        Picture = '".htmlentities($Picture,ENT_QUOTES )."', 
                        Homepage='".htmlentities($Homepage,ENT_QUOTES )."', 
                        Theme='".htmlentities($Theme,ENT_QUOTES )."', 
                        City='".htmlentities($City,ENT_QUOTES )."', 
                        ICQ='".htmlentities($ICQ,ENT_QUOTES )."', 
                        Birthdate='".htmlentities($birthdate,ENT_QUOTES )."', 
                        Show_Friends = '$show_friend', 
                        Show_Email = '$show_email', 
                        Show_Birthdate = '$show_birth', 
                        Gender = '$pgender' 
                    WHERE Nick='$nick'";
	    	$update=mysql_query($query,$db_handle);
      	echo '<font color=green>'.$PROFIL_UPDATE_SUCCESS.'</font><BR><BR>';
      	echo '<A HREF="javascript:OpenUserpage(\'userpage.php?user='.urlencode($nick).'\')">'.$PROFIL_LOOKAT_UP.'</A><BR><BR>';
	echo '<A HREF="user_profile.php?nick='.$nick.'&pruef='.$pruef.'">'.$PROFIL_BACK_TO.'</A>';
	exit;
      }
    }
    echo "<TABLE WIDTH=\"600\" CELLPADDING=\"3\" CELLSPACING=\"0\" BORDER=\"0\" ALIGN=\"CENTER\"><TR><TD ALIGN=\"CENTER\">";
    echo "<TABLE BGCOLOR=\"#DDDDDD\" CELLPADDING=\"3\" CELLSPACING=\"0\" BORDER=\"0\">";
    echo "<FORM ACTION=\"user_profile.$FILE_EXTENSION\" METHOD=\"SUBMIT\">";  
    echo "<TR><TD COLSPAN=\"2\" ALIGN=\"CENTER\"><FONT STYLE=\"font-size: 16px;\"><B>Chat-Daten</B></FONT></TD></TR>"; 
    echo "<TR><TD>Nick:</TD><TD>".$nick."</TD></TR>";
    echo "<TR><TD>$PASSWORD:</TD><TD><INPUT NAME=\"Passwort\" TYPE=\"password\" VALUE=\"".$chatuserdata[Passwort]."\" MAXLENGTH=\"8\" SIZE=\"8\"></TD></TR>\n";
    echo "<TR><TD>$PWD_REPEATE:</TD><TD><INPUT NAME=\"Passwort2\" TYPE=\"password\" VALUE=\"".$chatuserdata[Passwort]."\" MAXLENGTH=\"8\" SIZE=\"8\"></TD></TR>\n";  
    if(!$chatuserdata[Email]){
      echo "<TR><TD>$MAIL_ADDRESS:</TD><TD><INPUT NAME=\"Email\" TYPE=\"text\" VALUE=\"".$chatuserdata[Email]."\" SIZE=\"40\"></TD></TR>\n";
    }else{
      echo "<TR><TD>$MAIL_ADDRESS:</TD><TD>".$chatuserdata[Email]."</TD></TR>\n";
      echo "<input type=hidden name=Email value=\"$chatuserdata[Email]\">";
    }
    echo "</TABLE><BR>";
    echo "<TABLE BGCOLOR=\"#DDDDDD\" CELLPADDING=\"3\" CELLSPACING=\"0\" BORDER=\"0\">";
    echo "<TR><TD COLSPAN=\"2\" ALIGN=\"CENTER\"><FONT STYLE=\"font-size: 16px;\"><B>Userpage-Daten</B></FONT></TD></TR>";
    if($userpagedata[Gender] == 'male' || $userpagedata[Gender] == 'female' ){
      echo '<input type="hidden" name="pgender" value="'.$userpagedata['Gender'].'">';
    }else{
      echo '<tr> 
        <td align="left">'.$PROFIL_GENDER.'</td>
        <td>
          '.$PROFIL_MALE.'<input type="radio" name="pgender" value="male">
          '.$PROFIL_FEMALE.'<input type="radio" name="pgender" value="female">
        </td>
      </tr>';
    }
    $db_year = substr($userpagedata[Birthdate],0,4);
    $db_month = substr($userpagedata[Birthdate],4,2);
    $db_day = substr($userpagedata[Birthdate],6,2);
    echo "<TR><TD>".$PROFIL_BIRTHDATE.":</TD><TD>";
    echo "<INPUT NAME=\"day\" TYPE=\"text\" VALUE=\"$db_day\" MAXSIZE=\"2\" SIZE=\"2\"> . \n";
    echo "<INPUT NAME=\"month\" TYPE=\"text\" VALUE=\"$db_month\" MAXSIZE=\"2\" SIZE=\"2\"> . \n";
    echo "<INPUT NAME=\"year\" TYPE=\"text\" VALUE=\"$db_year\" MAXSIZE=\"4\" SIZE=\"4\"></TD></TR>\n";
    echo "<TR><TD COLSPAN=\"2\"><FONT COLOR=#FF0000><b>$HINT:</b></FONT> $URL_FORMAT_HINT</TD></TR>";
    echo "<TR><TD>$PROFIL_PIC:</TD><TD><INPUT NAME=\"Picture\" TYPE=\"text\" VALUE=\"".$userpagedata[Picture]."\" SIZE=\"40\" maxsize=\"130\"></TD></TR>\n";
    echo "<TR><TD>$PROFIL_HOMEPAGE:</TD><TD><INPUT NAME=\"Homepage\" TYPE=\"text\" VALUE=\"".$userpagedata[Homepage]."\" SIZE=\"40\" maxsize=\"130\"></TD></TR>\n";
    echo "<TR><TD>$PROFIL_MOTTO:</TD><TD><INPUT NAME=\"Theme\" TYPE=\"text\" VALUE=\"".$userpagedata[Theme]."\" SIZE=\"40\" maxsize=\"250\"></TD></TR>\n";
    echo "<TR><TD>$PROFIL_INFO:</TD><TD><textarea NAME=\"Info\" rows=\"3\" cols=\"40\">".$userpagedata[Info]."</textarea> </TD></TR>\n";
    echo "<TR><TD>$PROFIL_HOBBIES:</TD><TD><INPUT NAME=\"Hobbies\" TYPE=\"text\" VALUE=\"".$userpagedata[Hobbies]."\" SIZE=\"40\" maxsize=\"250\"></TD></TR>\n";
    echo "<TR><TD>$PROFIL_HOME:</TD><TD><INPUT NAME=\"City\" TYPE=\"text\" VALUE=\"".$userpagedata[City]."\" SIZE=\"40\" maxsize=\"100\"></TD></TR>\n";
    echo "<TR><TD>$PROFIL_ICQ:</TD><TD><INPUT NAME=\"ICQ\" TYPE=\"text\" VALUE=\"".$userpagedata[ICQ]."\" SIZE=\"40\" maxsize=\"15\"></TD></TR>\n";
    $mail_check1['1'] = 'checked';
    $birth_check1['1'] = 'checked';
    $firend_check1['1'] = 'checked';
    $mail_check0['0'] = 'checked';
    $birth_check0['0'] = 'checked';
    $firend_check0['0'] = 'checked';
    echo '<tr> 
	   <td width="269">
          <div align="left">'.$PROFIL_SHOW_EMAIL.'</div>
        </td>
        <td width="472"> '.$PROFIL_YES.' 
          <input type="radio" name="show_email" value="1" '.$mail_check1[$userpagedata['Show_Email']].'>
          '.$PROFIL_NO.' 
          <input type="radio" name="show_email" value="0" '.$mail_check0[$userpagedata['Show_Email']].'>
        </td>
      </tr>
      <tr> 
        <td width="269">
          <div align="left">'.$PROFIL_SHOW_FRIENDS.'</div>
        </td>
        <td width="472">'.$PROFIL_YES.'
          <input type="radio" name="show_friend" value="1" '.$mail_check1[$userpagedata['Show_Friends']].'>
          '.$PROFIL_NO.' 
          <input type="radio" name="show_friend" value="0" '.$mail_check0[$userpagedata['Show_Friends']].'>
        </td>
      </tr>
	  <tr> 
        <td width="269">
          <div align="left">'.$PROFIL_SHOW_BIRTHDATE.'</div>
        </td>
        <td width="472">'.$PROFIL_YES.'
          <input type="radio" name="show_birth" value="1" '.$mail_check1[$userpagedata['Show_Birthdate']].'>
          '.$PROFIL_NO.' 
          <input type="radio" name="show_birth" value="0" '.$mail_check0[$userpagedata['Show_Birthdate']].'>
        </td>
      </tr>';
	echo "<TR><TD COLSPAN=\"2\" ALIGN=\"CENTER\"><INPUT TYPE=\"submit\" NAME=\"eintragen\" VALUE=\"$PROFIL_SAVE_CHANGES\">";
    echo "</TABLE><INPUT TYPE=\"hidden\" NAME=\"Nick\" VALUE=\"$nick\">";
    echo "<INPUT TYPE=\"hidden\" NAME=\"pruef\" VALUE=\"".$pruef."\">";
    echo "</TD></TR></FORM></TABLE><BR>\n";
    
    echo "<TABLE ALIGN=\"CENTER\" BGCOLOR=\"#DDDDDD\" CELLPADDING=\"3\" CELLSPACING=\"0\" BORDER=\"0\">";
    echo "<TR><TD ALIGN=\"CENTER\"><FONT STYLE=\"font-size: 16px;\"><B>Chat-Icon</B></FONT></TD></TR>";
    echo "<TR><TD><TABLE BGCOLOR=\"#DDDDDD\" CELLPADDING=\"3\" CELLSPACING=\"0\" BORDER=\"0\">";
    echo "<TR><TD WIDTH=\"200\" ALIGN=\"RIGHT\">$USER_ICON:&nbsp;</TD><TD WIDTH=\"18\" BGCOLOR=\"#284628\" ALIGN=\"CENTER\">";
    $smileydir="images/chatter/";
    if(file_exists($smileydir.strtolower(str_replace(" ","_",$nick)).".gif")){
      echo '<IMG WIDTH=16 HIGHT=16 SRC="'.$smileydir.urlencode(strtolower(str_replace(" ","_",$nick))).'.gif">';
    }else{
      echo '<IMG WIDTH=16 HIGHT=1 SRC="images/dot_clear.gif">';
    }
    echo "</TD></TR></TABLE></TD></TR><TR><TD>";
       
    //user pic upload
    $result=mysql_query("SELECT Nick,Online FROM chat_data ORDER by Online desc LIMIT 0,30",$db_handle);
    while($row=mysql_fetch_array($result)){
      if($row[Nick]==$nick){
        switch($op){
          case "PreviewUpload":
            PreviewUpload($img, $incom_img);
            break;
          default:
            UploadImage();
            break;   
        }
      }
    } 
    echo '</TD></TR></TABLE><BR>';
  }
  echo '</TD></TR></TABLE></body></html>';
}
mysql_close($db_handle);
?>

