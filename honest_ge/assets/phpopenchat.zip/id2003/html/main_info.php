<?//-*- C++ -*-
/*   ********************************************************************   **
**   Copyright (C) 1995-2000 Michael Oertel                                 **
**   Copyright (C) 2000-     PHPOpenChat Development Team                   **
**   http://www.ortelius.de/phpopenchat/                                    **
**                                                                          **
**   This program is free software. You can redistribute it and/or modify   **
**   it under the terms of the PHPOpenChat License Version 1.0              **
**                                                                          **
**   This program is distributed in the hope that it will be useful,        **
**   but WITHOUT ANY WARRANTY, without even the implied warranty of         **
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   **
**                                                                          **
**   You should have received a copy of the PHPOpenChat License             **
**   along with this program.                                               **
**   ********************************************************************   */

/* 
 * Include some default values
 */
include("defaults_inc.php");

/*
 * Open a database connection
 * The following include returns a database handle
 */
include ("connect_db_inc.php");
$db_handle=connect_db($DATABASEHOST,$DATABASEUSER,$DATABASEPASSWD);
if(!$db_handle){
  exit;
}
if($menu=="register"){
  $show_title = $REGISTER_TITLE;
  $show_info = $MAIN_INFO_REGISTER;
}
if($menu=="userprofile"){
  $show_title = $MY_PROFILE;
  $show_info = $MAIN_INFO_PROFILE;
}
if($menu=="chatmail"){
  $show_title = $CHATMAIL;
  $show_info = $MAIN_INFO_CHATMAIL;
}
if($menu=="invite"){
  $show_title = $IGNORE_INVITE;
  $show_info = $MAIN_INFO_INVITE;
}
if($menu=="friends"){
  $show_title = $NOTIFY;
  $show_info = $MAIN_INFO_FRIENDS;  
}
if($menu=="toplist"){
  $show_title = $TOPLIST;
  $show_info = $MAIN_INFO_TOPLIST;
}
if($menu=="whoisonline"){
  $show_title = $WHOISONLINE;
  $num = mysql_result(mysql_query("SELECT count(*) AS count FROM chat",$db_handle),0,"count");
  if ($num>0) {
    if ($num==1){
      $show_info = $WHOISONLINE_NUM_ONE.' ';
    }else{
      $show_info = $WHOISONLINE_NUM_MORE.' ';
    }
    $show_info .= '<STRONG>'.$num.'</STRONG> '.$WHOISONLINE_IN_CHAT.'&nbsp;';
    if($ENABLE_USERPAGES){
      $show_info .= '<font size="-2">'.$MAIN_INFO_CLICK_UP.'</font>';
    }
  }else{
    $show_info = $WHOISONLINE_NUM_MORE.' <STRONG>0</STRONG> '.$WHOISONLINE_IN_CHAT.'.';
  }
}
if($menu=="forum"){
  $show_title = $FORUM[title];
  $show_info = $MAIN_INFO_FORUM;
}
if($menu=="help"){
  $show_title = $HELP;
  $show_info = $MAIN_INFO_HELP;
}
if($menu=="forgotpwd"){
  $show_title = $FORGOTPWD;
  $show_info = $MAIN_INFO_FORGOTPWD;
}
?>

<HTML>
<HEAD>
<TITLE><?echo $CHATNAME?></TITLE>
<META NAME="distribution" CONTENT="global">
<META NAME="author" CONTENT="Andre Leitenberger; andre.leitenberger@gmx.net">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
td { font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #ffffff; }
-->
</style>
</HEAD>
<BODY bgcolor="#284628" link="#4a129f" alink="#4a129f" vlink="#4a129f" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td height="30" colspan="2" bgcolor="#000000" align="left">
      <font style="font-size: 16px; font-weight: bold;">&nbsp;<?echo $show_title?></font>
    </td>
  </tr>
  <tr>
    <td height="25" colspan="2" bgcolor="#555555" align="left">
      &nbsp;<?echo $show_info?></font>
    </td>
  </tr>
</table>
</BODY>
</HTML>

