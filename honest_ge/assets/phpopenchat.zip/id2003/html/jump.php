<?//-*- C++ -*-
/*   ********************************************************************   **
**   Copyright (C) 1995-2000 Michael Oertel                                 **
**   Copyright (C) 2000-     PHPOpenChat Development Team                   **
**   http://www.ortelius.de/phpopenchat/                                    **
**                                                                          **
**   This program is free software. You can redistribute it and/or modify   **
**   it under the terms of the PHPOpenChat License Version 1.0              **
**                                                                          **
**   This program is distributed in the hope that it will be useful,        **
**   but WITHOUT ANY WARRANTY, without even the implied warranty of         **
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   **
**                                                                          **
**   You should have received a copy of the PHPOpenChat License             **
**   along with this program.                                               **
**   ********************************************************************   */

/**
 * Include default values
 */
include ("defaults_inc.php");

function content_check($url){
  ereg("^http://(.[^/:]*):?([1234567890]*)(.*)",$url,$piece);
  $hostname = $piece[1];
  if(!$piece[2]){
    $port = 80;
  }else{
    $port = $piece[2];
  }
  if(!$piece[3]){
    $pfad = "/";
  }else{
    $pfad = $piece[3];
  }

  global $errortext;
  $fp=fsockopen($hostname,$port);
  if(!$fp){
    $errortext = "Host could not be found!";
    return false;
  }

  @fputs($fp,"GET $pfad HTTP/1.0\nUser-Agent: PHPOpenChat-Robot (http://www.ortelius.de/phpopenchat/)\nHost: $hostname\n\n");
  $header = @fgets($fp,128);
  if(eregi(" 40",$header)){
    $errortext = $header;
    return false;
  }
  while(!feof($fp)){
    $content .= fgets($fp,1024);
  }
  @fclose($fp);
  global $UNACCEPTABLE_CONTENT;

  if(eregi($UNACCEPTABLE_CONTENT,$content)){
    $errortext = 'Unacceptable content in target page found!';
    return false;
  }  

  return true;
}

$url=str_replace("jump.".$FILE_EXTENSION."?url=","",$REQUEST_URI);if ((strtolower(substr($url,0,4))!="http")&&(strtolower(substr($url,0,3))!="ftp")){
  $url="http://".$url;
}

if(!content_check($url)){
  echo "
<html>
  <head>
    <title>Error: $errortext</title>
  </head>
  <body>
    $errortext<br>
    <a href=\"#\" onClick=\"window.close();\">$CLOSE_WINDOW</a>
  </body>
</html>
";
  exit;
}

echo"
 <html><head>
  <title>Jump to $url</title>
  <meta http-equiv=\"Refresh\" content=\"0; url=$url\">
 </head>
  <body>
   <a href=\"$url\">$url</a><br>
  </body>
 </html>
";
?>
