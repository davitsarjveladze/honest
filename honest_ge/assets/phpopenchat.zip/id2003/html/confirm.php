<?
//script kiddies are sometimes crazy...let them sleep 2 seconds
sleep(2);

// this script checks if the code from registration-link is ok and aktivates the user
include ('defaults_inc.php');
//start session
if($ENABLE_SESSION){
  @session_start();
}

/*
 * Open a database connection
 * The following include returns a database handle
 */
include ('connect_db_inc.php');
$db_handle=connect_db($DATABASEHOST,$DATABASEUSER,$DATABASEPASSWD);
if(!$db_handle){
  exit;//the error message is printed in connect_db_inc.php
}
$result = mysql_query("select kicked from chat_data where Nick = '$user' limit 0,1",$db_handle);
if(mysql_result($result,'0','kicked') == -1){
  $salt_nick     = substr(md5($user.$pass_phrase),strlen($pass_phrase)%30,2);
  if(check_permissions($user,$code)){
    $result = mysql_query("update chat_data set kicked = 0 where Nick = '$user'",$db_handle);
    $link = 'index.'.$FILE_EXTENSION;
    include('confirm_success_tpl.php');
  }else{
    include('confirm_failed_tpl.php');
  }
}else{
  include('confirm_failed_tpl.php');
}
?>