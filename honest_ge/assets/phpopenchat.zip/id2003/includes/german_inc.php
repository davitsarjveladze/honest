<?
$LANG                   = 'de';

$YES = 'Ja';
$NO = 'Nein';

$MODERATOR_NAME       = 'Parkw�chter';
$TEAM_NAME          = 'Chat-Team';
$STATUSFILTERNAME     = 'Statusfilter';
$TWADDLEFILTERNAME    = 'Quasselfilter';
$WEEKDAY['Mon']         = 'Mo';
$WEEKDAY['Tue']         = 'Di';
$WEEKDAY['Wed']         = 'Mi';
$WEEKDAY['Thu']        = 'Do';
$WEEKDAY['Fri']        = 'Fr';
$WEEKDAY['Sat']        = 'Sa';
$WEEKDAY['Sun']        = 'So';
$CHANNEL                = 'Raum';
$WRONGFORM        = 'Falsches Eingabeformular!';
$READING_MSG        = 'liest Nachricht von';
$COME_FROM        = 'kommt aus';
$COME_FROM_PRIVAT    = 'kommt aus dem privaten Channel von';
$JOINING_IN        = 'nimmt teil';
$LEAVES_US        = 'verl��t uns';
$GOES_TO        = 'geht zu';
$NO_PARTICIPATE        = 'Doch nicht teilnehmen';
$NICK_NAME        = 'Spitzname';
$PASSWORD        = 'Kennwort';
$MAIL_ADDRESS        = 'E-Mailadresse';
$AGAIN            = 'nochmal';
$GO            = 'Los geht\'s!';
$FIRST_TIME_ONLY    = 'Nur beim ersten Mal';
$LEAVE_CHAT        = 'Chat verlassen';
$WISPER_TO        = 'fl�stere zu';
$SAY_TO            = 'sag zu';
$WISPERS_TO        = 'fl�stert zu';
$SAYS_TO        = 'sagt zu';
$SAY_IT            = 'sag es';
$SAYS		 = 'sagt';
$AUTOSCROLLING        = 'Autoscrolling';
$COLOR_CHANGE        = 'Farbwechsel von';
$OLD_COLOR        = 'alte Farbe';
$NEW_COLOR         = 'neue Farbe';
$HELP            = 'Hilfe';
$ALL            = 'allen';
$ON            = 'normal';
$ON1			= 'schnell';
$ON2			= 'sehr schnell';
$OFF            = 'aus';
$MESSAGES        = 'Nachrichten';
$CLOSE_WINDOW        = 'Fenster schlie�en';
$EDIT            = 'bearbeiten...';
$SEND_MSG        = 'Nachrichten hinterlassen';
$NICK_IS        = 'Dein Spitzname ist:';
$CHOOSE_LETTER        = 'W�hle einen Anfangsbuchstaben!';
$CLEAR            = 'Alles l�schen';
$UPDATE_TEXT        = 'Text aktualisieren';
$KICKED            = 'rausgeworfen';
$SOMEBODY        = 'Jemand';
$LOOKING_IN        = 'schaut zu';
$CHANGE_COLOR        = 'Farbe wechseln';
$ACCEPT_ROW        = 'akzeptiere text';
$MODERATOR_MESSAGE    = 'Nachricht an den Moderator';
$CHANNEL_EXPIRED    = 'Dieser Raum ist geschlossen.';
$CHANNEL_STARTS_AT    = 'N�chster Chat:';//Zeitangaben folgen
$CHANNEL_HINT        = 'Du befindest Dich im privaten Channel von ';
$INACTIVE        = 'Du warst zulange inaktiv! Bitte melde Dich erneut an.';
$UNLOCK_CHANNEL        = 'Raum �ffnen';
$SOMEBODY        = 'Jemand';
$REPLY_TO        = 'Antwort zu';
$IS_DISCHARGED        = 'ist nicht l�nger in meinen Channel eingeladen';
$IS_INVITED        = 'ist in meinen Channel eingeladen';
$ENTER_YOUR_CODE        = 'Benutze Deine eigene Farbe';
$HAS_CHANGED_COLOR      = 'hat die Farbe gewechselt';
$BANNED_MSG             = 'Du bist f�r ein paar Wochen gesperrt!';
$NOTIFY                 = 'Freunde';
$ADD_CHATTER            = 'Diesen Chatter zu meiner Liste aller Freunde hinzuf�gen!';
$LAST_LOGON             = 'zuletzt eingelogt';
$USERPROFILE            = 'Benutzerprofil';
$PWD_REPEATE            = 'Passwort wiederholen';
$HINT                   = 'Hinweis';
$HOST                   = 'Host';
$URL_FORMAT_HINT        = 'Bitte die Protokollangabe (http://) bei der URL nicht vergessen!';
$I_WANT_TO_CHAT         = 'Ich m�chte jetzt chatten';
$GREETINGS[1]           = 'Moin';
$GREETINGS[2]           = 'Mahlzeit';
$GREETINGS[3]           = 'Tach!';
$GREETINGS[4]           = 'N\'abend';
$GREETINGS[5]           = 'Wenn du nicht schlafen willst';
$NUM_USER               = 'Anzahl der schon registrierten Benutzer';
$CHATTERS_ONLINE        = 'Anzahl der Chatter';
$CHATTERS_ONLINE_24H    = 'Logins der letzten 24 Stunden';
$LOCAL_TIME             = 'Es ist jetzt';
$MY_PROFILE             = 'Mein Profil';
$FORGOT_PWD             = 'Du hast dein Kennwort vergessen?';
$TELL_US                = 'erz�hl uns was.';
$COME_IN                = 'komm\' rein.';
$WHATS_UP               = 'was ist los?';
$CHAT_WITH_US           = 'chatte mit uns!';
$IS_CHATTING_IN         = 'chattet im Raum';//a channel name follows
$NOT_ONLINE             = 'ist nicht eingeloggt.';//a nickname in front
$OPENED_TO_PUB		= 'wurde freigegeben';
$SEND_IMG		= 'Grafik abschicken';
$CHOOSE_IMG		= 'W�hle eine Grafikdatei';
$USER_ICON		= 'Dein Icon im Chat';
$NEW_IMG_HINT		= 'Falls Du Dein neues Icon nicht sehen kannst, l�sche den Cache Deines Browsers!';
$PWD_DONT_MATCH		= "Die Passw�rter stimmen nicht �berein!";
$MAX_FILE_EXCEEDED	= "Die Maximalgr��e der Datei wurde �berschritten! Die Dateigr��e darf nicht gr��er sein als";//a size in KByte follows
$MAX_SIZE_EXCEEDED	= "Die Maximalgr��e des Bildes wurde �berschritten!";
$HINT_IMG_SIZE		= "Die erlaubte maximal Gr��e ist ";//x,y values follows
$ALLOWED		= "erlaubt";
$MIME_ERROR		= "Falscher Dateityp! Erlaubt ist 'image/gif' aber Deine Datei ist vom Typ";//a type follows
$INVALID_NICK		= 'Dieser Spitzname ist nicht registriert!';
$NO_EMPTY_PWD		= 'Dein Passwort mu� mindestens ein Zeichen lang sein!';
$GODFATHER		= 'Pate';
$MSG_KICKED 		= "Du wurdest aus dem Chat verwiesen !";
$MSG_SEARCH 		= "Suchen";
$FLOODING_MSG1		= 'Das war das dritte mal, dass Du das Gleiche gesagt hast! Bitte versuche es doch mal mit einem normalen Gespr�ch.';
$FLOODING_MSG2		= 'Du hast zum wiederholten mal das Gleiche gesagagt, was aber nicht angezeigt wurde. Beim n�chsten mal wirst Du rausgeworfen!';
$NO_SCRIPT  = 'Bevor Du Dich einloggst must Du JavaScript (Im IE hei�t es "Active Scripting") anschalten!';

//PROFILE
$PROFILE_OPTIONAL = 'Weitere freiwillige Angaben f&uuml;r Deine Userpage';
$PROFIL_MOTTO = 'Dein Motto';
$PROFIL_INFO = 'Info �ber Dich';
$PROFIL_SHOW_EMAIL = 'Anderen Chattern meine Emailadresse zeigen';
$PROFIL_YES = 'Ja';
$PROFIL_NO = 'Nein';
$PROFIL_SHOW_FRIENDS = 'Anderen meine Chatfreunde zeigen';
$PROFIL_SHOW_BIRTHDATE = 'Mein Geburtsdatum zeigen';
$PROFIL_BIRTHDATE = 'Geburtsdatum';
$PROFIL_HOMEPAGE = 'Homepage';
$PROFIL_HOBBIES = 'Hobbies';
$PROFIL_GENDER = 'Geschlecht';
$PROFIL_MALE = 'M&auml;nnlich';
$PROFIL_FEMALE = 'Weiblich';
$PROFIL_HOME = 'Wohnort';
$PROFIL_ICQ = 'Meine ICQ-Nummer';
$PROFIL_PIC = 'Adresse zu meinem Bild';
$PROFIL_UPDATE_SUCCESS = 'Dein Profil wurde erfolgreich aktualisiert.';
$PROFIL_LOOKAT_UP = 'Userpage anschauen';
$PROFIL_BACK_TO = 'Zur�ck zum Profil';
$PROFIL_SAVE_CHANGES = '&Auml;nderungen speichern';

// -- Send Password to User --
$FORGOTPWD		= 'Passwort vergessen';
$MSG_SENDPWD        = 'Vergessenes Passwort per E-Mail zusenden';
$MSG_SENDPWD_SUCCESS = '<font color=green>Dein Passwort wurde erfolgreich an die E-Mail-Adresse geschickt, die Du beim Registrieren angegeben hast.</font>';
$MSG_SENDPWD_NONICK = '<font color=red>Der eingegebene Nickname wurde nicht gefunden !</font>';
$MSG_SENDPWD_NOEMAIL = '<font color=red>Dein Passwort konnte nicht verschickt werden, weil keine E-Mail-Adresse f�r Deinen Spitznamen gefunden werden konnte.</font>';
$MSG_SENDPWD_SUBJECT = 'Dein angefordertes Chatpasswort';
$MSG_SENDPWD_MSGTXT   = 'Hallo,'.nl.nl.'Dein Chatpasswort lautet: ';
$MSG_SENDPWD_SUBMIT = 'Absenden';
$MSG_SENDPWD_NICKNAME = 'Nickname : ';

// -- Invite & Ignore --
$IGNORE_INVITE = 'Einladen/Ignorieren';
$ALL_CHATTER = 'Alle Chatter';
$MSG_INVITE = 'Chatter einladen';
$MSG_IGNORE = 'Chatter ignorieren';
$MSG_INVITE_TITLE = 'Chatter in den eigenen Raum einladen';
$MSG_INVITE_LIST = 'Eingeladene Chatter';
$MSG_IGNORE_LIST = 'Ignorierte Chatter';
$MSG_IGNORE_NUMBER = 'Anzahl der Benutzer, die diesen Chatter auch ignorieren';
$MSG_IGNORE_ALSO = 'Anzahl der Benutzer, die diesen Benutzer auch ignorieren m�ssen, um ihn zu sperren';
$MSG_IGNORE_PATEN = 'Mit dem Ignorieren eines Chatters wird er gleichzeitig aus dem Chat geworfen.';

// -- Friends --
$MSG_FRIENDS_ADD = 'Freund hinzuf�gen';
$MSG_FRIENDS_ADD_TITLE = 'Chatter zu Freunden hinzuf�gen';
$MSG_FRIENDS_SEARCH = 'Suchen';
$MSG_FRIENDS_ADD_BUTTON = 'Hinzuf�gen';
$MSG_FRIENDS_FRIEND = 'Freund';
$MSG_FRIENDS_LAST_SEEN = 'Zuletzt gesehen';

// -- Toplist --
$TOPLIST                = 'Stammtisch';
$TOPLIST_HINT_PART1     = 'Alle Zeiten werden an jedem Monatsanfang halbiert, dadurch sitzen hier auch nur die aktuellen Stammchatter.';
$TOPLIST_HINT_PART2	= 'Solltest Du beim Chatten "Redepausen" von �ber f�nf Minuten einlegen, wird diese Zeit hier nicht addiert.';
$TOPLIST_HINT_PART3	= 'Hier alle Chatter, die noch nicht am Stammtisch sitzen:';
$MSG_TOPLIST_RANK       = 'Platz';
$MSG_TOPLIST_ONLINE_TIME = 'Online-Zeit';
$MSG_TOPLIST_LAST_SEEN  = 'Zuletzt gesehen...';
$MSG_TOPLIST_SHOW_30	= "Pl�tze 1 bis 30 anzeigen";
$MSG_TOPLIST_SHOW_100	= "Pl�tze 31 bis 100 anzeigen";

// -- Chatmail --
$CHATMAIL       = 'Chatmail';
$INBOX		= 'Nachrichteneingang';
$SENT_MAIL	= 'Gesendete Nachrichten';
$WRITE_MAIL	= 'Nachricht schreiben';
$SENDER		= 'Absender';
$RECEIPIENT	= 'Empf&auml;nger';
$SENT		= 'Gesendet';
$RECEIVED	= 'Empfangen';
$SUBJECT	= 'Betreff';
$MESSAGE	= 'Nachricht';
$NOSUBJECT	= 'Kein Betreff';
$SENDMAIL	= 'Mail senden';
$LEFT_THIS_MESSAGE    = 'hinterlie� diese Nachricht';
$FRIENDS_SUBJ	= 'Die letzten Logins Deiner Freunde...';
$WELCOME_SUBJ	= 'Registrierung erfolgreich...';
$WELCOME_MSG        = 'Hallo '.$nick.'! Du wurdest erfolgreich in die Chat-Community aufgenommen. Das '.$TEAM_NAME.' w�nscht Dir jetzt viel Spa� beim rumquatschen ;-) Wenn Du noch Fragen hast oder wissen m�chtest, wie man hier Icons einbindet, kannst Du auf den Hilfeknopf im Texteingabefenster unten klicken. CU :-)';
$NO_HIT         = 'Chatter wurde nicht gefunden...';
$MSG_SEND_TO	= 'Die Nachricht soll geschickt werden an:<br>(Der erste Buchstabe des Spitznamen gen�gt)';
$CHOOSE_NICK	= 'W�hle einen der gefundenen Spitznamen aus';
$NO_SELECTION   = 'Du hast vergessen einen Chatter auszuw�hlen.';
$SEND_SUCCESS	= 'Die Mail wurde erfolgreich versendet.';

// -- Who is online? --
$WHOISONLINE = 'Wer ist online?';
$WHOISONLINE_NUM_ONE = 'Zur Zeit befindet sich';
$WHOISONLINE_NUM_MORE = 'Zur Zeit befinden sich';
$WHOISONLINE_IN_CHAT = 'User im Chat.';
$WHOISONLINE_COLOR_RED = 'Rot';
$WHOISONLINE_COLOR_BLUE = 'Blau';

// -- START new Admin-module ---

$MSG_ADM_BACKTOCHAT        = 'zur�ck in den Chat';
$MSG_ADM_PAGETITLE        = 'Chat-Administration';
$MSG_ADM_CHANNELS        = 'Administration der Channel';
$MSG_ADM_OPERATORS    = 'Administration der Paten';
$MSG_ADM_COMODERATORS    = 'Administration der Co-Moderatoren';
$MSG_ADM_VIPS        = 'Administration von VIP/Moderatoren-Paaren';
$MSG_ADM_HINTS    = 'automatische Spr�che im Chat';
$MSG_ADM_FORUM       =  'Administration des Forums';

// channels
$MSG_ADM_CHANNELNAME ='Channelname';
$MSG_ADM_NEWCHANNEL = 'Neuen Channel anlegen';
$MSG_ADM_EDITCHANNEL = 'bearbeiten';
$MSG_ADM_DELETECHANNEL = 'l�schen';
$MSG_ADM_CHANNELS_CONFIRM_DEL = 'Soll dieser Channel wirklich gel�scht werden ?';

$MSG_ADM_CLEAR_LINES        = 'Zeilen l�schen';
$MSG_ADM_SAVE            = 'Daten speichern';

$MSG_ADM_CHANNELS_FIELDS['Name']    = 'Name des Channels';
$MSG_ADM_CHANNELS_FIELDS['PASSWORD']    = 'Kennwort';
$MSG_ADM_CHANNELS_FIELDS['These']    = 'These';
$MSG_ADM_CHANNELS_FIELDS['Teilnehmerzahl']='Maximale Teilnehmerzahl';
$MSG_ADM_CHANNELS_FIELDS['BG_Color']    = 'Hintergrundfarbe';
$MSG_ADM_CHANNELS_FIELDS['Logo']    = 'Pfad zur Grafikdatei des Channellogos';
$MSG_ADM_CHANNELS_FIELDS['ExitURL']    = 'Exit URL';
$MSG_ADM_CHANNELS_FIELDS['moderiert']= 'Channel moderieren';
$MSG_ADM_CHANNELS_FIELDS['starts_at']= 'der channel ist offen ab';
$MSG_ADM_CHANNELS_FIELDS['stops_at']    = 'der channel ist geschlossen ab';
$MSG_ADM_CHANNELS_FIELDS['NICK_COLOR']    = 'Farbe des Spitznamens';

$MSG_ADM_CHANNEL_ERROR_NAME = 'Bitte einen g�ltigen Namen f�r den Channel eingeben';
$MSG_ADM_CHANNEL_ERROR_BGCOLOR = 'Bitte eine g�ltige Hintergrundfarbe eingeben';
$MSG_ADM_CHANNEL_ERROR_NICKCOLOR = 'Bitte eine g�ltige Farbe f�r Nicknamen eingeben';
$MSG_ADM_CHANNEL_ERROR_LOGO = 'Bitte eine g�ltigen Path zum Channellogo eingeben';
$MSG_ADM_CHANNEL_ERROR_EXITURL = 'Bitte eine g�ltigen Path f�r die Exit-URL eingeben';
$MSG_ADM_CHANNEL_ERROR_SAMECOLOR = 'Die Hintergrundfarbe und die Farbe der Nicknamen d�rfen nicht gleich sein';
$MSG_ADM_CHANNEL_ERROR_YEAR = 'Das Jahr wurde nicht korrekt eingegeben';

// Operators
$MSG_ADM_OPERATORNAME ='Name des Paten';
$MSG_ADM_NEWOPERATOR = 'Neuen Paten anlegen';
$MSG_ADM_DELETEOPERATOR = 'l�schen';

$MSG_ADM_OPERATORS_ERROR_EMPTY = 'Das Eingabefeld darf nicht leer sein';
$MSG_ADM_OPERATORS_ERROR_NONICK = 'Es wurde kein Chatter mit diesem Namen gefunden !';

// VIP's
$MSG_ADM_VIPS_CREATE = 'Neues VIP / Moderator-Paar eintragen';
$MSG_ADM_VIPS_NICK = 'Nickname des VIP';
$MSG_ADM_VIPS_MODERATOR = 'Moderator';
$MSG_ADM_VIPS_CHANNEL = 'Channel';
$MSG_ADM_VIPS_DELETE = 'l�schen';

$MSG_ADM_VIPS_ERROR_MODERATOR1 = 'Das Feld Moderator darf nicht leer sein !';
$MSG_ADM_VIPS_ERROR_MODERATOR2 = 'Der Moderator muss ein registrierter Chatter sein !';
$MSG_ADM_VIPS_ERROR_VIP1 = 'Das Feld VIP darf nicht leer sein !';
$MSG_ADM_VIPS_ERROR_VIP2 = 'Dieser VIP ist bereits eingetragen !';

// co-moderators
$MSG_ADM_COMODERATORNAME ='Name des Co-Moderatoren';
$MSG_ADM_NEWCOMODERATOR = 'Neuen Co-Moderator anlegen';
$MSG_ADM_DELETECOMODERATOR = 'l�schen';

$MSG_ADM_COMODERATORS_ERROR_EMPTY = 'Das Eingabefeld darf nicht leer sein';
$MSG_ADM_COMODERATORS_ERROR_NONICK = 'Es wurde kein Chatter mit diesem Namen gefunden !';

// hints
$MSG_ADM_HINT = 'Spruch';
$MSG_ADM_HINTS_SAVE = 'Spr�che speichern';

// forum
$MSG_ADM_FORUM_ADDTOPIC = 'Neues Thema anlegen';
$MSG_ADM_FORUM_NAME = 'Name des Themas';
$MSG_ADM_FORUM_MSGCOUNT = 'Beitr�ge';
$MSG_ADM_FORUM_EDIT = 'bearbeiten';
$MSG_ADM_FORUM_DELETE = 'l�schen';
$MSG_ADM_FORUM_MESSAGES = 'Nachrichten bearbeiten';
$MSG_ADM_FORUM_INITMSG = 'initiale Nachricht';
$MSG_ADM_FORUM_INITMSG_TEXT ='Dieses Thema wurde neu er�ffnet !';
$MSG_ADM_FORUM_CONFIRM_DEL = 'Soll dieses Thema wirklich gel�scht werden ?';
$MSG_ADM_FORUM_MSG_CONFIRM_DEL = 'Soll diese Nachricht wirklich gel�scht werden ?';

$MSG_ADM_FORUM_ERROR_TOPIC = 'Bitte einen g�ltigen Namen f�r das neue Thema eingeben';
$MSG_ADM_FORUM_ERROR_INITMSG = 'Bitte eine initiale Nachricht f�r das neue Thema eingeben';
$MSG_ADM_FORUM_ERROR_NICK = 'Bitte einen g�ltigen Nicknamen eingeben';
$MSG_ADM_FORUM_ERROR_COMMENT = 'Das Kommentarfeld darf nicht leer sein';

$MSG_ADM_FORUM_DELWARNING = 'Warnung : Beim l�schen eines Themas gehen alle Nachrichten darin verloren ! ';
$MSG_ADM_FORUM_MSG_DELWARNING = 'Warnung : Beim l�schen der letzten Nachricht wird das gesamte Thema gel�scht !';

$MSG_ADM_FORUM_MSGID = 'Nachricht ID';
$MSG_ADM_FORUM_MSGRANGE = 'Nachrichten�bersicht';
$MSG_ADM_FORUM_MSGCOUNTER = 'Nr.';
$MSG_ADM_FORUM_NICK = 'Nickname';
$MSG_ADM_FORUM_DATE = 'Datum';
$MSG_ADM_FORUM_COMMENT = 'Kommentar';
$MSG_ADM_FORUM_EMAIL = 'Email';
$MSG_ADM_FORUM_HOMEPAGE = 'Homepage';

$MSG_ADM_FORUM_NAV = 'Navigation';
$MSG_ADM_FORUM_FROM = 'von';
$MSG_ADM_FORUM_FIRST = 'Anfang';
$MSG_ADM_FORUM_LAST = 'Ende';
$MSG_ADM_FORUM_NEXT = 'vor';
$MSG_ADM_FORUM_PREV = 'zur�ck';

$MSG_ADM_FORUM_EDITMSG = 'Nachricht bearbeiten';
$MSG_ADM_FORUM_BACKTOLIST = 'Zur�ck zur Nachrichtenliste';

// Chatmail to all users
$MSG_ADM_MAILALL = 'Rundschreiben an Chatter';
$MSG_ADM_MAILALL_NEWMAIL = 'Neues Rundschreiben erstellen';
$MSG_ADM_MAILALL_SHOW = 'anzeigen';
$MSG_ADM_MAILALL_OLDMAILS = 'Bisherige Nachrichten :';
$MSG_ADM_MAILALL_SUBJECT = 'Betreff';
$MSG_ADM_MAILALL_DATE = 'Datum';
$MSG_ADM_MAILALL_BODY = 'Nachricht';
$MSG_ADM_MAILALL_DELETE = 'l�schen';
$MSG_ADM_MAILALL_SEND = 'Nachricht senden';
$MSG_ADM_MAILALL_REFRESH = 'Inhalt l�schen';
$MSG_ADM_MAILALL_ERROR_BODY = 'Das Feld Nachricht darf nicht leer sein';
$MSG_ADM_MAILALL_ERROR_SUBJECT = 'Das Feld Betreff darf nicht leer sein';
$MSG_ADM_MAILALL_CONFIRM_DEL = 'Soll diese Nachricht wirklich gel�scht werden ?';
$MSG_ADM_MAILALL_BACK = 'Zur�ck zur �bersicht';

$MSG_ADM_MAILALL_RECIEVER = 'Emf�nger';
$MSG_ADM_MAILALL_ALLUSERS = 'Alle registrierten Chatter';
$MSG_ADM_MAILALL_OPERATORS = 'Alle Paten';
$MSG_ADM_MAILALL_COMODERATORS = 'Alle Co-Moderatoren';

// -- END new Admin-module ---

/*
** Admin-Tool
*/
$BACK_TO_CHAT        = 'zur�ck in den Chat';
$CHAT_SETUP        = 'Chat-Administration';
$AUTOMATIC_HINTS    = 'automatische Spr�che im Chat';
$SETUP_CHANNELS        = 'Administration der Channels';
$SETUP_MODERATORS    = 'Administration der Paten';
$SETUP_COMODERATORS    = 'Administration der Co-Moderatoren';
$SETUP_VIPS        = 'Administration der VIPs';
$SETUP_FORUM       =  'Administration des Forums';
$SAVE_HINTS        = 'Spr�che speichern';
$CREATE_CHANNEL        = 'Neuen Channel anlegen';
$MODERATORS        = 'Moderatoren';
$GODFATHERS             = 'Paten';
$MODERATOR        = 'Moderator';
$COMODERATORS        = 'Co-Moderatoren';
$VIPS            = 'VIPs';
$VIP            = 'VIP';
$ADD_REMOVE        = 'Hinzuf�gen/L�schen';
$SAVE            = 'save';
$CLEAR_LINES        = 'clear all lines in channel';
$CHAT_OVERLOAD        = 'Leider ist der Chat zur Zeit �berlastet. Der Chatadmin ist bereits per Email benachrichtigt worden.';
$REPEAT_LOGIN        = 'Versuche Dich bitte neu einzulogen.';
$FEHLER            = 'Fehler';
$ERRORMAIL_SUBJECT ='fehler bei der datenbankverbindung';
$ERRORMAIL_BODY    ="der chat konnte sich nicht mit der datenbank verbinden.\nl&auml;uft der chat bereits und ist unter hoher last, scheint der server an seien kapazit&auml;tsgrenze gesto&szlig;en zu sein. evtl. mu&szlig; er erweitert werden.\n\nHandelt es sich im eine neuinstallation, ist vermutlich der verbindung nicht zustande gekommen, weil die konfiguration noch nicht stimmt. bitte &uuml;berpr&uuml;fen sie die einstellungen f&uuml;r host, databaseuser, dataabsepassword in der default_inc.php. pr&uuml;fen sie auch, ob sie sich nicht verschrieben oder ein leerzeichen versehentlich eingef&uuml;gt haben. pr&uuml;fen sie, ob die datenbank korrekt installiert wurde. beim installieren per phpMyAdmin schl&auml;gt dei installation oft fehl. ";
$BEGIN                  = 'Zur&uuml;ck zum Anfang';
$ANSWER                 = 'Antworten';
$DELETE                 = 'L&ouml;schen';
$WROTE                  = 'schrieb';

$TBL_FIELDS['Id']    = '';
$TBL_FIELDS['Name']    = 'Name des Channels';
$TBL_FIELDS['PASSWORD']    = 'Kennwort';
$TBL_FIELDS['These']    = 'These';
$TBL_FIELDS['Teilnehmerzahl']='Maximale Teilnehmerzahl';    
$TBL_FIELDS['BG_Color']    = 'Hintergrundfarbe';
$TBL_FIELDS['Logo']    = 'Pfad zur Grafikdatei des Channellogos';
$TBL_FIELDS['ExitURL']    = 'Exit URL';
$TBL_FIELDS['moderiert']= 'Moderation? [1=yes/0=no]';
$TBL_FIELDS['starts_at']= 'der channel ist offen ab';
$TBL_FIELDS['stops_at']    = 'der channel ist geschlossen ab';
$TBL_FIELDS['NICK_COLOR']    = 'Farbe des Spitznamens';

/*
 * login and registration messages
 */
$message['session_name']='Kann Session nicht registrieren.';
$message['error_1']='Der Spitzname ist schon vergeben oder nimmt bereits teil.<BR>';
$message['error_default']='Teilnahme nicht moeglich';
$message['error_2']='Teilnahme verweigert! Das Kennwort ist falsch.';
$message['error_3']='Die Kennw�rter stimmen nicht �berein. Bitte wiederholen!';
$message['error_4']='Bitte Emailadresse eingeben!';
$message['error_5']='Dein Spitzname enth�lt unerw�nschte Begriffe!';
$message['error_6']='Der Spitzname enth�lt ung�ltige Zeichen';
$message['error_7']='Maximalzahl der Benutzer wurde erreicht.<BR>Bitte versuch\'s sp�ter nocheinmal oder w�hle einen anderen Channel.';
$message['error_8']='Es wurde ein falsches Format des Farbcodes festgestellt.';
$message['error_9'] = 'Nickname ist noch nicht freigegeben';
$REGISTER_NICK = 'ich m�chte meinen Nick registrieren';
$REGISTER_TITLE = 'Registrierung';
$REGISTER_SUBMIT = 'registrieren';
$REGISTER_SUCCESS_1 = 'Registrierung erfolgreich. <br>Jetzt melde Dich auf unserer ';
$REGISTER_SUCCESS_2 = ' Hauptseite</a>, mit deinem Nick und deinem Passwort an, um gleich zu los zu chatten.';

/*
 * Forum-Messages
 */
$FORUM['title']             = 'Pinnwand';
$FORUM['save_message']      = 'Dein Eintrag wurde gespeichert.';
$FORUM['save_message_empty']= 'Dein leerer Eintrag wurde nicht gespeichert.';
$FORUM['save_nickname']     = '(Spitz-)name: ';
$FORUM['save_email']        = 'email:';
$FORUM['save_homepage']     = 'Homepage:';
$FORUM['save_comment']      = 'Kommentar:';
$FORUM['save_topic']        = 'zum Thema ';
$FORUM['our_topics']        = 'Unsere Themen';
$FORUM['save_next']         = 'weiter im ';
$FORUM['save_read']         = 'lesen!';
$FORUM['write']             = 'Einen Beitrag schreiben';
$FORUM['write_header']      = 'Hier kannst Du einen neuen Eintrag in das Forum schreiben.';
$FORUM['write_topic']       = 'Thema: ';
$FORUM['write_comment']     = 'Dein Kommentar:';
$FORUM['write_submit']      = 'Eintragen';
$FORUM['no_frame']          = 'Leider unterstuetzt Dein Browser keine Frames. Dadurch kannst Du keine Foren sehen.';
$FORUM['back_to']           = 'zur�ck zum';
$FORUM['article_list']      = 'Liste aller Beitr�ge';
$FORUM['left_theme']        = 'Thema';
$FORUM['left_refresh']      = 'Aktualisieren';
$FORUM['welcome']             = '        <H3>Klicke links auf die aufgelisteten Themen, um eine �bersicht �ber die schon geschriebenen Beitr�ge
                                zu erhalten. Klicke dann auf einen (Spitz-)namen zum Lesen eines Beitrags.</H3>
                                Die neuesten Beitr�ge stehen oben.<BR>
                                Viel Spa�!';

$FORUM['wrote']             = 'schrieb';
$FORUM['meeting']           = 'Meeting';
$FORUM['technology']        = 'Technik';
$FORUM['babble_topic']      = 'Laberforum';
$FORUM['newbees']           = 'Newbees';
$FORUM['all_themes']    = ' Themenliste';
$FORUM['subject']    = 'Betreff';

// confirmation page
$CONFIRMATION_TITLE = 'Registrierung abschlie�en';
$CONFIRMATION_OK_1 = 'Gl�ckwunsch! Du wurdest erfolgreich in unsere Community aufgenommen. <br>Klick gleich';
$CONFIRMATION_OK_2 = 'hier um Dich einzuloggen!</a><br>Viel Spa�!';
$CONFIRMATION_FAILED = 'Leider konnten wir deine Anmeldung nicht best�tigen. Versuche es erneut. <br> Bei manchen Emailprogrammen ist es notwendig, den Link mit Hilfe der Maus zu kopieren. Viel Erfolg!';

// Operator-Interface
$MSG_OP_TITLE = 'Paten-Funktion';
$MSG_OP_DESCRIPTION = 'W�hle einen Chatter aus, der herausgeworfen werden soll :';
$MSG_OP_INFO = '<b><u>Information :</u></b>';
$MSG_OP_KICKBUTTON = 'kicken';
$MSG_OP_INFOBUTTON = 'Info';
$MSG_OP_PERMANENT = 'Chatter dauerhaft rauswerfen';

$MSG_OP_INFOTEXT_GENERAL  = 'Paten k�nnen nicht rausgeworfen werden, und sind deshalb nicht in dieser Liste aufgef�hrt !';
$MSG_OP_INFOTEXT_GENERAL .= '<br><br>Das dauerhafte herauswerfen eines Chatters bitte nur im Notfall ausf�hren.';
$MSG_OP_INFOTEXT_GENERAL .= '<br><br>Hinweise zum hinauswerfen von Chattern ist der Paten-FAQ zu entnehmen.';

$MSG_OP_INFOTEXT_INFOABOUT  = "Information �ber ";
$MSG_OP_INFOTEXT_KICKSSOFAR .= "bisherige Rausw�rfe :";
$MSG_OP_INFOTEXT_KICKCOUNT .= "Rausw�rfe insgesamt :";
$MSG_OP_INFOTEXT_KICKTIME ="Neue Sperrzeit (Minuten) :"; 
$MSG_OP_INFOTEXT_NEXTKICKTIME ="Sperrzeit beim n�chsten Rauswurf (Minuten) :"; 
$MSG_OP_INFOTEXT_KICKED = "wurde herausgeworfen !";
$MSG_OP_INFOTEXT_ALREADYKICKED = "wurde bereits von einem anderen Paten herausgeworfen !";

//userpage
$UP_FROM = 'Userpage von';
$UP_UNKNOWN_USER = 'Diesen Namen kenne ich nicht';
$UP_TOPLISTPLACE = 'Stammtischplatz';
$UP_INFO = 'Infos �ber mich';
$UP_SEX = 'Geschlecht';
$UP_HOBBY = 'Meine Hobbies';
$UP_BIRTHDATE = 'Geburtsdatum';
$UP_AGE = 'Alter';
$UP_HOME = 'Wohnort';
$UP_FRIENDS = 'Meine Freunde im';
$UP_GB_ERROR = 'Du musst mindestens einen Text eingeben';
$UP_GB_SAVED = 'Dein Eintrag wurde im G�stebuch gespeichert';
$UP_GB_BACK = 'Zur�ck zum G�stebuch';
$UP_GB_SIGNHERE = 'Hier kannst du dich ins G�stebuch eintragen';
$UP_GB_NOTLOGGEDIN = 'Um einen eigenen Eintrag zu machen, mu�t Du Dich in den Chat einloggen';
$UP_GB_MSGCOUNT = 'Anzahl aller Eintr�ge';
$UP_GB_MOVE = 'Im G�stebuch bl�ttern';
$UP_GB_WROTE = 'schrieb am';
$UP_GB_CONFIRM_DELETE = 'wirklich l&ouml;schen?';
$UP_GB_ENTRY = 'Eintragung ins G�stebuch';
$UP_GB_COMMENT = 'Kommentar';
$UP_GB_DOIT = 'Eintragen';
$UP_GB_DELETE = 'l&ouml;schen';

//main menu
$MAIN_INFO_REGISTER = 'Hier kannst du dir deinen Namen im Chat registrieren.';
$MAIN_INFO_PROFILE = 'Pers�nliche Daten �ndern und Userpage einrichten.';
$MAIN_INFO_CHATMAIL = 'Nachrichten innerhalb des Chats empfangen und versenden.';
$MAIN_INFO_INVITE = 'Chatter in den eigenen Raum einladen oder ignorieren.';
$MAIN_INFO_FRIENDS = 'Chatter zu deinen Freunden hinzuf�gen.';
$MAIN_INFO_TOPLIST = 'Rangliste der Chatter, die zur Zeit am meisten im Chat sind.';
$MAIN_INFO_CLICK_UP = 'Klick auf einen Namen um die Userpage zu sehen.';
$MAIN_INFO_FORUM = 'Im Forum kannst du �ber allgemeine Themen diskutieren.';
$MAIN_INFO_HELP = 'Hier findest du viele n�tzliche Informationen zum Chat.';
$MAIN_INFO_FORGOTPWD = 'Hier kannst du dir dein Passwort per E-Mail zusenden lassen.';
?>
