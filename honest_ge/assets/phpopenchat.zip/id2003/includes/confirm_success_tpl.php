<HTML>
    <HEAD>
      <TITLE><?=$CONFIRMATION_TITLE?></TITLE>
    </HEAD>
    <body bgcolor="#FFFFFF" BACKGROUND="<?echo$BACKGROUNDIMAGE?>" text="#000000" link="#007b39" vlink="#007b39">
      <div align="center">

        <table cellSpacing="0" cellPadding="0" border="0" width="80%">
          <tr>
            <td>
              <!-- start table -->


              <table cellSpacing="0" cellPadding="1" border="0">
                <tr>
                  <td width="100%" bgColor="#468e31">


                    <TABLE cellSpacing="0" cellPadding="4" border="0">
                      <tr>
                        <td background="images/bg.gif" align="center">
                          <font size="+1">
                            <b><?=$CONFIRMATION_TITLE?>
                            </b>
                          </font>
                        </td>
                      </tr>
                      <tr>
                        <td bgColor="#ffffff" align="center">
                          <img src="images/leer.gif" alt="" width="480" height="1" border="0"><BR>
                              <font face="arial,helvetica,sans-serif" size="4" color="#000000"></font><br><br>


                                        <?=$CONFIRMATION_OK_1?><a href="<?=$link?>"><?=$CONFIRMATION_OK_2?>

                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
              <!-- end table -->
              
            </td>
          </tr>
        </table>
              
      </div>
    </BODY>
</HTML>