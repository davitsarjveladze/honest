<?php

function send_mail($to,$subject,$body){
  global $CHATNAME, $TEAM_MAIL_ADDR;
  mail($to,$subject,$body,"From: $CHATNAME <$TEAM_MAIL_ADDR>");
 }
?>
