<?

// Written by:
// PHPOpenChat Version: 2.x

$LANG                   = '';

$YES                    = '';
$NO                     = '';
$MODERATOR_NAME         = '';
$TEAM_NAME              = '';
$STATUSFILTERNAME       = '';
$TWADDLEFILTERNAME      = '';
$WEEKDAY['Mon']         = '';
$WEEKDAY['Tue']         = '';
$WEEKDAY['Wed']         = '';
$WEEKDAY['Thu']         = '';
$WEEKDAY['Fri']         = '';
$WEEKDAY['Sat']         = '';
$WEEKDAY['Sun']         = '';
$CHANNEL                = '';
$WRONGFORM              = '';
$READING_MSG            = '';
$COME_FROM              = '';
$COME_FROM_PRIVAT       = '';
$JOINING_IN             = '';
$LEAVES_US              = '';
$GOES_TO                = '';
$NO_PARTICIPATE         = '';
$NICK_NAME              = '';
$PASSWORD               = '';
$MAIL_ADDRESS           = '';
$AGAIN                  = '';
$GO                     = '';
$FIRST_TIME_ONLY        = '';
$LEAVE_CHAT             = '';
$WISPER_TO              = '';
$SAY_TO                 = '';
$WISPERS_TO             = '';
$SAYS_TO                = '';
$SAY_IT                 = '';
$SAYS			              = '';
$AUTOSCROLLING          = '';
$COLOR_CHANGE           = '';
$OLD_COLOR              = '';
$NEW_COLOR              = '';
$HELP                   = '';
$ALL                    = '';
$ON			                = '';
$ON1			              = '';
$ON2			              = '';
$OFF                    = '';
$MESSAGES               = '';
$CLOSE_WINDOW           = '';
$EDIT                   = '';
$SEND_MSG               = '';
$NICK_IS                = '';
$CHOOSE_LETTER          = '';
$CLEAR                  = '';
$UPDATE_TEXT            = '';
$KICKED                 = '';
$SOMEBODY               = '';
$LOOKING_IN             = '';
$CHANGE_COLOR           = '';
$ACCEPT_ROW             = '';
$MODERATOR_MESSAGE      = '';
$CHANNEL_EXPIRED        = '';
$CHANNEL_STARTS_AT      = '';//Zeitangaben folgen
$CHANNEL_HINT           = '';//nick name follows
$INACTIVE               = '';
$UNLOCK_CHANNEL         = '';
$SOMEBODY               = '';
$REPLY_TO               = '';
$IS_DISCHARGED          = '';
$IS_INVITED             = '';
$ENTER_YOUR_CODE        = '';
$HAS_CHANGED_COLOR      = '';
$BANNED_MSG             = '';
$NOTIFY                 = '';
$ADD_CHATTER            = '';
$LAST_LOGON             = '';
$USERPROFILE            = '';
$PWD_REPEATE            = '';
$HINT                   = '';
$HOST                   = '';
$URL_FORMAT_HINT        = '';
$I_WANT_TO_CHAT         = '';
$GREETINGS[1]           = '';
$GREETINGS[2]           = '';
$GREETINGS[3]           = '';
$GREETINGS[4]           = '';
$GREETINGS[5]           = '';
$NUM_USER               = '';
$CHATTERS_ONLINE        = '';
$CHATTERS_ONLINE_24H    = '';
$LOCAL_TIME             = '';
$MY_PROFILE             = '';
$FORGOT_PWD             = '';
$TELL_US                = '';
$COME_IN                = '';
$WHATS_UP               = '';
$CHAT_WITH_US           = '';
$IS_CHATTING_IN         = '';//a channel name follows
$NOT_ONLINE             = '';//a nickname in front
$OPENED_TO_PUB          = '';
$BEGIN                  = '';
$ANSWER                 = '';
$DELETE                 = '';
$WROTE                  = '';
$SEND_IMG		            = '';
$CHOOSE_IMG		          = '';
$USER_ICON		          = '';
$NEW_IMG_HINT		        = '';
$PWD_DONT_MATCH		      = '';
$MAX_FILE_EXCEEDED	    = '';//a size follows
$MAX_SIZE_EXCEEDED	    = '';
$HINT_IMG_SIZE		      = '';//x,y values follows
$ALLOWED		            = '';
$MIME_ERROR		          = '';//a type follows
$INVALID_NICK		        = '';
$NO_EMPTY_PWD		        = '';
$GODFATHER		          = '';
$MSG_KICKED 		        = '';
$MSG_SEARCH 		        = '';
$FLOODING_MSG1		      = '';
$FLOODING_MSG2		      = '';
$NO_SCRIPT              = '';

$LAST_REGISTERED_USER   = '';
$TOTAL_POSTS            = '';
$NUM_POSTS              = '';
$NEW_POSTS_LAST_24H     = '';
$LAST_POST              = '';
$TOTAL_MAILS            = '';
$NUM_MAILS              = '';
$NEW_MAILS_LAST_24H     = '';

// send password to user
$MSG_SENDPWD            = '';
$MSG_SENDPWD_SUCCESS    = '';
$MSG_SENDPWD_NONICK     = '';
$MSG_SENDPWD_NOEMAIL    = '';
$MSG_SENDPWD_SUBJECT    = '';
$MSG_SENDPWD_MSGTXT     = '';
$MSG_SENDPWD_SUBMIT     = '';
$MSG_SENDPWD_NICKNAME   = '';

// -- Invite & Ignore --
$IGNORE_INVITE          = '';
$ALL_CHATTER            = '';
$MSG_INVITE             = '';
$MSG_IGNORE             = '';
$MSG_INVITE_TITLE       = '';
$MSG_INVITE_LIST        = '';
$MSG_IGNORE_LIST        = '';
$MSG_IGNORE_NUMBER      = '';
$MSG_IGNORE_ALSO        = '';
$MSG_IGNORE_PATEN       = '';

// -- Friends --
$MSG_FRIENDS            = '';
$MSG_FRIENDS_ADD        = '';
$MSG_FRIENDS_ADD_TITLE  = '';
$MSG_FRIENDS_SEARCH     = '';
$MSG_FRIENDS_ADD_BUTTON = '';
$MSG_FRIENDS_FRIEND     = '';
$MSG_FRIENDS_LAST_SEEN  = '';
$MSG_FRIENDS_TIME       = '';

// -- Toplist --
$TOPLIST                = '';
$TOPLIST_HINT_PART1     = '';
$TOPLIST_HINT_PART2	    = '';
$TOPLIST_HINT_PART3	    = '';
$MSG_TOPLIST_RANK       = '';
$MSG_TOPLIST_ONLINE_TIME= '';
$MSG_TOPLIST_LAST_SEEN  = '';
$MSG_TOPLIST_SHOW_30	  = '';
$MSG_TOPLIST_SHOW_100	  = '';

// -- Chatmail --
$CHATMAIL               = '';
$INBOX		              = '';
$SENT_MAIL	            = '';
$WRITE_MAIL	            = '';
$SENDER		              = '';
$RECEIPIENT	            = '';
$SENT	 	                = '';
$RECEIVED	              = '';
$SUBJECT	              = '';
$MESSAGE	              = '';
$NOSUBJECT	            = '';
$SENDMAIL	              = '';
$MESSAGE_TO             = '';
$LEFT_THIS_MESSAGE      = '';
$FRIENDS_SUBJ	          = '';
$WELCOME_SUBJ	          = '';
$WELCOME_MSG            = '';
$NO_HIT                 = '';
$MSG_SEND_TO	          = '';//a nickname follows
$CHOOSE_NICK	          = '';
$NO_SELECTION           = '';
$SEND_SUCCESS	          = '';

// -- Who is online? --
$WHOISONLINE            = '';
$WHOISONLINE_NUM_ONE    = '';
$WHOISONLINE_NUM_MORE   = '';
$WHOISONLINE_IN_CHAT    = '';
$WHOISONLINE_COLOR_RED  = '';
$WHOISONLINE_COLOR_BLUE = '';

// -- START new Admin-module ---

$MSG_ADM_BACKTOCHAT     = '';
$MSG_ADM_PAGETITLE      = '';
$MSG_ADM_CHANNELS       = '';
$MSG_ADM_OPERATORS      = '';
$MSG_ADM_COMODERATORS   = '';
$MSG_ADM_VIPS           = '';
$MSG_ADM_HINTS          = '';
$MSG_ADM_FORUM          = '';

// channels
$MSG_ADM_CHANNELNAME    = '';
$MSG_ADM_NEWCHANNEL     = '';
$MSG_ADM_EDITCHANNEL    = '';
$MSG_ADM_DELETECHANNEL  = '';
$MSG_ADM_CHANNELS_CONFIRM_DEL = '';

$MSG_ADM_CLEAR_LINES    = '';
$MSG_ADM_SAVE           = '';

$MSG_ADM_CHANNELS_FIELDS['Name'] = '';
$MSG_ADM_CHANNELS_FIELDS['PASSWORD'] = '';
$MSG_ADM_CHANNELS_FIELDS['These'] = '';
$MSG_ADM_CHANNELS_FIELDS['Teilnehmerzahl'] = '';
$MSG_ADM_CHANNELS_FIELDS['BG_Color'] = '';
$MSG_ADM_CHANNELS_FIELDS['Logo'] = '';
$MSG_ADM_CHANNELS_FIELDS['ExitURL'] = '';
$MSG_ADM_CHANNELS_FIELDS['moderiert'] = '';
$MSG_ADM_CHANNELS_FIELDS['starts_at'] = '';
$MSG_ADM_CHANNELS_FIELDS['stops_at'] = '';
$MSG_ADM_CHANNELS_FIELDS['NICK_COLOR'] = '';

$MSG_ADM_CHANNEL_ERROR_NAME = '';
$MSG_ADM_CHANNEL_ERROR_BGCOLOR = '';
$MSG_ADM_CHANNEL_ERROR_NICKCOLOR = '';
$MSG_ADM_CHANNEL_ERROR_LOGO = '';
$MSG_ADM_CHANNEL_ERROR_EXITURL = '';
$MSG_ADM_CHANNEL_ERROR_SAMECOLOR = '';
$MSG_ADM_CHANNEL_ERROR_YEAR = '';

// Operators
$MSG_ADM_OPERATORNAME   = '';
$MSG_ADM_NEWOPERATOR    = '';
$MSG_ADM_DELETEOPERATOR = '';

$MSG_ADM_OPERATORS_ERROR_EMPTY = '';
$MSG_ADM_OPERATORS_ERROR_NONICK = '';

// VIP's
$MSG_ADM_VIPS_CREATE    = '';
$MSG_ADM_VIPS_NICK      = '';
$MSG_ADM_VIPS_MODERATOR = '';
$MSG_ADM_VIPS_CHANNEL   = '';
$MSG_ADM_VIPS_DELETE    = '';

$MSG_ADM_VIPS_ERROR_MODERATOR1 = '';
$MSG_ADM_VIPS_ERROR_MODERATOR2 = '';
$MSG_ADM_VIPS_ERROR_VIP1 = '';
$MSG_ADM_VIPS_ERROR_VIP2 = '';

// co-moderators
$MSG_ADM_COMODERATORNAME= '';
$MSG_ADM_NEWCOMODERATOR = '';
$MSG_ADM_DELETECOMODERATOR = '';
$MSG_ADM_COMODERATORS_ERROR_EMPTY = '';
$MSG_ADM_COMODERATORS_ERROR_NONICK = '';

// hints
$MSG_ADM_HINT           = '';
$MSG_ADM_HINTS_SAVE     = '';

// forum
$MSG_ADM_FORUM_ADDTOPIC = '';
$MSG_ADM_FORUM_NAME     = '';
$MSG_ADM_FORUM_MSGCOUNT = '';
$MSG_ADM_FORUM_EDIT     = '';
$MSG_ADM_FORUM_DELETE   = '';
$MSG_ADM_FORUM_MESSAGES = '';
$MSG_ADM_FORUM_INITMSG  = '';
$MSG_ADM_FORUM_INITMSG_TEXT = '';
$MSG_ADM_FORUM_CONFIRM_DEL = '';
$MSG_ADM_FORUM_MSG_CONFIRM_DEL = '';

$MSG_ADM_FORUM_ERROR_TOPIC = '';
$MSG_ADM_FORUM_ERROR_INITMSG = '';
$MSG_ADM_FORUM_ERROR_NICK = '';
$MSG_ADM_FORUM_ERROR_COMMENT = '';

$MSG_ADM_FORUM_DELWARNING = '';
$MSG_ADM_FORUM_MSG_DELWARNING = '';

$MSG_ADM_FORUM_MSGID    = '';
$MSG_ADM_FORUM_MSGRANGE = '';
$MSG_ADM_FORUM_MSGCOUNTER = '';
$MSG_ADM_FORUM_NICK     = '';
$MSG_ADM_FORUM_DATE     = '';
$MSG_ADM_FORUM_COMMENT  = '';
$MSG_ADM_FORUM_EMAIL    = '';
$MSG_ADM_FORUM_HOMEPAGE = '';

$MSG_ADM_FORUM_NAV      = '';
$MSG_ADM_FORUM_FROM     = '';
$MSG_ADM_FORUM_FIRST    = '';
$MSG_ADM_FORUM_LAST     = '';
$MSG_ADM_FORUM_NEXT     = '';
$MSG_ADM_FORUM_PREV     = '';

$MSG_ADM_FORUM_EDITMSG  = '';
$MSG_ADM_FORUM_BACKTOLIST = '';

// Chatmail to all users
$MSG_ADM_MAILALL        = '';
$MSG_ADM_MAILALL_NEWMAIL= '';
$MSG_ADM_MAILALL_OLDMAILS = '';
$MSG_ADM_MAILALL_SUBJECT= '';
$MSG_ADM_MAILALL_DATE   = '';
$MSG_ADM_MAILALL_BODY   = '';
$MSG_ADM_MAILALL_DELETE = '';
$MSG_ADM_MAILALL_SEND   = '';
$MSG_ADM_MAILALL_REFRESH= '';
$MSG_ADM_MAILALL_ERROR_BODY = '';
$MSG_ADM_MAILALL_ERROR_SUBJECT = '';
$MSG_ADM_MAILALL_CONFIRM_DEL = '';
$MSG_ADM_MAILALL_SHOW   = '';
$MSG_ADM_MAILALL_BACK   = '';

$MSG_ADM_MAILALL_RECIEVER = '';
$MSG_ADM_MAILALL_ALLUSERS = '';
$MSG_ADM_MAILALL_OPERATORS = '';
$MSG_ADM_MAILALL_COMODERATORS = '';

// -- END new Admin-module ---

/*
** Admin-Tool
*/
$BACK_TO_CHAT           = '';
$CHAT_SETUP             = '';
$AUTOMATIC_HINTS        = '';
$SETUP_CHANNELS         = '';
$SETUP_MODERATORS       = '';
$SETUP_COMODERATORS     = '';
$SETUP_VIPS             = '';
$SETUP_FORUM            = '';
$SAVE_HINTS             = '';
$CREATE_CHANNEL         = '';
$MODERATORS             = '';
$GODFATHERS             = '';
$MODERATOR              = '';
$COMODERATORS           = '';
$VIPS                   = '';
$VIP                    = '';
$ADD_REMOVE             = '';
$SAVE                   = '';
$CLEAR_LINES            = '';
$CHAT_OVERLOAD          = '';
$REPEAT_LOGIN           = '';
$FEHLER                 = '';
$ERRORMAIL_SUBJECT 		  = '';
$ERRORMAIL_BODY    		  = '';

$TBL_FIELDS['Id']       = '';
$TBL_FIELDS['Name']     = '';
$TBL_FIELDS['PASSWORD'] = '';
$TBL_FIELDS['These']    = '';
$TBL_FIELDS['Teilnehmerzahl']= '';      
$TBL_FIELDS['BG_Color'] = '';
$TBL_FIELDS['Logo']     = '';
$TBL_FIELDS['ExitURL']  = '';
$TBL_FIELDS['moderiert']= '';
$TBL_FIELDS['starts_at']= '';
$TBL_FIELDS['stops_at'] = '';
$TBL_FIELDS['NICK_COLOR']= '';

/*
 * login and registration messages
 */
$message[session_name]  = '';
$message[error_1]       = '';
$message[error_default] = '';
$message[error_2]       = '';
$message[error_3]       = '';
$message[error_4]       = '';
$message[error_5]       = '';
$message[error_6]       = '';
$message[error_7]       = '';
$message[error_8]       = '';
$REGISTER_NICK          = '';
$REGISTER_TITLE         = '';
$REGISTER_SUBMIT        = '';
$REGISTER_SUCCESS_1     = '';
$REGISTER_SUCCESS_2     = '';

/*
 * Forum-Messages
 */
$FORUM[title]           = '';
$FORUM[save_message]    = '';
$FORUM[save_message_empty]= '';
$FORUM[save_nickname]   = '';
$FORUM[save_email]      = '';
$FORUM[save_homepage]   = '';
$FORUM[save_comment]    = '';
$FORUM[save_topic]      = '';
$FORUM[our_topics]      = '';
$FORUM[save_next]       = '';
$FORUM[save_read]       = '';
$FORUM[write]           = '';
$FORUM[write_header]    = '';
$FORUM[write_topic]     = '';
$FORUM[write_comment]   = '';
$FORUM[write_submit]    = '';
$FORUM[no_frame]        = '';
$FORUM[back_to]         = '';
$FORUM[article_list]    = '';
$FORUM[left_theme]      = '';
$FORUM[left_refresh]    = '';
$FORUM[welcome]         = '';
$FORUM[wrote]           = '';
$FORUM[meeting]         = '';
$FORUM[technology]      = '';
$FORUM[babble_topic]    = '';
$FORUM[newbees]         = '';
$FORUM[all_themes]      = '';
$FORUM[subject]         = '';

// confirmation page
$CONFIRMATION_TITLE = '';
$CONFIRMATION_OK_1 = '';
$CONFIRMATION_OK_2 = '';
$CONFIRMATION_FAILED = '';

// Operator-Interface
$MSG_OP_TITLE = '';
$MSG_OP_DESCRIPTION = '';
$MSG_OP_INFO = '';
$MSG_OP_KICKBUTTON = '';
$MSG_OP_INFOBUTTON = '';
$MSG_OP_PERMANENT = '';

$MSG_OP_INFOTEXT_GENERAL  = '';

$MSG_OP_INFOTEXT_INFOABOUT  = '';
$MSG_OP_INFOTEXT_KICKSSOFAR .= '';
$MSG_OP_INFOTEXT_KICKCOUNT .= '';
$MSG_OP_INFOTEXT_KICKTIME = '';
$MSG_OP_INFOTEXT_NEXTKICKTIME = '';
$MSG_OP_INFOTEXT_KICKED = '';
$MSG_OP_INFOTEXT_ALREADYKICKED = '';


//USERPAGE
$UP_FROM = '';
$UP_UNKNOWN_USER = '';
$UP_TOPLISTPLACE = '';
$UP_SEX = '';
$UP_INFO = '';
$UP_HOBBY = '';
$UP_BIRTHDATE = '';
$UP_AGE = '';
$UP_HOME = '';
$UP_FRIENDS = '';
$UP_GB_ERROR = '';
$UP_GB_SAVED = '';
$UP_GB_BACK = '';
$UP_GB_SIGNHERE = '';
$UP_GB_NOTLOGGEDIN = '';
$UP_GB_MSGCOUNT = '';
$UP_GB_MOVE = '';
$UP_GB_WROTE = '';
$UP_GB_CONFIRM_DELETE = '';
$UP_GB_ENTRY = '';
$UP_GB_COMMENT = '';
$UP_GB_DOIT = '';
$UP_GB_DELETE = '';

//main menu
$MAIN_INFO_REGISTER = '';
$MAIN_INFO_PROFILE = '';
$MAIN_INFO_CHATMAIL = '';
$MAIN_INFO_INVITE = '';
$MAIN_INFO_FRIENDS = '';
$MAIN_INFO_TOPLIST = '';
$MAIN_INFO_CLICK_UP = '';
$MAIN_INFO_FORUM = '';
$MAIN_INFO_HELP = '';
$MAIN_INFO_FORGOTPWD = '';
?>
