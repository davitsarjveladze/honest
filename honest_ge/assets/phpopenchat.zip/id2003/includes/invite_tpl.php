<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<html>
<head>
<title><?echo$MSG_INVITE?></title>
</head>
<body bgcolor="#F4F4F4" TEXT="#000000" LINK="#007b39" VLINK="#007b39" ALINK="#007b39" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="700" height="100%" align="center" cellspacing="0" cellpadding="5" border="0">
  <tr>
    <td align="center" valign="top">
      <font face="arial,helvetica,sans-serif" size="2">[ <A HREF="invite.<?echo $FILE_EXTENSION.'?nick='.urlencode($nick).'&pruef='.$pruef.'&'.session_name().'='.session_id();?>"><b><?echo $MSG_INVITE?></b></a> | <A HREF="ignore.<?echo $FILE_EXTENSION.'?nick='.urlencode($nick).'&pruef='.$pruef.'&'.session_name().'='.session_id();?>"><b><?echo $MSG_IGNORE?></b></a> ]</font>
      <HR>
      <FORM ACTION="invite.<?echo $FILE_EXTENSION?>" METHOD="POST">
	<TABLE ALIGN="CENTER" BORDER="0">
	  <TR>
	    <TD ALIGN="CENTER">
	      <font face="arial,helvetica,sans-serif" size="2"><?echo$MSG_INVITE_LIST?></font>
	    </TD>
	    <TD WIDTH="50"></TD>
	    <TD ALIGN="CENTER">
	      <font face="arial,helvetica,sans-serif" size="2"><?echo$ALL_CHATTER?></font>
	      <?echo$permissions?>
	    </TD>
	  </TR>
	  <TR>
      </FORM>
      <FORM ACTION="<?echo$SCRIPT_NAME?>" METHOD="POST">
	    <TD ALIGN="CENTER">
	      <?echo $select_of_invited_chatter?>
	    </TD>
	    <TD ALIGN="CENTER" VALIGN="CENTER">
	      <INPUT NAME="rein" TYPE="submit" VALUE="� --"><BR>
	      <INPUT NAME="raus" TYPE="submit" VALUE="-- �">
	    </TD>
	    <TD ALIGN="CENTER">
	      <?echo $select_of_not_invited?>
	      <?echo$permissions?>
	    </TD>
	  </TR>
	</TABLE>
      </FORM>
    </td>
  </tr>
  <tr>
    <td align="center" valign="bottom">
      <HR>
      <font face="arial,helvetica,sans-serif" size="2">[ <A HREF="invite.<?echo $FILE_EXTENSION.'?nick='.urlencode($nick).'&pruef='.$pruef.'&'.session_name().'='.session_id();?>"><b><?echo $MSG_INVITE?></b></a> | <A HREF="ignore.<?echo $FILE_EXTENSION.'?nick='.urlencode($nick).'&pruef='.$pruef.'&'.session_name().'='.session_id();?>"><b><?echo $MSG_IGNORE?></b></a> ]</font>
    </td>
  </tr>
</table>
</body>
</html>


