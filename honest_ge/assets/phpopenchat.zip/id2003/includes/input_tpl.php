<?//-*- C++ -*-
/*   ********************************************************************   **
**   Copyright (C) 1995-2000 Michael Oertel                                 **
**   Copyright (C) 2000-     PHPOpenChat Development Team                   **
**   http://www.ortelius.de/phpopenchat/                                    **
**                                                                          **
**   This program is free software. You can redistribute it and/or modify   **
**   it under the terms of the PHPOpenChat License Version 1.0              **
**                                                                          **
**   This program is distributed in the hope that it will be useful,        **
**   but WITHOUT ANY WARRANTY, without even the implied warranty of         **
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   **
**                                                                          **
**   You should have received a copy of the PHPOpenChat License             **
**   along with this program.                                               **
**   ********************************************************************   */

/*
Don't remove tags containing php tags like <?echo $var?> from this file! You can disable features by editing the file default_inc.php
*/?>
<BODY BGCOLOR="#FFFFFF" BACKGROUND="<?echo "images/$bgimage"?>" text="#000000" link="#007b39" vlink="#007b39" onLoad="<?echo $js_onload?>">

<SPAN STYLE="background-color:#f00"><?echo$choose_color_error?></SPAN>
   <TABLE cellpadding="0" cellspacing="5" border="0">
	<TR>
	<form name="chanchange" action="input.<?echo$FILE_EXTENSION?>" method="post">
	  <TD valign="top" rowspan="2">
	  		<?echo $chan_teilnehmer?>
			<?echo $get_privat_channel?>
			<?echo $hidden_fields?>
			<table border="0">
			<tr>
				<td><P STYLE="margin-top: 5px; margin-bottom: 3px; margin-left: 3px; background-color: <?=$chanbgcolor?>">
					<font><?echo $change_color_link?></font>
					</P>
				</td>
				<td><?echo $select_channel?></td>
			</tr>
			<tr><td colspan="2">
			    Hi <STRONG><?echo $nick?></STRONG>! <?echo urldecode($chanthese)?>
			</td></tr>
					</form>
					<form action="input.<?echo$FILE_EXTENSION?>" name="input" method="post">
			</table>
			<NOBR>
			&nbsp;<input name="chat" type="text" maxlength="<?echo$MAX_LINE_LENGTH?>" size="53" STYLE="font-size: 10px;font-family:MONOSPACE;" />
			 <input type="submit" value="<?echo $SAY_IT?>!" onClick="return checkSubmit()" />
			<BR />
			<TABLE cellpadding="0" cellspacing="0" border="0" >
				<TR VALIGN="top">
				   <TD BGCOLOR="#7093DB" VALIGN="middle">
				     	<?echo $radio_say_to?><BR />
     					<?echo $radio_wisper_to?>
				       </TD>
				   <TD BGCOLOR="#7093DB" VALIGN="middle">
				     <?echo $select_user?>
				     <BR />
				   </TD><TD>&nbsp;</TD>
				   <TD BGCOLOR="#66B886">
				       <?echo $button_twaddle_filter?>
				       <?echo $button_status_filter?>
				      </TD>
				</TR>
			</TABLE>
			</NOBR>
	  </TD>
	</TR>
		<?echo $chan_teilnehmer?>
		<?echo $get_privat_channel?>
		<?echo $hidden_fields?>
		<?echo $hidden_fields_chat?>
		</form>
	  
   </TABLE>
</BODY>
