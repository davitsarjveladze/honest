<?

// Translated by: Gio Lotito <gio@submail.net>
// PHPOpenChat Version: 2.x

$LANG			= "it";

$YES = 'Si';
$NO = 'No';

$MODERATOR_NAME   	= "System";
$TEAM_NAME	  	= "Chat-Team";
$STATUSFILTERNAME 	= "Filtro di stato";
$TWADDLEFILTERNAME	= "Filtro stupidaggini";
$WEEKDAY["Mon"]         = "Lun";
$WEEKDAY["Tue"]         = "Mar";
$WEEKDAY["Wed"]         = "Mer";
$WEEKDAY["Thu"]		= "Gio";
$WEEKDAY["Fri"]		= "Ven";
$WEEKDAY["Sat"]		= "Sab";
$WEEKDAY["Sun"]		= "Dom";
$CHANNEL		= "Canale";
$WRONGFORM		= "Si � riscontrata una forma sbagliata!";
$READING_MSG		= "Leggere messaggo dal";
$COME_FROM		= "viene da";
$COME_FROM_PRIVAT	= "viene dal canale privato di";
$JOINING_IN		= "si unisce a noi";
$LEAVES_US		= "ci lascia";
$GOES_TO		= "va verso";
$NO_PARTICIPATE		= "Non desidero partecipare";
$NICK_NAME		= "Nick";
$PASSWORD		= "Password";
$MAIL_ADDRESS		= "Indirizzo E-Mail";
$AGAIN			= "di nuovo";
$GO			= "Entra!";
$FIRST_TIME_ONLY	= "Solo la prima volta";
$LEAVE_CHAT		= "Lasciare la Chat";
$WISPER_TO		= "sussurrare a";
$SAY_TO			= "Di a";
$WISPERS_TO		= "sussurra a";
$SAYS_TO                = "Dice a";
$SAY_IT			= "dillo";
$SAYS			= "dice";
$AUTOSCROLLING		= "Auto scroll";
$COLOR_CHANGE		= "Nuovo colore per";
$OLD_COLOR		= "colore precedente";
$NEW_COLOR 		= "nuovo colore";
$HELP			= "Aiuto";
$ALL			= "tutti";
$ON			= "normale";
$ON1			= "veloce";
$ON2			= "pi� veloce";
$OFF			= "no";
$MESSAGES		= "Messaggi";
$CLOSE_WINDOW		= "Chiudere la finestra";
$EDIT			= "modifica...";
$SEND_MSG		= "Inviare un messaggio";
$NICK_IS		= "Il tuo nick �:";
$CHOOSE_LETTER		= "Seleziona la prima lettera del nome del ricevente!";
$CLEAR			= "cancella tutto";
$UPDATE_TEXT		= "Aggiorna il testo";
$KICKED			= "estromesso";
$SOMEBODY		= "qualcuno";
$LOOKING_IN		= "guardando";
$CHANGE_COLOR		= "cambiare colore";
$ACCEPT_ROW		= "accettare testo";
$MODERATOR_MESSAGE	= "Messaggio al moderatore";
$CHANNEL_EXPIRED	= "Mi dispiace, questo canale non esiste pi�!";
$CHANNEL_STARTS_AT	= "Prossima chat:";//Zeitangaben folgen
$CHANNEL_HINT		= "Sei nel canale privato di";//nick name follows
$INACTIVE		= "Sei stato inattivo per lungo tempo. Per favore prendi parte nuovamente.";
$UNLOCK_CHANNEL		= "sbloccare il canale";
$SOMEBODY		= "Qualcuno";
$REPLY_TO		= "respondi a";
$IS_DISCHARGED		= "non sei pi� invitato nel mio canale privato";
$IS_INVITED		= "sei invitato nel mio canale privato";
$ENTER_YOUR_CODE	= "Inserire il proprio codice";
$HAS_CHANGED_COLOR	= "� cambiato il colore del testo";
$BANNED_MSG		= "Sei stato estromesso dalla chat per un paio di settimane!";
$NOTIFY			= "Amici";
$ADD_CHATTER		= "Aggiungere questo utente alla mia lista di amici!";
$LAST_LOGON		= "ultima visita";
$USERPROFILE		= "Profilo Utente";
$PWD_REPEATE		= "Ripetere la password";
$HINT			= "Suggerimenti";
$HOST			= "Host";
$URL_FORMAT_HINT	= "Per favore non dimenticare il protocollo (http://) nelle URL!";
$I_WANT_TO_CHAT         = "desidero chattare";
$GREETINGS[1]		= "Buongiorno!";
$GREETINGS[2]           = "Come va?";
$GREETINGS[3]		= "Ciao!";
$GREETINGS[4]		= "Buona sera";
$GREETINGS[5]		= "Buona notte";
$NUM_USER		= "Numero di utenti registrati";
$CHATTERS_ONLINE	= "Utenti in linea";
$CHATTERS_ONLINE_24H    = 'Logins nelle ultime 24 ore';
$LOCAL_TIME		= "ora locale";
$MY_PROFILE		= "Il mio profilo";
$FORGOT_PWD		= "Dimenticato la password?";
$TELL_US                = "raccontaci qualcosa...";
$COME_IN                = "unisciti a noi";
$WHATS_UP               = "che succede?";
$CHAT_WITH_US           = "chatta con noi";
$IS_CHATTING_IN		= "sei nel canale ";//a channel name follows
$NOT_ONLINE		= "non � on line.";//a nickname in front
$OPENED_TO_PUB		= 'era aperto al pubblico';
$BEGIN			= "Tornare all'inizio";
$ANSWER			= 'Risposta';
$DELETE			= 'Cancellare';
$WROTE    		= 'Ha scritto';

// no translation
$SEND_IMG		= 'Invia immagine';
$CHOOSE_IMG		= "Scegli un'immagine";
$USER_ICON		= 'La tua icona nella chat';
$NEW_IMG_HINT		= 'Se non vedi la tua nuova immagine, cancella i file temporanei del browser e aggiorna.';
$PWD_DONT_MATCH		= 'La passwords non � corretta!';
$MAX_FILE_EXCEEDED	= 'Massima dimensione del file superata! La dimensione del file non deve superare';//a size follows
$MAX_SIZE_EXCEEDED	= 'Il file � troppo grande!';
$HINT_IMG_SIZE		= "la dimensione dell'immagine �";//x,y values follows
$ALLOWED		= 'ammesso';
$MIME_ERROR		= 'Tipo di file non ammesso! Ammessi sono \'image/gif\' il tuo � ';//a type follows
$INVALID_NICK		= 'Questo nick non � stato ancora registrato!';
$NO_EMPTY_PWD		= 'Non sono ammesse password vuote!';
$GODFATHER		= 'Padrino';
$MSG_KICKED		= "Sei stato estromesso!";
$MSG_SEARCH		= 'Cerca';
$FLOODING_MSG1		= 'Hai detto la stessa cosa tre volte. Per favore prova una normale conversazione.';
$FLOODING_MSG2		= 'Hai detto di nuovo la stessa cosa, cos� il tuo testo non � stato visualizzato e sarai estromesso dalla chat, se ci riprovi.';
$NO_SCRIPT              = 'Devi avere il compilatore java attivato nel tuo browser prima di entrare nella nostra chat!';

$LAST_REGISTERED_USER   = 'Ultimo utente registrato';
$TOTAL_POSTS            = 'Post totali';
$NUM_POSTS              = 'Postnel database';
$NEW_POSTS_LAST_24H     = 'Nuovi post nelle ultime 24 ore';
$LAST_POST              = 'Ultimo post';
$TOTAL_MAILS            = 'Mail totali';
$NUM_MAILS              = 'Mail nel database';
$NEW_MAILS_LAST_24H     = 'Nuove mail nelle ultime 24 ore';

// send password to user
$MSG_SENDPWD        = 'Invia la password dimenticata per email';
$MSG_SENDPWD_SUCCESS = "<font color=green>La password � stata inviata sull'email specificata al momento della registrazione.</font>";
$MSG_SENDPWD_NONICK = '<font color=red>Non ci sono utenti con questo Nick nel database !</font>';
$MSG_SENDPWD_NOEMAIL = "<font color=red>La password non ha potuto essere inviata. Non � stato specificata un'email con insieme al nick.</font>";
$MSG_SENDPWD_SUBJECT = 'La password richiesta';
$MSG_SENDPWD_MSGTXT   = 'Salve,\n\nla tua password �: ';
$MSG_SENDPWD_SUBMIT = 'Invia';
$MSG_SENDPWD_NICKNAME = 'Nick : ';

// -- Invite & Ignore --
$IGNORE_INVITE		= "Ignorare/Invitare";
$ALL_CHATTER		= "Tutti gli utenti";
$MSG_INVITE 		= "Invita utente";
$MSG_IGNORE 		= "Ignora utente";
$MSG_INVITE_TITLE	= "Invitare un utente nella propria chat";
$MSG_INVITE_LIST	= "Utente(i) invitato(i) ";
$MSG_IGNORE_LIST	= "Utente(i) ignorato(i)";
$MSG_IGNORE_NUMBER	= "Numero di utenti che ignorano questo utente";
$MSG_IGNORE_ALSO	= "Quantit� di utenti che devono ignorarlo per estrometterlo";
$MSG_IGNORE_PATEN	= "Puoi estromettere un utente usando l'opzione ignora";

// -- Friends --
$MSG_FRIENDS = 'I miei Amici';
$MSG_FRIENDS_ADD = 'Aggiungi Amici';
$MSG_FRIENDS_ADD_TITLE = 'Aggiungi questo utente ai miei Amici';
$MSG_FRIENDS_SEARCH = 'Cerca';
$MSG_FRIENDS_ADD_BUTTON = 'Aggiungi';
$MSG_FRIENDS_FRIEND = 'Amico';
$MSG_FRIENDS_LAST_SEEN = "Visto l'ultima volta";
$MSG_FRIENDS_TIME = 'Tempo adesso';

// -- Toplist --
$TOPLIST                = 'Toplist';
$TOPLIST_HINT_PART1     = 'Tutti i tempi on line verranno azzerati





 all\'inizio di ogni mese.';
$TOPLIST_HINT_PART2	= 'Se mentre chatti fai un break pi� lungo di cinque minuti, questo tempo non sar� conteggiato nel tuo tempo online totale.';
$TOPLIST_HINT_PART3	= 'Qui ci sono tutti gli utenti che ora non sono nei Top 30 :';
$MSG_TOPLIST_RANK       = 'Classifica';
$MSG_TOPLIST_ONLINE_TIME = 'Totale del tempo online';
$MSG_TOPLIST_LAST_SEEN  = 'Ultima volta in';
$MSG_TOPLIST_SHOW_30	= "Mostra classificati dall'1� al 30�";
$MSG_TOPLIST_SHOW_100	= "Mostra classificati dall'30� al 100�";

// -- Chatmail --
$CHATMAIL       = 'Chatmail';
$INBOX		= 'Posta in arrivo';
$SENT_MAIL	= 'Posta inviata';
$WRITE_MAIL	= 'Scrivi posta';
$SENDER		= 'Da';
$RECEIPIENT	= 'A';
$SENT		= 'Spedita';
$RECEIVED	= 'Ricevuta';
$SUBJECT	= 'Oggetto';
$MESSAGE	= 'Messaggio';
$NOSUBJECT	= 'Nessun oggetto';
$SENDMAIL	= 'Invia Posta';
$LEFT_THIS_MESSAGE = "lasciare questo messaggio";
$FRIENDS_SUBJ	= 'Ultima visita dei tuoi amici...';
$WELCOME_SUBJ	= 'Registrazione avvenuta con successo...';
$WELCOME_MSG    = 'Ciao $nick! Sei stato accettato nella comunit� della chat. $TEAM_NAME ti augura buon divertimento. Se hai dubbi, puoi fare click su aiuto. CU';
$NO_HIT         = 'Utente non trovato';
$MSG_SEND_TO	= 'Il messaggio sar� inviato a (La prima lettera del nick pu� essere sufficiente)';//a nickname follows
$CHOOSE_NICK	= 'Seleziona uno dei nick trovati';
$NO_SELECTION   = 'Hai dimenticato di inserire il nome.';
$SEND_SUCCESS	= 'Posta inviata con successo.';

// -- Who is online? --
$WHOISONLINE = 'Chi c\'� online?';
$WHOISONLINE_NUM_ONE = 'In questo momento c\'�';
$WHOISONLINE_NUM_MORE = 'In questo momento ci sono';
$WHOISONLINE_IN_CHAT = 'Utente(i) online';
$WHOISONLINE_COLOR_RED = 'Rosso';
$WHOISONLINE_COLOR_BLUE = 'Blu';

// -- START new Admin-module ---

$MSG_ADM_BACKTOCHAT        = 'Torna alla Chat';
$MSG_ADM_PAGETITLE        = 'Amministrazione Chat';
$MSG_ADM_CHANNELS        = 'Amministrazione dei Canali';
$MSG_ADM_OPERATORS    = 'Amministrazione degli Operatori';
$MSG_ADM_COMODERATORS    = 'Amministrazione dei Co-Moderatori';
$MSG_ADM_VIPS        = 'Amministrazione dei VIP and Moderatori';
$MSG_ADM_HINTS    = 'Messaggi Automatici nella Chat';
$MSG_ADM_FORUM       =  'Administrazione del Forum';

// channels
$MSG_ADM_CHANNELNAME ='Nome del canale';
$MSG_ADM_NEWCHANNEL = 'Aggiungi canale';
$MSG_ADM_EDITCHANNEL = 'Edit';
$MSG_ADM_DELETECHANNEL = 'Cancella';
$MSG_ADM_CHANNELS_CONFIRM_DEL = 'Vuoi veramente cancellare questo canale ?';

$MSG_ADM_CLEAR_LINES        = 'Cancella Colonne';
$MSG_ADM_SAVE            = 'Salva Dati';

$MSG_ADM_CHANNELS_FIELDS['Name']    = 'Nome del canale';
$MSG_ADM_CHANNELS_FIELDS['PASSWORD']    = 'Password';
$MSG_ADM_CHANNELS_FIELDS['These']    = 'Tema';
$MSG_ADM_CHANNELS_FIELDS['Teilnehmerzahl']='Numero massimo di utenti';
$MSG_ADM_CHANNELS_FIELDS['BG_Color']    = 'Colore di sfondo';
$MSG_ADM_CHANNELS_FIELDS['Logo']    = 'Percorso del file di immagine nella frame di input';
$MSG_ADM_CHANNELS_FIELDS['ExitURL']    = 'URL di uscita';
$MSG_ADM_CHANNELS_FIELDS['moderiert']= 'Moderazione del Canale ';
$MSG_ADM_CHANNELS_FIELDS['starts_at']= 'Il canale comincia alle';
$MSG_ADM_CHANNELS_FIELDS['stops_at']    = 'Il canale finisce alle';
$MSG_ADM_CHANNELS_FIELDS['NICK_COLOR']    = 'Colore del Nick';

$MSG_ADM_CHANNEL_ERROR_NAME = 'Per favore scrivi un nome valido per il canale';
$MSG_ADM_CHANNEL_ERROR_BGCOLOR = 'Per favore dai un colore valido per lo sfondo';
$MSG_ADM_CHANNEL_ERROR_NICKCOLOR = 'Per favore dai un colore valido per il nick';
$MSG_ADM_CHANNEL_ERROR_LOGO = 'Per favore dai un percorso valido per l\'immagine del canale';
$MSG_ADM_CHANNEL_ERROR_EXITURL = 'Per favore dai un percorso valido per l\'URL di uscita';
$MSG_ADM_CHANNEL_ERROR_SAMECOLOR = 'Il colore di sfondo e quello del nick non devono essere uguali';
$MSG_ADM_CHANNEL_ERROR_YEAR = "L'anno non � valido";

// Operators
$MSG_ADM_OPERATORNAME ="Nome dell'operatore";
$MSG_ADM_NEWOPERATOR = 'Aggiungi nuovo operatore';
$MSG_ADM_DELETEOPERATOR = 'Cancella';

$MSG_ADM_OPERATORS_ERROR_EMPTY = 'Il campo di input non pu� essere vuoto !';
$MSG_ADM_OPERATORS_ERROR_NONICK = 'Non c\'� un utente con questo nick !';

// VIP's
$MSG_ADM_VIPS_CREATE = 'Aggiungi nuovo VIP e Moderatore';
$MSG_ADM_VIPS_NICK = 'Nick del VIP';
$MSG_ADM_VIPS_MODERATOR = 'Moderatore';
$MSG_ADM_VIPS_CHANNEL = 'Canale';
$MSG_ADM_VIPS_DELETE = 'Cancella';

$MSG_ADM_VIPS_ERROR_MODERATOR1 = 'Il campo del moderatore non pu� esere vuoto !';
$MSG_ADM_VIPS_ERROR_MODERATOR2 = 'Il moderatore deve essere un utente registrato !';
$MSG_ADM_VIPS_ERROR_VIP1 = 'Il campo VIP non pu� essere vuoto !';
$MSG_ADM_VIPS_ERROR_VIP2 = 'Il VIP esiste gi�';

// co-moderators
$MSG_ADM_COMODERATORNAME ='Name del the Co-Moderatore';
$MSG_ADM_NEWCOMODERATOR = 'Aggiungi nuovo Co-Moderatore';
$MSG_ADM_DELETECOMODERATOR = 'Cancella';

$MSG_ADM_COMODERATORS_ERROR_EMPTY = 'Il campo di input non pu� essere vuoto !';
$MSG_ADM_COMODERATORS_ERROR_NONICK = 'Non c\'� un utente con questo nick !';

// hints
$MSG_ADM_HINT = 'Suggerimento';
$MSG_ADM_HINTS_SAVE = 'Salva suggerimento';

// forum
$MSG_ADM_FORUM_ADDTOPIC = 'Aggiungi nuovo tema';
$MSG_ADM_FORUM_NAME = 'Nome del tema';
$MSG_ADM_FORUM_MSGCOUNT = 'Messaggi';
$MSG_ADM_FORUM_EDIT = 'Modifica';
$MSG_ADM_FORUM_DELETE = 'Cancella';
$MSG_ADM_FORUM_MESSAGES = 'Modifica messaggi';
$MSG_ADM_FORUM_INITMSG = 'Messaggio iniziale';
$MSG_ADM_FORUM_INITMSG_TEXT ='Questo � un nuovo tema che � stato appena aperto';
$MSG_ADM_FORUM_CONFIRM_DEL = 'Vuoi veramente cancellare questo tema ?';
$MSG_ADM_FORUM_MSG_CONFIRM_DEL = 'Vuoi veramente cancellare questo messaggio ?';

$MSG_ADM_FORUM_ERROR_TOPIC = 'Per favore dai un nome valido al nuovo tema !';
$MSG_ADM_FORUM_ERROR_INITMSG = 'Per favore inserisci un messaggio iniziale per il nuovo tema !';
$MSG_ADM_FORUM_ERROR_NICK = 'Per favore inserisci un nick valido per il nuovo tema !';
$MSG_ADM_FORUM_ERROR_COMMENT = 'Il campo commento non pu� essere vuoto';

$MSG_ADM_FORUM_DELWARNING = 'Attenzione : Tutti i messaggi verranno persi dopo aver cancellato il tema';
$MSG_ADM_FORUM_MSG_DELWARNING = 'Attenzione : Dopo aver cancellato l\'ultimo messaggio del tema, l\'intero tema sar� cancellato';
$MSG_ADM_FORUM_MSGID = 'ID Messaggio';
$MSG_ADM_FORUM_MSGRANGE = 'Vista d\'insieme messaggi';
$MSG_ADM_FORUM_MSGCOUNTER = 'Nr.';
$MSG_ADM_FORUM_NICK = 'Nick';
$MSG_ADM_FORUM_DATE = 'Data';
$MSG_ADM_FORUM_COMMENT = 'Commento';
$MSG_ADM_FORUM_EMAIL = 'Email';
$MSG_ADM_FORUM_HOMEPAGE = 'Homepage';

$MSG_ADM_FORUM_NAV = 'Navigazione';
$MSG_ADM_FORUM_FROM = 'Da';
$MSG_ADM_FORUM_FIRST = 'Start';
$MSG_ADM_FORUM_LAST = 'Fine';
$MSG_ADM_FORUM_NEXT = 'Seguente';
$MSG_ADM_FORUM_PREV = 'Precedente';

$MSG_ADM_FORUM_EDITMSG = 'Modifica messaggio';
$MSG_ADM_FORUM_BACKTOLIST = 'Ritorna alla vista d\'insieme messaggi';

// Chatmail to all users
$MSG_ADM_MAILALL = 'Chatmail a tutti';
$MSG_ADM_MAILALL_NEWMAIL = 'Scrivi una nuova chatmail a tutti';
$MSG_ADM_MAILALL_OLDMAILS = 'Messaggi precedenti :';
$MSG_ADM_MAILALL_SUBJECT = 'Oggetto';
$MSG_ADM_MAILALL_DATE = 'Data';
$MSG_ADM_MAILALL_BODY = 'Messaggio';
$MSG_ADM_MAILALL_DELETE = 'Cancella';
$MSG_ADM_MAILALL_SEND = 'Invia messaggio';
$MSG_ADM_MAILALL_REFRESH = 'Cancella contenuto';
$MSG_ADM_MAILALL_ERROR_BODY = 'Il campo messaggio non pu� essere vuoto';
$MSG_ADM_MAILALL_ERROR_SUBJECT = 'Il campo oggetto non pu� essere vuoto';
$MSG_ADM_MAILALL_CONFIRM_DEL = 'vuoi veramente cancellare questo messaggio ?';
$MSG_ADM_MAILALL_SHOW = 'Mostra';
$MSG_ADM_MAILALL_BACK = 'Ritorna alla vista d\'insieme messaggi';

$MSG_ADM_MAILALL_RECIEVER = 'Ricevente';
$MSG_ADM_MAILALL_ALLUSERS = 'Tutti gli utenti registrati';
$MSG_ADM_MAILALL_OPERATORS = 'Tutti gli operatori';
$MSG_ADM_MAILALL_COMODERATORS = 'Tutti i Co-Moderatori';

// -- END new Admin-module ---


/*
** Admin-Tool
*/
$BACK_TO_CHAT		= "Tornare alla chat";
$CHAT_SETUP		= "Amministrazione della Chat";
$AUTOMATIC_HINTS	= "Messaggi automatici nella chat";
$SETUP_CHANNELS		= "Amministrazione dei canali";
$SETUP_MODERATORS	= "Amministrazione dei padrini della chat chat";
$SETUP_COMODERATORS	= "Amministrazione dei co-moderadori";
$SETUP_VIPS		= "Amministrazione dei VIP's";
$SETUP_FORUM            = "Amministrazione Forum";
$SAVE_HINTS		= "Salva suggerimenti";
$CREATE_CHANNEL		= "Creare un nuovo canale";
$MODERATORS		= "Moderatori";
$GODFATHERS		= "Padrini";
$MODERATOR		= "Moderatore";
$COMODERATORS		= "Co-Moderadori";
$VIPS			= "VIP's";
$VIP			= "VIP";
$ADD_REMOVE		= "Aggiungi/elimina";
$SAVE			= "Salva";
$CLEAR_LINES		= "Cancellare tutto il testo del canale";
$CHAT_OVERLOAD		= "Mi dispiace la chat � troppo piena in questo momento.";
$REPEAT_LOGIN		= "Prova a fare di nuovo login!";
$FEHLER			= "Errore";
$ERRORMAIL_SUBJECT 		= 'Errore connettendo al database';
$ERRORMAIL_BODY    		= "La chat non ha potuto connettersi con il database.\nif la chat era gi� iniziata o � sovraccarica, sembra essere al limite del carico. prova a cambiare qualcosa ;-)\n\n se questa � una nuova installazione, probabilmente c\'� qualcosa di sbagliato nel file default_inc.php. Controlla se databasehost, databaseuser e databasepassword sono corrette e senza spazi. Controlla se il database � correttamente installato. Se hai provato ad installarlo via phpMyAdmin, potrebbe aver fallito. ";

$TBL_FIELDS["Id"]	= "";
$TBL_FIELDS["Name"]	= "Nome del canale";
$TBL_FIELDS["PASSWORD"]	= "Pssword";
$TBL_FIELDS["These"]	= "Questi";
$TBL_FIELDS["Teilnehmerzahl"]="Numero massimo di utenti<BR>0=nessun limite";
$TBL_FIELDS["BG_Color"]	= "Colore di sfondo della casella testo";
$TBL_FIELDS["Logo"]	= "Percorso del file di immagine nella casella di input";
$TBL_FIELDS["ExitURL"]	= "URL di uscita";
$TBL_FIELDS["moderiert"]= "moderato?<BR>[1=si/0=no]";
$TBL_FIELDS["starts_at"]= "Il canale inizia";
$TBL_FIELDS["stops_at"]	= "Il canale finisce";
$TBL_FIELDS["NICK_COLOR"]="Colore del nick";

/*
 * login and registration messages
 */
$message[session_name]="Non si pu� registrare la sessione.";
$message[error_1]="Questo nick � gi� registrato o � on line.<BR>Sugerencia: Ingrese la clave solo una vez!";
$message[error_default]="Non � possibile partecipare";
$message[error_2]="Partecipazione negata! Password non corretta.";
$message[error_3]="Le password non coincidono. Per favore riprova!";
$message[error_4]="Solamente due possibilit�! Inserisci una password o un\'indirizzo E-mail!";
$message[error_5]="Parole non valide trovate nel tuo nick!";
$message[error_6]="Espressione non valida trovata nel tuo nick!";
$message[error_7]="Mi dispiace � stato raggiunto il numero massimo di utenti permesso!<BR>Riprova pi� tardi.";
$message[error_8]="Si � riscontrato un codice colore sbagliato.";
$REGISTER_NICK = 'Voglio registrarmi!';
$REGISTER_TITLE = 'Registrazione';
$REGISTER_SUBMIT = 'Registra';
$REGISTER_SUCCESS_1 = 'Registrazione avvenuta con successo!<br> Login sul nostro';
$REGISTER_SUCCESS_2 = ' home page</a> adesso.';

/*
 * Forum-Messages
 */
$FORUM[title]		  = "Lavagna";
$FORUM[save_message]	  = "Complimenti! Il tuo articolo � in linea.";
$FORUM[save_message_empty]= "Il tuo articolo � vuoto e non abbiamo potuto salvarlo.";
$FORUM[save_nickname]	  = "nick: ";
$FORUM[save_email]	  = "E-mail:";
$FORUM[save_homepage]	  = "Home page:";
$FORUM[save_comment]	  = "Commento:";
$FORUM[save_topic]	  = "al tema ";
$FORUM[our_topics]	  = "nostri temi";
$FORUM[save_next]	  = "prossimo ";
$FORUM[save_read]	  = "Desidero leggere!";
$FORUM[write]		  = "Scrivi un articolo";
$FORUM[write_header]	  = "Ora puoi scrivere un nuovo articolo.";
$FORUM[write_topic]	  = "Il tuo tema: ";
$FORUM[write_comment]	  = "Il tuo commento:";
$FORUM[write_submit]	  = "Invia";
$FORUM[no_frame]	  = "Mi dispiace, Il tuo browser non supporta le frames.";
$FORUM[back_to]		  = "Tornare a";
$FORUM[article_list]	  = "Lista di tutti gli articoli";
$FORUM[left_theme]	  = "Tema";
$FORUM[left_refresh]	  = "aggiorna";
$FORUM[welcome]	  	  = "	<H3>Fai click sui temi sul lato sinistro per ottenere la lista degli articoli.<BR>Per leggere un articolo fai click su di un nick.</H3>				Los articulos mas nuevos estan arriba.<BR>				Que los disfrute!";
$FORUM[wrote]		  = "Ha scritto";
$FORUM[meeting]		  = "Incontro";
$FORUM[technology]	  = "Tecnologia";
$FORUM[babble_topic]	  = "Tema di chiacchiere";
$FORUM[newbees]		  = "principianti";
$FORUM[all_themes]        = "Lista dei temi";
$FORUM[subject]           = "Oggetto";

// confirmation page
$CONFIRMATION_TITLE = 'Finish Registration';
$CONFIRMATION_OK_1 = 'Welcome! You are now a member of our online community.<br>Click here';
$CONFIRMATION_OK_2 = 'to login!</a><br>Have fun!';
$CONFIRMATION_FAILED = 'We are sorry, but your nickname could not be activated. Please try again!';

// Operator-Interface
$MSG_OP_TITLE = 'Operator-Function';
$MSG_OP_DESCRIPTION = 'Select a chatter to kick :';
$MSG_OP_INFO = '<b><u>Information :</u></b>';
$MSG_OP_KICKBUTTON = 'kick';
$MSG_OP_INFOBUTTON = 'Info';
$MSG_OP_PERMANENT = 'Kick chatter permanetly';

$MSG_OP_INFOTEXT_GENERAL  = 'Operators cannot be kicked. Therefore, they are not listed here. !';

$MSG_OP_INFOTEXT_INFOABOUT  = "Information about ";
$MSG_OP_INFOTEXT_KICKSSOFAR .= "Kicks so far :";
$MSG_OP_INFOTEXT_KICKCOUNT .= "Kick count :";
$MSG_OP_INFOTEXT_KICKTIME ="New locktime (minutes) :";
$MSG_OP_INFOTEXT_NEXTKICKTIME ="Locktime at next kick (minutes) :";
$MSG_OP_INFOTEXT_KICKED = "has been kicked out of the chat !";
$MSG_OP_INFOTEXT_ALREADYKICKED = "Has already been kicked out of the chat by another operator. !";


//USERPAGE
$UP_FROM = 'Userpage from';
$UP_UNKNOWN_USER = 'Don&acute;t know this user';
$UP_TOPLISTPLACE = 'Toplistplace';
$UP_SEX = 'Sex';
$UP_INFO = 'Info about me';
$UP_HOBBY = 'My hobbies';
$UP_BIRTHDATE = 'Birthdate';
$UP_AGE = 'Age';
$UP_HOME = 'Home';
$UP_FRIENDS = 'My friends at';
$UP_GB_ERROR = 'You have to fill in a text at least';
$UP_GB_SAVED = 'Your guestbook entry was saved';
$UP_GB_BACK = 'Back to guestbook';
$UP_GB_SIGNHERE = 'Here you can sign the guestbook';
$UP_GB_NOTLOGGEDIN = 'To sign the guestbook you have to login into the chat';
$UP_GB_MSGCOUNT = 'Count of entries';
$UP_GB_MOVE = 'Browse the guestbook';
$UP_GB_WROTE = 'wrote at';
$UP_GB_CONFIRM_DELETE = 'Sure to delete?';
$UP_GB_ENTRY ='Sign the guestbook';
$UP_GB_COMMENT = 'Comment';
$UP_GB_DOIT = 'Save';
$UP_GB_DELETE = 'delete';

//main menu
$MAIN_INFO_REGISTER = 'Register your nickname.';
$MAIN_INFO_PROFILE = 'Modify personal data and create your userpage.';
$MAIN_INFO_CHATMAIL = 'Send and receive mail messages within the chat.';
$MAIN_INFO_INVITE = 'Invite chatters into your own channel or ignore them.';
$MAIN_INFO_FRIENDS = 'Add a chatter to your friends.';
$MAIN_INFO_TOPLIST = 'List of all the chatters that have been here the most und longest.';
$MAIN_INFO_CLICK_UP = 'Click on a nickname to see the chatter\'s userpage.';
$MAIN_INFO_FORUM = 'Here you can communicate with other chatters about specific topics.';
$MAIN_INFO_HELP = 'Here you can find some help for all the chat\'s funtions.';
$MAIN_INFO_FORGOTPWD = 'Have your password sent to you by email.';
?>

