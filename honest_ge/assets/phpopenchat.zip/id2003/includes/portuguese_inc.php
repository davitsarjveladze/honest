<?

// Written by:
// PHPOpenChat Version: 2.x

$LANG                   = 'en';

$YES = 'Yes';
$NO = 'No';

$MODERATOR_NAME         = 'Sistema';
$TEAM_NAME                = 'Equipe de Bate-Papo';
$STATUSFILTERNAME       = 'Filtro de Status';
$TWADDLEFILTERNAME      = 'Filtro anti-tolices';
$WEEKDAY['Mon']         = 'Seg';
$WEEKDAY['Tue']         = 'Ter';
$WEEKDAY['Wed']         = 'Qua';
$WEEKDAY['Thu']         = 'Qui';
$WEEKDAY['Fri']         = 'Sex';
$WEEKDAY['Sat']         = 'S�b';
$WEEKDAY['Sun']         = 'Dom';
$CHANNEL                = 'Sala';
$WRONGFORM              = 'Forma inv�lida detectada!';
$READING_MSG            = 'ler mensagens de';
$COME_FROM              = 'vem de';
$COME_FROM_PRIVAT       = 'vem da sala privada de';
$JOINING_IN             = 'entra na sala';
$LEAVES_US              = 'sai da sala';
$GOES_TO                = 'vai para';
$NO_PARTICIPATE         = 'Eu n�o quero participar';
$NICK_NAME              = 'Apelido';
$PASSWORD               = 'Senha';
$MAIL_ADDRESS           = 'Endere�o de E-Mail ';
$AGAIN                  = 'Repetir';
$GO                     = 'Vamos l�!';
$FIRST_TIME_ONLY        = 'Na primeira vez apenas';
$LEAVE_CHAT             = 'Sair do bate-papo';
$WISPER_TO              = 'sussurra para';
$SAY_TO                 = 'diz para';
$WISPERS_TO             = 'sussurra para';
$SAYS_TO                = 'diz para';
$SAY_IT                 = 'Enviar';
$SAYS                        = 'diz';
$AUTOSCROLLING          = 'Rolagem autom�tica';
$COLOR_CHANGE           = 'Nova cor para';
$OLD_COLOR              = 'Cor antiga';
$NEW_COLOR              = 'nova cor';
$HELP                   = 'Ajuda';
$ALL                    = 'Todos';
$ON                        = 'Normal';
$ON1                        = 'R�pido';
$ON2                        = 'Mais r�pido';
$OFF                    = 'desligado';
$MESSAGES               = 'Mensagens';
$CLOSE_WINDOW           = 'Fechar Janela';
$EDIT                   = 'editar...';
$SEND_MSG               = 'Enviar uma mensagem';
$NICK_IS                = 'Seu apelido �:';
$CHOOSE_LETTER          = 'Escolha a primeira letra do nome do destinat�rio!';
$CLEAR                  = 'Limpar tudo';
$UPDATE_TEXT            = 'Atualizar texto';
$KICKED                 = 'chutado';
$SOMEBODY               = 'Algu�m';
$LOOKING_IN             = 'olhando em';
$CHANGE_COLOR           = 'mudar cor';
$ACCEPT_ROW             = 'aceitar texto';
$MODERATOR_MESSAGE      = 'Mensagem para o moderador';
$CHANNEL_EXPIRED        = 'Desculpe, sala encerrada!';
$CHANNEL_STARTS_AT      = 'Pr�xima abertura em:';//Zeitangaben folgen
$CHANNEL_HINT           = 'Voc� est� na sala privada de';//nick name follows
$INACTIVE               = 'Voce ficou inativo por muito tempo. Por favor, entre novamente.';
$UNLOCK_CHANNEL         = 'destrancar canal';
$SOMEBODY               = 'Alguem';
$REPLY_TO               = 'responder para';
$IS_DISCHARGED          = 'n�o est� mais convidado(a) para a sala privada';
$IS_INVITED             = 'is invited to my private channel';
$ENTER_YOUR_CODE        = 'Entre seu pr�prio c�digo';
$HAS_CHANGED_COLOR      = 'mudou a cor do texto';
$BANNED_MSG             = 'Voc� est� banido do chat!';
$NOTIFY                 = 'Amigos';
$ADD_CHATTER            = 'Adicionar essa pessoa a minha lista de amigos!';
$LAST_LOGON             = 'Visto pela �ltima vez em';
$USERPROFILE            = 'Detalhes do usu�rio';
$PWD_REPEATE            = 'Repita a senha';
$HINT                   = 'Dica';
$HOST                   = 'Host';
$URL_FORMAT_HINT        = 'N�o esque�a do Protocolo (http://) no endere�o da p�gina!';
$I_WANT_TO_CHAT         = 'Eu quero participar';
$GREETINGS[1]           = 'Bom dia!';
$GREETINGS[2]           = 'Como vai?';
$GREETINGS[3]           = 'Ol�';
$GREETINGS[4]           = 'Boa tarde!';
$GREETINGS[5]           = 'Boa Noite!';
$NUM_USER               = 'N�mero de usu�rios registrados';
$CHATTERS_ONLINE        = 'Usu�rios no bate-papo agora';
$LOCAL_TIME             = 'Hora atual';
$MY_PROFILE             = 'Meus detalhes';
$FORGOT_PWD             = 'Esqueceu sua senha?';
$TELL_US                = 'Diga-nos algo.';
$COME_IN                = 'venha e junte-se a n�s.';
$WHATS_UP               = 'e ai?';
$CHAT_WITH_US           = 'vamos conversar juntos.';
$IS_CHATTING_IN         = 'esta conversando na sala ';//a channel name follows
$NOT_ONLINE             = 'n�o est� no bate-papo agora.';//a nickname in front
$OPENED_TO_PUB          = 'aberto para o p�blico';
$BEGIN                  = 'de volta ao in�cio';
$ANSWER                 = 'Responder';
$DELETE                 = 'Apagar';
$WROTE                  = 'escreveu';
$SEND_IMG                = 'enviar imagem';
$CHOOSE_IMG                = 'escolher uma imagem';
$USER_ICON                = 'Seu desenho no bate-papo';
$NEW_IMG_HINT                = 'Se n�o conseguir ver seu novo desenho, limpe o cache do seu navegador e recarregue a p�gina.';
$PWD_DONT_MATCH                = 'Senhas n�o coincidem!';
$MAX_FILE_EXCEEDED        = 'Tamanho m�ximo do arquivo ultrapassado! O tamanho do arquivo deve ser menor que';
$MAX_SIZE_EXCEEDED        = 'Tamanho m�ximo de arquivo ultrapassado!';
$HINT_IMG_SIZE                = 'O tamanho de sua figura �';//x,y values follows
$ALLOWED                = 'permitido';
$MIME_ERROR                = 'Tipo de arquivo invalido! O tipo permitido � \'gif\' e o seu arquivo �';
$INVALID_NICK                = 'Este apelido n�o est� registrado ainda!';
$NO_EMPTY_PWD                = 'N�o s�o permitidas senhas vazias!';
$GODFATHER                = 'Operador';
$MSG_KICKED                 = 'Voc� foi chutado!';
$MSG_SEARCH                 = 'Procurar';
$FLOODING_MSG1                = 'Voc� disse a mesma coisa tr�s vezes. Por favor, tente conversar normalmente.';
$FLOODING_MSG2                = 'Voc� disse a mesma coisa de novo; sua mensagem n�o ser� exibida, e caso insista, voc� ser� chutado para fora do bate-papo!';
$NO_SCRIPT  = 'Voce precisa ativar suporte a JavaScript (no Internet Explorer, ativar "Active Script") antes de entrar no bate-papo!';

$LAST_REGISTERED_USER   = 'Last registered user';
$TOTAL_POSTS            = 'Total posts';
$NUM_POSTS              = 'Posts in the database';
$NEW_POSTS_LAST_24H     = 'New posts in the last 24 hours';
$LAST_POST              = 'Last post';
$TOTAL_MAILS            = 'Total mails';
$NUM_MAILS              = 'Mails in the database';
$NEW_MAILS_LAST_24H     = 'New mails in the last 24 hours';

// send password to user
$MSG_SENDPWD        = 'Enviar a senha por e-mail';
$MSG_SENDPWD_SUCCESS = '<font color=green>Sua senha foi enviada para o endere�o de e-mail especificado quando voce se registrou.</font>';
$MSG_SENDPWD_NONICK = '<font color=red>Este apelido n�o existe no nosso banco de dados!</font>';
$MSG_SENDPWD_NOEMAIL = '<font color=red>Sua senha n�o pode ser enviada. Seu registro n�o possui endere�o de e-mail.</font>';
$MSG_SENDPWD_SUBJECT = 'Sua senha do bate-papo';
$MSG_SENDPWD_MSGTXT   = "Ol�! \n \n Sua senha �: ";
$MSG_SENDPWD_SUBMIT = 'Enviar';
$MSG_SENDPWD_NICKNAME = 'Apelido: ';

// -- Invite & Ignore --
$IGNORE_INVITE = 'Convidar/Ignorar';
$ALL_CHATTER = 'Todos os usu�rios';
$MSG_INVITE = 'Convidar usu�rio';
$MSG_IGNORE = 'Ignorar usu�rio';
$MSG_INVITE_TITLE = 'Convidar usu�rio para participar de sua sala';
$MSG_INVITE_LIST = 'Usu�rio(s) convidado(s)';
$MSG_IGNORE_LIST = 'Usu�rio(s) ignorado(s)';
$MSG_IGNORE_NUMBER = 'Total de pessoas que tamb�m ignoram este usu�rio';
$MSG_IGNORE_ALSO = 'N�mero total de pessoas que precisam ignor�-lo tamb�m para que o mesmo seja chutado.';
$MSG_IGNORE_PATEN = 'Voc� pode chutar usu�rios usando a op��o Ignorar.';

// -- Friends --
$MSG_FRIENDS = 'Meus Amigos';
$MSG_FRIENDS_ADD = 'Adicionar Amigo';
$MSG_FRIENDS_ADD_TITLE = 'Adicionar este usu�rio aos meus amigos';
$MSG_FRIENDS_SEARCH = 'Procurar';
$MSG_FRIENDS_ADD_BUTTON = 'Adicionar';
$MSG_FRIENDS_FRIEND = 'Amigo';
$MSG_FRIENDS_LAST_SEEN = 'Visto pela �ltima vez em';
$MSG_FRIENDS_TIME = 'Hora atual';

// -- Toplist --
$TOPLIST                = 'Toplist';
$TOPLIST_HINT_PART1     = 'Todos os tempos de perman�ncia ser�o reduzidos a metade no in�cio de cada m�s.';
$TOPLIST_HINT_PART2        = 'Se voc� ficar mais de 5 minutos sem participar, este tempo nao ser� computado no seu total.';
$TOPLIST_HINT_PART3        = 'Usu�rios que ainda n�o est�o no Top 30:';
$MSG_TOPLIST_RANK       = 'Classifica��o';
$MSG_TOPLIST_ONLINE_TIME = 'Tempo de perman�ncia';
$MSG_TOPLIST_LAST_SEEN  = '�ltima visita...';
$MSG_TOPLIST_SHOW_30        = "Mostrar do 1o. ao 30o. colocados";
$MSG_TOPLIST_SHOW_100        = "Mostrar do 31o. ao 100o. colocados";

// -- Chatmail --
$CHATMAIL       = 'Chatmail';
$INBOX                = 'Caixa de entrada';
$SENT_MAIL        = 'Enviar Mensagem';
$WRITE_MAIL        = 'Escrever Mensagem';
$SENDER                = 'Rementente';
$RECEIPIENT        = 'Destinatario';
$SENT                = 'Enviado';
$RECEIVED        = 'Recebido';
$SUBJECT        = 'Assunto';
$MESSAGE        = 'Mensagem';
$NOSUBJECT        = 'Sem Assunto';
$SENDMAIL        = 'Enviar Mensagem';
$MESSAGE_TO     = 'Mensagem para';
$LEFT_THIS_MESSAGE    = 'deixou esta mensagem';
$FRIENDS_SUBJ        = '�ltimas visitas de seus amigos...';
$WELCOME_SUBJ        = 'Registro bem-sucedido...';
$WELCOME_MSG    = 'Ol�, '.$nick.'! Voc� foi aceito para ser usu�rio do bate-papo. A '.$TEAM_NAME.' espera que voce aproveite bem o bate-papo. Quaisquer d�vidas, clique no bot�o \'Ajuda\'.';
$NO_HIT         = 'Usu�rio n�o encontrado...';
$MSG_SEND_TO        = 'Mensagem a ser enviada para ';//a nickname follows
$CHOOSE_NICK        = 'Escolha um dos apelidos encontrado';
$NO_SELECTION   = 'Faltou digitar um nome.';
$SEND_SUCCESS        = 'Mensagem enviada com sucesso.';

// -- Who is online? --
$WHOISONLINE = 'Quem est� conectado?';
$WHOISONLINE_NUM_ONE = 'No momento h� ';
$WHOISONLINE_NUM_MORE = 'No momento existem ';
$WHOISONLINE_IN_CHAT = 'usu�rio(s) online';
$WHOISONLINE_COLOR_RED = 'Vermelho';
$WHOISONLINE_COLOR_BLUE = 'Azul';

// -- START new Admin-module ---

$MSG_ADM_BACKTOCHAT        = 'Voltar ao bate-papo';
$MSG_ADM_PAGETITLE        = 'Administra��o do bate-papo';
$MSG_ADM_CHANNELS        = 'Administra��o das Salas';
$MSG_ADM_OPERATORS    = 'Administra��o dos Operadores';
$MSG_ADM_COMODERATORS    = 'Administra��o dos Co-Moderadores';
$MSG_ADM_VIPS        = 'Administra��o dos usu�rios VIPs e Moderatores';
$MSG_ADM_HINTS    = 'Mensagens Autom�ticas no bate-papo';
$MSG_ADM_FORUM       =  'Administra��o do F�rum';

// channels
$MSG_ADM_CHANNELNAME ='Nome da sala';
$MSG_ADM_NEWCHANNEL = 'Adicionar sala';
$MSG_ADM_EDITCHANNEL = 'Editar';
$MSG_ADM_DELETECHANNEL = 'Apagar';
$MSG_ADM_CHANNELS_CONFIRM_DEL = 'Voc� deseja realmente apagar esta sala?';

$MSG_ADM_CLEAR_LINES        = 'Apagar Colunas';
$MSG_ADM_SAVE            = 'Salvar';

$MSG_ADM_CHANNELS_FIELDS['Name']    = 'Nome da Sala';
$MSG_ADM_CHANNELS_FIELDS['PASSWORD']    = 'Senha';
$MSG_ADM_CHANNELS_FIELDS['These']    = 'Tema';
$MSG_ADM_CHANNELS_FIELDS['Teilnehmerzahl']='Numero m�ximo de usu�rios simult�neos';
$MSG_ADM_CHANNELS_FIELDS['BG_Color']    = 'Cor de Fundo';
$MSG_ADM_CHANNELS_FIELDS['Logo']    = 'Caminho para o arquivo de imagem no frame de envio de mensagens';
$MSG_ADM_CHANNELS_FIELDS['ExitURL']    = 'P�gina de sa�da';
$MSG_ADM_CHANNELS_FIELDS['moderiert']= 'Modera��o da sala';
$MSG_ADM_CHANNELS_FIELDS['starts_at']= 'A sala se abre �s';
$MSG_ADM_CHANNELS_FIELDS['stops_at']    = 'A sala se fecha �s';
$MSG_ADM_CHANNELS_FIELDS['NICK_COLOR']    = 'Cor dos Apelidos';

$MSG_ADM_CHANNEL_ERROR_NAME = 'Entre um nome v�lido para a sala';
$MSG_ADM_CHANNEL_ERROR_BGCOLOR = 'Entre uma cor de fundo valida';
$MSG_ADM_CHANNEL_ERROR_NICKCOLOR = 'Entre uma cor v�lida para os apelidos';
$MSG_ADM_CHANNEL_ERROR_LOGO = 'Entre um caminho v�lido para a imagem da sala';
$MSG_ADM_CHANNEL_ERROR_EXITURL = 'Entre um caminho v�lido para a p�gina de sa�da';
$MSG_ADM_CHANNEL_ERROR_SAMECOLOR = 'A cor de fundo e a cor dos apelidos nao podem ser as mesmas';
$MSG_ADM_CHANNEL_ERROR_YEAR = 'O Ano � inv�lido';

// Operators
$MSG_ADM_OPERATORNAME ='Nome do operador';
$MSG_ADM_NEWOPERATOR = 'Adicionar operador';
$MSG_ADM_DELETEOPERATOR = 'Apagar';

$MSG_ADM_OPERATORS_ERROR_EMPTY = 'O campo de entrada n�o pode ser vazio!';
$MSG_ADM_OPERATORS_ERROR_NONICK = 'N�o existe usu�rio com este apelido!';

// VIP's
$MSG_ADM_VIPS_CREATE = 'Adicionar usu�rio VIP e Moderador';
$MSG_ADM_VIPS_NICK = 'Apelido do usu�rio VIP';
$MSG_ADM_VIPS_MODERATOR = 'Moderador';
$MSG_ADM_VIPS_CHANNEL = 'Sala';
$MSG_ADM_VIPS_DELETE = 'Apagar';

$MSG_ADM_VIPS_ERROR_MODERATOR1 = 'O campo Moderador n�o pode ser vazio!';
$MSG_ADM_VIPS_ERROR_MODERATOR2 = 'O Moderador precisa ser um usu�rio registrado!';
$MSG_ADM_VIPS_ERROR_VIP1 = 'O campo usu�rio VIP n�o pode ser vazio!';
$MSG_ADM_VIPS_ERROR_VIP2 = 'O usu�rio VIP j� existe';

// co-moderators
$MSG_ADM_COMODERATORNAME ='Nome do Co-Moderador';
$MSG_ADM_NEWCOMODERATOR = 'Adicionar Co-Moderador';
$MSG_ADM_DELETECOMODERATOR = 'Apagar';

$MSG_ADM_COMODERATORS_ERROR_EMPTY = 'O campo de entrada n�o pode ser vazio!';
$MSG_ADM_COMODERATORS_ERROR_NONICK = 'N�o existe usu�rio com este apelido!';

// hints
$MSG_ADM_HINT = 'Dica';
$MSG_ADM_HINTS_SAVE = 'Salvar Dicas';

// forum
$MSG_ADM_FORUM_ADDTOPIC = 'Adicionar novo t�pico';
$MSG_ADM_FORUM_NAME = 'Nome do t�pico';
$MSG_ADM_FORUM_MSGCOUNT = 'Mensagens';
$MSG_ADM_FORUM_EDIT = 'Editar';
$MSG_ADM_FORUM_DELETE = 'Apagar';
$MSG_ADM_FORUM_MESSAGES = 'Editar mensagens';
$MSG_ADM_FORUM_INITMSG = 'Mensagem inicial';
$MSG_ADM_FORUM_INITMSG_TEXT ='Este � um novo t�pico que acabou de ser criado';
$MSG_ADM_FORUM_CONFIRM_DEL = 'Deseja realmente apagar este t�pico?';
$MSG_ADM_FORUM_MSG_CONFIRM_DEL = 'Deseja realmente apagar esta mensagem?';

$MSG_ADM_FORUM_ERROR_TOPIC = 'Entre um nome v�lido para o novo t�pico!';
$MSG_ADM_FORUM_ERROR_INITMSG = 'Entre uma mensagem inicial para o novo t�pico!';
$MSG_ADM_FORUM_ERROR_NICK = 'Entre um apelido v�lido para o novo t�pico!';
$MSG_ADM_FORUM_ERROR_COMMENT = 'O campo Coment�rio nao pode ser vazio';

$MSG_ADM_FORUM_DELWARNING = 'Alerta: Todas as mensagens de um t�pico ser�o perdidas ap�s a dele��o do mesmo';
$MSG_ADM_FORUM_MSG_DELWARNING = 'Alerta: depois de apagar a �ltima mensagem de um t�pico, o mesmo ser� exclu�do';

$MSG_ADM_FORUM_MSGID = 'ID da Mensagem';
$MSG_ADM_FORUM_MSGRANGE = 'Lista de mensagens';
$MSG_ADM_FORUM_MSGCOUNTER = 'No.';
$MSG_ADM_FORUM_NICK = 'Apelido';
$MSG_ADM_FORUM_DATE = 'Data';
$MSG_ADM_FORUM_COMMENT = 'Coment�rio';
$MSG_ADM_FORUM_EMAIL = 'Email';
$MSG_ADM_FORUM_HOMEPAGE = 'Homepage';

$MSG_ADM_FORUM_NAV = 'Navega��o';
$MSG_ADM_FORUM_FROM = 'de';
$MSG_ADM_FORUM_FIRST = 'In�cio';
$MSG_ADM_FORUM_LAST = 'Fim';
$MSG_ADM_FORUM_NEXT = 'Pr�xima';
$MSG_ADM_FORUM_PREV = 'Anterior';

$MSG_ADM_FORUM_EDITMSG = 'Editar mensagem';
$MSG_ADM_FORUM_BACKTOLIST = 'Voltar � lista de mensagens';

// Chatmail to all users
$MSG_ADM_MAILALL = 'Mensagem para todos';
$MSG_ADM_MAILALL_NEWMAIL = 'Enviar nova mensagem para todos os usu�rios';
$MSG_ADM_MAILALL_OLDMAILS = 'Mensagens anteriores :';
$MSG_ADM_MAILALL_SUBJECT = 'Assunto';
$MSG_ADM_MAILALL_DATE = 'Data';
$MSG_ADM_MAILALL_BODY = 'Mensagem';
$MSG_ADM_MAILALL_DELETE = 'Apagar';
$MSG_ADM_MAILALL_SEND = 'Enviar Mensagem';
$MSG_ADM_MAILALL_REFRESH = 'Apagar Conte�do';
$MSG_ADM_MAILALL_ERROR_BODY = 'O Campo de mensagem n�o pode ser vazio';
$MSG_ADM_MAILALL_ERROR_SUBJECT = 'O assunto nao pode ser vazio';
$MSG_ADM_MAILALL_CONFIRM_DEL = 'Deseja realmente apagar esta mensagem?';
$MSG_ADM_MAILALL_SHOW = 'Mostrar';
$MSG_ADM_MAILALL_BACK = 'Voltar a listagem';

$MSG_ADM_MAILALL_RECIEVER = 'Destinat�rio';
$MSG_ADM_MAILALL_ALLUSERS = 'Todos os usu�rios registrados';
$MSG_ADM_MAILALL_OPERATORS = 'Todos os Operadores';
$MSG_ADM_MAILALL_COMODERATORS = 'Todos os Co-Moderadores';

// -- END new Admin-module ---

/*
** Admin-Tool
*/
$BACK_TO_CHAT           = 'Voltar ao bate-papo';
$CHAT_SETUP             = 'Administra��o do bate-papo';
$AUTOMATIC_HINTS        = 'mensagens autom�ticas no bate-papo';
$SETUP_CHANNELS         = 'Administra��o das salas';
$SETUP_MODERATORS       = 'Administra��o dos Operadores da sala';
$SETUP_COMODERATORS     = 'Administra��o dos Co-Moderadores da sala';
$SETUP_VIPS             = 'Administra��o dos usu�rios Vips';
$SETUP_FORUM       =  'Administrar F�rum';
$SAVE_HINTS             = 'salvar dicas';
$CREATE_CHANNEL         = 'criar uma nova sala';
$MODERATORS             = 'Moderadores';
$GODFATHERS             = 'Operadores';
$MODERATOR              = 'Moderador';
$COMODERATORS           = 'Co-Moderadores';
$VIPS                   = 'VIP\'s';
$VIP                    = 'VIP';
$ADD_REMOVE             = 'adicionar/remover';
$SAVE                   = 'salvar';
$CLEAR_LINES            = 'Apagar todas as linhas da sala';
$CHAT_OVERLOAD          = 'Desculpe-nos, a sala est� cheia no momento.';
$REPEAT_LOGIN           = 'Tente entrar novamente!';
$FEHLER                 = 'Erro';
$ERRORMAIL_SUBJECT                 = 'Erro na conex�o com o banco de dados';
$ERRORMAIL_BODY                    = "o chat n�o conseguiu conectar-se ao banco de dados.\n Se o chat estava rodando normalmente, parece que o servidor chegou a sua carga m�ximo. Pode ser necess�rio atualiz�-lo.\n\n Se esta � uma nova instala��o, provavelmente h� algo errado no arquivo default_inc.php. Verifique se databasehost, databaseuser e datanasepassword est�o corretos e sem espa�os. Verifique tamb�m se a base est� corretamente instalada.";

$TBL_FIELDS['Id']       = '';
$TBL_FIELDS['Name']     = 'Nome da Sala';
$TBL_FIELDS['PASSWORD'] = 'Senha';
$TBL_FIELDS['These']    = 'Estes';
$TBL_FIELDS['Teilnehmerzahl']='N�mero m�ximo de usu�rios<br>0=ilimitado';
$TBL_FIELDS['BG_Color'] = 'Cor de fundo da �rea de texto';
$TBL_FIELDS['Logo']     = 'Caminho para o arquivo de imagem do frame de digita��o';
$TBL_FIELDS['ExitURL']  = 'p�gina de sa�da';
$TBL_FIELDS['moderiert']= 'Moderada? <BR>[1=sim/0=n�o]';
$TBL_FIELDS['starts_at']= 'A sala abre �s';
$TBL_FIELDS['stops_at'] = 'A sala fecha �s';
$TBL_FIELDS['NICK_COLOR']='Cor dos apelidos';

/*
 * login and registration messages
 */
$message[session_name]='N�o foi poss�vel registrar a sess�o.';
$message[error_1]='O apelido j� encontra-se registrado, ou existe alguem no bate-papo com o mesmo.';
$message[error_default]='N�o � possivel Participar';
$message[error_2]='Participa��o negada! Senha incorreta.';
$message[error_3]='As senhas nao combinam. Tente novamente!';
$message[error_4]='Digite uma senha e um endere�o de E-Mail!';
$message[error_5]='Palavras inv�lidas encontradas no seu apelido!';
$message[error_6]='Express�es inv�lidas encontradas no seu apelido!';
$message[error_7]='O n�mero m�ximo de usu�rios simult�neos foi atingido. <br> Tente novamente mais tarde.';
$message[error_8]='Um c�digo de cor inv�lido foi detectado.';
$REGISTER_NICK = 'Eu quero me registrar!';
$REGISTER_TITLE = 'Registro';
$REGISTER_SUBMIT = 'registrar';
$REGISTER_SUCCESS_1 = 'Registro bem-sucedido!<br> Entre no';
$REGISTER_SUCCESS_2 = ' bate-papo</a> agora.';

/*
 * Forum-Messages
 */
$FORUM[title]             = 'Quadro de mensagens';
$FORUM[save_message]      = 'Successo! Seu artigo est� no ar.';
$FORUM[save_message_empty]= 'Seu artigo n�o foi salvo por estar vazio.';
$FORUM[save_nickname]     = 'Apelido: ';
$FORUM[save_email]        = 'E-mail:';
$FORUM[save_homepage]     = 'Home page:';
$FORUM[save_comment]      = 'Coment�rio:';
$FORUM[save_topic]        = 'para o t�pico ';
$FORUM[our_topics]        = 'Nossos t�picos';
$FORUM[save_next]         = 'pr�xima em ';
$FORUM[save_read]         = 'Quero ler!';
$FORUM[write]             = 'Escrever um artigo';
$FORUM[write_header]      = 'Agora voc� pode escrever um novo artigo.';
$FORUM[write_topic]       = 'Seu t�pico: ';
$FORUM[write_comment]     = 'Seu coment�rio:';
$FORUM[write_submit]      = 'submeter';
$FORUM[no_frame]          = 'Infelizmente, seu navegador nao suporta frames.';
$FORUM[back_to]           = 'voltar para';
$FORUM[article_list]      = 'Listar todos os artigos';
$FORUM[left_theme]        = 'T�pico';
$FORUM[left_refresh]      = 'Atualizar';
$FORUM[welcome]             = '        <H3>Clique nos t�picos a esquerda para ver a lista de artigos.<BR>Para ler um artigo, clique em um apelido.</H3> Novos artigos em cima.<BR> Divirta-se!';
$FORUM[wrote]             = 'escreveu';
$FORUM[meeting]           = 'Reuni�o';
$FORUM[technology]        = 'Tecnologia';
$FORUM[babble_topic]      = 't�pico de conversa fiada';
$FORUM[newbees]           = 'Novatos';
$FORUM[all_themes]      = ' List de temas';
$FORUM[subject]                 = 'Assunto';

// confirmation page
$CONFIRMATION_TITLE = 'Finish Registration';
$CONFIRMATION_OK_1 = 'Welcome! You are now a member of our online community.<br>Click here';
$CONFIRMATION_OK_2 = 'to login!</a><br>Have fun!';
$CONFIRMATION_FAILED = 'We are sorry, but your nickname could not be activated. Please try again!';

// Operator-Interface
$MSG_OP_TITLE = 'Operator-Function';
$MSG_OP_DESCRIPTION = 'Select a chatter to kick :';
$MSG_OP_INFO = '<b><u>Information :</u></b>';
$MSG_OP_KICKBUTTON = 'kick';
$MSG_OP_INFOBUTTON = 'Info';
$MSG_OP_PERMANENT = 'Kick chatter permanetly';

$MSG_OP_INFOTEXT_GENERAL  = 'Operators cannot be kicked. Therefore, they are not listed here. !';

$MSG_OP_INFOTEXT_INFOABOUT  = "Information about ";
$MSG_OP_INFOTEXT_KICKSSOFAR .= "Kicks so far :";
$MSG_OP_INFOTEXT_KICKCOUNT .= "Kick count :";
$MSG_OP_INFOTEXT_KICKTIME ="New locktime (minutes) :";
$MSG_OP_INFOTEXT_NEXTKICKTIME ="Locktime at next kick (minutes) :";
$MSG_OP_INFOTEXT_KICKED = "has been kicked out of the chat !";
$MSG_OP_INFOTEXT_ALREADYKICKED = "Has already been kicked out of the chat by another operator. !";


//USERPAGE
$UP_FROM = 'Userpage from';
$UP_UNKNOWN_USER = 'Don&acute;t know this user';
$UP_TOPLISTPLACE = 'Toplistplace';
$UP_SEX = 'Sex';
$UP_INFO = 'Info about me';
$UP_HOBBY = 'My hobbies';
$UP_BIRTHDATE = 'Birthdate';
$UP_AGE = 'Age';
$UP_HOME = 'Home';
$UP_FRIENDS = 'My friends at';
$UP_GB_ERROR = 'You have to fill in a text at least';
$UP_GB_SAVED = 'Your guestbook entry was saved';
$UP_GB_BACK = 'Back to guestbook';
$UP_GB_SIGNHERE = 'Here you can sign the guestbook';
$UP_GB_NOTLOGGEDIN = 'To sign the guestbook you have to login into the chat';
$UP_GB_MSGCOUNT = 'Count of entries';
$UP_GB_MOVE = 'Browse the guestbook';
$UP_GB_WROTE = 'wrote at';
$UP_GB_CONFIRM_DELETE = 'Sure to delete?';
$UP_GB_ENTRY ='Sign the guestbook';
$UP_GB_COMMENT = 'Comment';
$UP_GB_DOIT = 'Save';
$UP_GB_DELETE = 'delete';

//main menu
$MAIN_INFO_REGISTER = 'Register your nickname.';
$MAIN_INFO_PROFILE = 'Modify personal data and create your userpage.';
$MAIN_INFO_CHATMAIL = 'Send and receive mail messages within the chat.';
$MAIN_INFO_INVITE = 'Invite chatters into your own channel or ignore them.';
$MAIN_INFO_FRIENDS = 'Add a chatter to your friends.';
$MAIN_INFO_TOPLIST = 'List of all the chatters that have been here the most und longest.';
$MAIN_INFO_CLICK_UP = 'Click on a nickname to see the chatter\'s userpage.';
$MAIN_INFO_FORUM = 'Here you can communicate with other chatters about specific topics.';
$MAIN_INFO_HELP = 'Here you can find some help for all the chat\'s funtions.';
$MAIN_INFO_FORGOTPWD = 'Have your password sent to you by email.';
?>
