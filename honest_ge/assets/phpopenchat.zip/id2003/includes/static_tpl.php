<?
/*   ********************************************************************   **
**   Copyright (C) 1995-2000 Michael Oertel                                 **
**   Copyright (C) 2000-     PHPOpenChat Development Team                   **
**   http://www.ortelius.de/phpopenchat/                                    **
**                                                                          **
**   This program is free software. You can redistribute it and/or modify   **
**   it under the terms of the PHPOpenChat License Version 1.0              **
**                                                                          **
**   This program is distributed in the hope that it will be useful,        **
**   but WITHOUT ANY WARRANTY, without even the implied warranty of         **
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   **
**                                                                          **
**   You should have received a copy of the PHPOpenChat License             **
**   along with this program.                                               **
**   ********************************************************************   */

/*
Don't remove tags containing php tags like <?echo $var?> from this file! You can disable features by editing the file default_inc.php
*/?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<script language="JavaScript">
//funktion for text scrolling
function scroll_me() {
  if (parent.scroll_it) {
    parent.scroll_it();
    return;
  }
}
function setFocus(){
  parent.input.document.input.chat.focus();
}

function openWindow(){
  setFocus();
  var newWindow;
  newWindow = window.open('','Color','scrollbars=no,toolbar=no,location=no,directories=no,status=no,menubar=no,resizable=no,width=300,height=450,screenX=50,screenY=250');

}
function OpenDialog(file) {
	  setFocus();
        // open window
         var newWindow;
        newWindow=window.open(file,"","scrollbars=yes,directories=no,width=640,height=480")

        if (newWindow != null && newWindow.opener == null)
                newWindow.opener=window
}
function OpenMainMenu(file) {
  var FunctionWindow;
  FunctionWindow=window.open(file,"function","scrollbars=yes,directories=no,width=791,height=522")
  if (FunctionWindow != null && FunctionWindow.opener == null)
    FunctionWindow.opener=window
    FunctionWindow.moveTo(0,0)
    FunctionWindow.focus()
}
</script>
<title>PHPOpenChat</title>
</head>
<BODY BGCOLOR="#FFFFFF" BACKGROUND="<?echo "images/$BACKGROUNDIMAGE"?>" text="#000000" link="#007b39" vlink="#007b39" onLoad="<?echo $js_onload?>">
<br>
<TABLE cellpadding="0" cellspacing="5" border="0">
<span>
<form action="static.<?echo$FILE_EXTENSION?>" name="input" method="post">
<tr><TD>
<font "font-size: 12px;"><?echo $help_button?></font>
</td><td>
<span><?echo $forum_button?></span>
</td>
</tr>
<tr><td>
<?echo $button_whoisonline?>
</td><td>
<?echo $messages_button?>
</td></tr>
<tr><td><?echo $ignore_invite_button?></td>
<td>
<?echo $button_notify?>
</td></tr>
<tr><td>
<?echo $button_operator?>
</td></tr>
<tr><td> <?echo $switch_auto_scrolling?></td><td><A HREF="<?echo $exit_link?>" TARGET="_top" onMouseOver="window.status='<?echo $LEAVE_CHAT?>'; return true;">
		  <?echo $LEAVE_CHAT?></A></td></tr>
</table>
</form>
</span>
</body>
</html>
