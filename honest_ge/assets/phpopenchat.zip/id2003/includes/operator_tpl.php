<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<title><? echo$MSG_OP_TITLE?></title>

 <style type="text/css">
<!--
 .chatterlist
   { width:200px; }

 .button
  { width:70px; }
-->
</style>

</head>
<body BACKGROUND="<?echo $BG_IMAGE?>" bgcolor="#FFFFFF" LINK="#0000FF" VLINK="#0000FF" ALINK="#0000FF">

<FORM ACTION="<?echo'operator.'.$FILE_EXTENSION?>" METHOD="POST">

<table width="590">
  <tr>
    <td>
      <font face="arial,helvetica,sans-serif" size="4"><b><?echo $MSG_OP_TITLE?></b></font><br><br>
      <font face="arial,helvetica,sans-serif" size="2"><?echo $MSG_OP_DESCRIPTION?></font><br>

      <HR><br>
      <table cellpadding="10"><tr>

       <td align="left" bgcolor="#e4e4e4">
        <center>
          <?echo $permissions?><br>
          <?echo $select_of_all_chatters?><br>
          <br>
          <input type="submit" name="op_info" class="button" value=" <?echo $MSG_OP_INFOBUTTON?> ">
          &nbsp;&nbsp;
          <input type="submit" name="op_kick" class="button" value=" <?echo $MSG_OP_KICKBUTTON?> ">
          <br><br>
          <input type="checkbox" name="permanent" value="1"><? echo $MSG_OP_PERMANENT; ?>
          <br><br>
        </center>
       </td>
       <td align="left" valign="top">
          <font face="arial,helvetica,sans-serif" size="2"><?echo $MSG_OP_INFO ?></font>
          <br><br>
          <font face="arial,helvetica,sans-serif" size="2"><?echo $MSG_OP_INFOTEXT ?></font>
       </td>
      </table>

      <BR>
	   <HR>
	   <BR>
	   <DIV ALIGN="CENTER"><INPUT type="button" Value=" <?echo $CLOSE_WINDOW?> " onClick="window.close()"></DIV>
    </TD>
  </TR>
</TABLE>

</FORM>

</body>
</html>

