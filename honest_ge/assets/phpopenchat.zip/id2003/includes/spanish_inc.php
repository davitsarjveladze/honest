<?

// Written by: Alejandro D. Burne <adburne@asocmedrosario.com.ar>
// Completado por: J.M. Goikoetxea <josema@milenium.com>
// PHPOpenChat Version: 2.1.x

$LANG			= "es";

$YES = 'Si';
$NO = 'No';

$MODERATOR_NAME   	= "System";
$TEAM_NAME	  	= "Chat-Team";
$STATUSFILTERNAME 	= "Filtro estado";
$TWADDLEFILTERNAME	= "Filtro tonterias";
$WEEKDAY["Mon"]         = "Lun";
$WEEKDAY["Tue"]         = "Mar";
$WEEKDAY["Wed"]         = "Mie";
$WEEKDAY["Thu"]		= "Jue";
$WEEKDAY["Fri"]		= "Vie";
$WEEKDAY["Sat"]		= "Sab";
$WEEKDAY["Sun"]		= "Dom";
$CHANNEL		= "Canal";
$WRONGFORM		= "Wrong form detected!";
$READING_MSG		= "leer mensajes desde";
$COME_FROM		= "viene de";
$COME_FROM_PRIVAT	= "viene del canal privado de";
$JOINING_IN		= "se nos une";
$LEAVES_US		= "nos deja";
$GOES_TO		= "va hacia";
$NO_PARTICIPATE		= "No deseo participar";
$NICK_NAME		= "Alias";
$PASSWORD		= "Clave";
$MAIL_ADDRESS		= "Direccion E-Mail";
$AGAIN			= "otra vez";
$GO			= "Ingresar!";
$FIRST_TIME_ONLY	= "Solo la primera vez";
$LEAVE_CHAT		= "Dejar el Chat";
$WISPER_TO		= "susurrar a";
$SAY_TO			= "habla a";
$WISPERS_TO		= "susurra a";
$SAYS_TO                = "says to";
$SAY_IT			= "decirlo";
$SAYS			= "says";
$AUTOSCROLLING		= "Refrescado de pantalla";
$COLOR_CHANGE		= "Nuevo color para";
$OLD_COLOR		= "color anterior";
$NEW_COLOR 		= "color nuevo";
$HELP			= "Ayuda";
$ALL			= "todos";
$ON			= "normal";
$ON1			= "r�pido";
$ON2			= "m�s r�pido";
$OFF			= "desactivado";
$MESSAGES		= "Mensajes";
$CLOSE_WINDOW		= "Cerrar la ventana";
$EDIT			= "editar...";
$SEND_MSG		= "Enviar un mensaje";
$NICK_IS		= "Su alias es:";
$CHOOSE_LETTER		= "Seleccione la primer letra del nombre!";
$CLEAR			= "limpiar todo";
$UPDATE_TEXT		= "Actualizar el texto";
$KICKED			= "fue pateado";
$SOMEBODY		= "Alguien";
$LOOKING_IN		= "mirando";
$CHANGE_COLOR		= "cambiar color";
$ACCEPT_ROW		= "aceptar texto";
$MODERATOR_MESSAGE	= "Mensaje al moderador";
$CHANNEL_EXPIRED	= "Lo siento, este canal ha expirado!";
$CHANNEL_STARTS_AT	= "Proximo chat:";//Zeitangaben folgen
$CHANNEL_HINT		= "Se encuentra en el canal privado de";//nick name follows
$INACTIVE		= "Estuvo inactivo un largo tiempo. Por favor vuelva a ingresar.";
$UNLOCK_CHANNEL		= "desbloquear canal";
$SOMEBODY		= "Alguien";
$REPLY_TO		= "responder a";
$IS_DISCHARGED		= "no esta mas invitado a mi canal privado";
$IS_INVITED		= "esta invitado a mi canal privado";
$ENTER_YOUR_CODE	= "Ingrese su propio codigo";
$HAS_CHANGED_COLOR	= "ha cambiado el color del texto";
$BANNED_MSG		= "Ud. ha sido retirado del chat por un par de semanas!";
$NOTIFY			= "Amigos";
$ADD_CHATTER		= "Agregar este usuario a mi lista de amigos!";
$LAST_LOGON		= "ultima visita";
$USERPROFILE		= "Perfil del Usuario";
$PWD_REPEATE		= "Repetir la clave";
$HINT			= "Sugerencia";
$HOST			= "Host";
$URL_FORMAT_HINT	= "Por favor no olvide el protocolo (http://) en la URL!";
$I_WANT_TO_CHAT         = "quiero chatear";
$GREETINGS[1]		= "Buen dia!";
$GREETINGS[2]           = "Hola!";
$GREETINGS[3]		= "Hola!";
$GREETINGS[4]		= "Buenas tardes";
$GREETINGS[5]		= "Buenas noches";
$NUM_USER		= "Numero de usuarios registrados";
$CHATTERS_ONLINE	= "Usuarios en linea";
$CHATTERS_ONLINE_24H    = 'Entradas en las �ltimas 24 horas';
$LOCAL_TIME		= "Hora local";
$MY_PROFILE		= "Mi perfil";
$FORGOT_PWD		= "Olvido su clave?";
$TELL_US                = "y cuentenos algo...";
$COME_IN                = "ingrese";
$WHATS_UP               = "que ocurre?";
$CHAT_WITH_US           = "chatee con nosotros";
$IS_CHATTING_IN		= "esta en el canal ";//a channel name follows
$NOT_ONLINE		= "no esta en linea.";//a nickname in front
$OPENED_TO_PUB		= 'fue abierto al publico';
$SEND_IMG		= 'Enviar imagen';
$CHOOSE_IMG		= 'Elige una imagen';
$USER_ICON		= 'Tu imagen el el chat';
$NEW_IMG_HINT		= 'Si no ves tu nueva imagen, limpia la cache de tu navegador y recarga.';
$PWD_DONT_MATCH		= 'La contrase�a no coincide';
$MAX_FILE_EXCEEDED	= 'Maximum of file size exceeded! The file size has to be smaller than';//a size follows
$MAX_SIZE_EXCEEDED	= 'Maximo tama�o de archivo excedido!';
$HINT_IMG_SIZE		= 'El tama�o de tu imagen es';//x,y values follows
$ALLOWED		= 'Permitido';
$MIME_ERROR		= 'Mal formato de archivo! Esta permitido \'image/gif\' your type is ';//a type follows
$INVALID_NICK		= 'Este nick todavia no ha sido registrado!';
$NO_EMPTY_PWD		= 'Las contrase�as vacias no se permiten!';
$GODFATHER		= 'Padrino';
$MSG_KICKED		= "Fuiste kickeado!";
$MSG_SEARCH		= 'Buscar';
$FLOODING_MSG1		= 'Has dicho lo mismo tres veces. Por favor, intenta mentener una conversacon normal e inteligente.';
$FLOODING_MSG2		= 'Has vuelto a decir lo mismo.  Si lo vuelves a hacer ser�s expulsado del chat, capullo';
$NO_SCRIPT  = 'Activa JavaScript (En IE se llama "Active Scripting") antes de entrar en el chat!';

//PROFILE
$PROFIL_OPTIONAL = 'additional voluntary details for your userpage';
$PROFIL_MOTTO = 'Your motto';
$PROFIL_INFO = 'Info about you';
$PROFIL_SHOW_EMAIL = 'Show other chatters my E-mailadress';
$PROFIL_YES = 'Yes';
$PROFIL_NO = 'No';
$PROFIL_SHOW_FRIENDS = 'Show others my chatfriends';
$PROFIL_SHOW_BIRTHDATE = 'Show my Birthdate';
$PROFIL_BIRTHDATE = 'Birthdate';
$PROFIL_HOMEPAGE = 'Homepage';
$PROFIL_HOBBIES = 'Hobbies';
$PROFIL_GENDER = 'Gender';
$PROFIL_MALE = 'male';
$PROFIL_FEMALE = 'female';
$PROFIL_HOME = 'I live in';
$PROFIL_ICQ = 'My ICQ-Number';
$PROFIL_PIC = 'URL to my picture';
$PROFIL_UPDATE_SUCCESS = 'Your profil is successful updated.';
$PROFIL_BACK_TO = 'Back to profil';
$PROFIL_SAVE_CHANGES = 'save changes';

// statistics
$LAST_REGISTERED_USER   = 'Ultimo usuario registrado';
$TOTAL_POSTS            = 'Total envios';
$NUM_POSTS              = 'Envios en la base de datos';
$NEW_POSTS_LAST_24H     = 'Nuevos envios en las ultimas 24 horas';
$LAST_POST              = 'Ultimo envio';
$TOTAL_MAILS            = 'Total correos';
$NUM_MAILS              = 'Correos en la base de datos';
$NEW_MAILS_LAST_24H     = 'Nuevos correos en las ultimas 24 horas';

// send password to user
$MSG_SENDPWD        = 'Enviar clave olvidada por correo';
$MSG_SENDPWD_SUCCESS = '<font color=green>Su clave ha sido enviada por correo a la direccion por Ud. especificada cuando se registro.</font>';
$MSG_SENDPWD_NONICK = '<font color=red>No hay ningun chatter con este nick en la base de datos !</font>';
$MSG_SENDPWD_NOEMAIL = '<font color=red>Su clave no ha podido ser enviada. No se especifico direccion de correo con su alias.</font>';
$MSG_SENDPWD_SUBJECT = 'Su clave solicitada';
$MSG_SENDPWD_MSGTXT   = 'Hola,\n\nsu clave es: ';
$MSG_SENDPWD_SUBMIT = 'Enviar';
$MSG_SENDPWD_NICKNAME = 'Nick : ';

// -- Invite & Ignore --
$IGNORE_INVITE		= "Ignorar/Invitar";
$ALL_CHATTER		= "Todos los usuarios";
$MSG_INVITE 		= "Invite chatter";
$MSG_IGNORE 		= "Ignore chatter";
$MSG_INVITE_TITLE	= "Invitar un usuario del chat";
$MSG_INVITE_LIST	= "Usuario invitado a su canal privado";
$MSG_IGNORE_LIST	= "Usuario ignorado";
$MSG_IGNORE_NUMBER	= "Numero de usuarios que ignoraron a este usuario";
$MSG_IGNORE_ALSO	= "Cantidad de usuario que lo deben ignorar para patearlo";
$MSG_IGNORE_PATEN	= "Se pude patear usuarios usando la opcion ignorar";

// -- Friends --
$MSG_FRIENDS_ADD = 'A�adir colega';
$MSG_FRIENDS_ADD_TITLE = 'A�adir este chatter a mis colegas';
$MSG_FRIENDS_SEARCH = 'Buscar';
$MSG_FRIENDS_ADD_BUTTON = 'A�adir';
$MSG_FRIENDS_FRIEND = 'Colega';
$MSG_FRIENDS_LAST_SEEN = 'Last seen';

// -- Toplist --
$TOPLIST                = 'Ranking de usuarios';
$TOPLIST_HINT_PART1     = 'Promediamos el tiempo que est�s en linea al principio de cada mes.';
$TOPLIST_HINT_PART2	= 'Si no prmaneces m�s de cinco minutos seguidos en el chat, este tiempo no ser� contablizado a la hora de establecer la media.';
$TOPLIST_HINT_PART3	= 'He aqu� todos los chatters que todav�a no est�n entre los 30 primeros:';
$MSG_TOPLIST_RANK       = 'Ranking';
$MSG_TOPLIST_ONLINE_TIME = 'Suma de tiempo en linea';
$MSG_TOPLIST_LAST_SEEN  = 'Ultima vez el d�a';
$MSG_TOPLIST_SHOW_30	= "Mostrar ranking de 1 a 30";
$MSG_TOPLIST_SHOW_100	= "Mostrar ranking de 31 a 100";

// -- Chatmail --
$CHATMAIL       = 'Chatmail';
$INBOX		= 'Buzon de entrada';
$SENT_MAIL	= 'Enviados';
$WRITE_MAIL	= 'Componer';
$SENDER		= 'Remitente';
$RECEIPIENT	= 'Destinatario';
$SENT		= 'Enviado';
$RECEIVED	= 'Recibido';
$SUBJECT	= 'Asunto';
$MESSAGE	= 'Mensaje';
$NOSUBJECT	= 'Sin asunto';
$SENDMAIL	= 'Enviar';
$LEFT_THIS_MESSAGE = "dejar este mensaje";
$FRIENDS_SUBJ	= 'Ultima visita de sus amigos...';
$WELCOME_SUBJ	= 'Registrierung erfolgreich...';
$WELCOME_MSG    = 'Hola $nick! Ha sido aceptedo en la comunidad del chat. $TEAM_NAME deseamos que lo disfrute. Si tiene dudas, puede hacer click en la ayuda. CU';
$NO_HIT         = 'Lo siento, el usuario no se ha encontrado';
$MSG_SEND_TO	= 'El mensaje ser� enviado a (La primer letra del alias es suficiente)';//a nickname follows
$CHOOSE_NICK	= 'Seleccione uno de los alias encontrados';
$NO_SELECTION   = 'Olvidaste introducir un nombre.';
$SEND_SUCCESS	= 'El correo se ha enviado correctamente.';

// -- Who is online? --
$WHOISONLINE = '�Qui�n est� en linea?';
$WHOISONLINE_NUM_ONE = 'Right now there is';
$WHOISONLINE_NUM_MORE = 'Right now there are';
$WHOISONLINE_IN_CHAT = 'Usuario(s) conectado(s)';
$WHOISONLINE_COLOR_RED = 'Red';
$WHOISONLINE_COLOR_BLUE = 'Blue';

// -- START new Admin-module ---

$MSG_ADM_BACKTOCHAT        = 'Volver al Chat';
$MSG_ADM_PAGETITLE        = 'Administracion del Chat';
$MSG_ADM_CHANNELS        = 'Administracion de Canales';
$MSG_ADM_OPERATORS    = 'Administracion de Operadores';
$MSG_ADM_COMODERATORS    = 'Administracion de Co-Moderadores';
$MSG_ADM_VIPS        = 'Administracion of VIPs y Moderadores';
$MSG_ADM_HINTS    = 'Mensajes automaticos en el Chat';
$MSG_ADM_FORUM       =  'Administracion del Forum';

// channels
$MSG_ADM_CHANNELNAME ='Nombre del canal';
$MSG_ADM_NEWCHANNEL = 'A�adir canal';
$MSG_ADM_EDITCHANNEL = 'Editar';
$MSG_ADM_DELETECHANNEL = 'Borrar';
$MSG_ADM_CHANNELS_CONFIRM_DEL = '�De verdad quieres borrar el canal?';
$MSG_ADM_CLEAR_LINES        = 'Borrar di�logos del canal';
$MSG_ADM_SAVE            = 'Guardar Datos';

$MSG_ADM_CHANNELS_FIELDS['Name']    = 'Nombre del canal';
$MSG_ADM_CHANNELS_FIELDS['PASSWORD']    = 'Contrase�a';
$MSG_ADM_CHANNELS_FIELDS['These']    = 'Tema';
$MSG_ADM_CHANNELS_FIELDS['Teilnehmerzahl']='N�mero m�ximo de chatters';
$MSG_ADM_CHANNELS_FIELDS['BG_Color']    = 'Color de fondo';
$MSG_ADM_CHANNELS_FIELDS['Logo']    = 'Path to the image file in the input frame';
$MSG_ADM_CHANNELS_FIELDS['ExitURL']    = 'URL de salida';
$MSG_ADM_CHANNELS_FIELDS['moderiert']= 'Moderaci�n del canal';
$MSG_ADM_CHANNELS_FIELDS['starts_at']= 'El canal comienza a';
$MSG_ADM_CHANNELS_FIELDS['stops_at']    = 'El canal termina a';
$MSG_ADM_CHANNELS_FIELDS['NICK_COLOR']    = 'Nickname color';

$MSG_ADM_CHANNEL_ERROR_NAME = 'Por favor, introduce un nombre v�lido para el canal';
$MSG_ADM_CHANNEL_ERROR_BGCOLOR = 'Por favor, introduce un color de fondo v�lido';
$MSG_ADM_CHANNEL_ERROR_NICKCOLOR = 'Por favor, introduce un color de nick valido';
$MSG_ADM_CHANNEL_ERROR_LOGO = 'Por favor, introduce una ruta v�lida par la im�gen del canal';
$MSG_ADM_CHANNEL_ERROR_EXITURL = 'Por favor, introduce una URL v�lida de salida';
$MSG_ADM_CHANNEL_ERROR_SAMECOLOR = 'El color de fondo y el color de nick deben ser diferentes';
$MSG_ADM_CHANNEL_ERROR_YEAR = 'El a�o es inv�lido';

// Operators
$MSG_ADM_OPERATORNAME ='Nombre del operador';
$MSG_ADM_NEWOPERATOR = 'A�adir operador';
$MSG_ADM_DELETEOPERATOR = 'Borrar';

$MSG_ADM_OPERATORS_ERROR_EMPTY = 'El campo no debe estar vacio !';
$MSG_ADM_OPERATORS_ERROR_NONICK = 'No hay ningun chatter con este nick !';

// VIP's
$MSG_ADM_VIPS_CREATE = 'A�adir VIP y Moderador';
$MSG_ADM_VIPS_NICK = 'Nick del  VIP';
$MSG_ADM_VIPS_MODERATOR = 'Moderador';
$MSG_ADM_VIPS_CHANNEL = 'Canal';
$MSG_ADM_VIPS_DELETE = 'Borrar';

$MSG_ADM_VIPS_ERROR_MODERATOR1 = 'El campo del moderador no puede estar vacio !';
$MSG_ADM_VIPS_ERROR_MODERATOR2 = 'El moderador debe ser un chatter registrado !';
$MSG_ADM_VIPS_ERROR_VIP1 = 'El campo VIP no puede estar vacio !';
$MSG_ADM_VIPS_ERROR_VIP2 = 'El VIP ya existe';

// co-moderators
$MSG_ADM_COMODERATORNAME ='Nombre del Co-moderador';
$MSG_ADM_NEWCOMODERATOR = 'A�adir Co-moderador';
$MSG_ADM_DELETECOMODERATOR = 'Borrar';

$MSG_ADM_COMODERATORS_ERROR_EMPTY = 'El campo de entrada no puede estar vacio !';
$MSG_ADM_COMODERATORS_ERROR_NONICK = 'No hay ningun chatter con este nick !';

// hints
$MSG_ADM_HINT = 'Hint';
$MSG_ADM_HINTS_SAVE = 'Guardar hints';

// forum
$MSG_ADM_FORUM_ADDTOPIC = 'A�adir nuevo tema';
$MSG_ADM_FORUM_NAME = 'Nombre del tema';
$MSG_ADM_FORUM_MSGCOUNT = 'Mensajes';
$MSG_ADM_FORUM_EDIT = 'Editar';
$MSG_ADM_FORUM_DELETE = 'Borrar';
$MSG_ADM_FORUM_MESSAGES = 'Editar mensajes';
$MSG_ADM_FORUM_INITMSG = 'Mensaje inicial';
$MSG_ADM_FORUM_INITMSG_TEXT ='Este es un nuevo tema que acaba de ser abiero';
$MSG_ADM_FORUM_CONFIRM_DEL = '�De verdad quieres borrar este tema?';
$MSG_ADM_FORUM_MSG_CONFIRM_DEL = '�De verdad quieres borrar este mensaje?';

$MSG_ADM_FORUM_ERROR_TOPIC = 'Por favor introduce un nombre v�lido para el tema!';
$MSG_ADM_FORUM_ERROR_INITMSG = 'Por favor, introduce un mensaje inicial para el nuevo tema!';
$MSG_ADM_FORUM_ERROR_NICK = 'Por favor, introduce un nuevo nick para el tema!';
$MSG_ADM_FORUM_ERROR_COMMENT = 'El campo de comentarios no puede estar vacio';

$MSG_ADM_FORUM_DELWARNING = 'Atenci�n: todos los mensajes del tema se perder�n al ser borrado �ste';
$MSG_ADM_FORUM_MSG_DELWARNING = 'Atenci�n : Al borrar todos los mensajes del t�pico, �ste desaparecera';

$MSG_ADM_FORUM_MSGID = 'ID Mensaje';
$MSG_ADM_FORUM_MSGRANGE = 'Panor�mica de mensajes';
$MSG_ADM_FORUM_MSGCOUNTER = 'N�';
$MSG_ADM_FORUM_NICK = 'Nick';
$MSG_ADM_FORUM_DATE = 'Fecha';
$MSG_ADM_FORUM_COMMENT = 'Comentario';
$MSG_ADM_FORUM_EMAIL = 'Email';
$MSG_ADM_FORUM_HOMEPAGE = 'Homepage';

$MSG_ADM_FORUM_NAV = 'Navegacion';
$MSG_ADM_FORUM_FROM = 'de';
$MSG_ADM_FORUM_FIRST = 'Empezar';
$MSG_ADM_FORUM_LAST = 'Fin';
$MSG_ADM_FORUM_NEXT = 'Siguiente';
$MSG_ADM_FORUM_PREV = 'Anterior';

$MSG_ADM_FORUM_EDITMSG = 'Editae mensaje';
$MSG_ADM_FORUM_BACKTOLIST = 'Volver a la panor�mica de mensajes';

// Chatmail to all users
$MSG_ADM_MAILALL = 'Chatmail para todo el mundo';
$MSG_ADM_MAILALL_NEWMAIL = 'Escribir nuevo chatmail para todo el mundo';
$MSG_ADM_MAILALL_OLDMAILS = 'Mensajes anteriores :';
$MSG_ADM_MAILALL_SUBJECT = 'Asunto';
$MSG_ADM_MAILALL_DATE = 'Fecha';
$MSG_ADM_MAILALL_BODY = 'Mensaje';
$MSG_ADM_MAILALL_DELETE = 'Borrar';
$MSG_ADM_MAILALL_SEND = 'Enviar mensaje';
$MSG_ADM_MAILALL_REFRESH = 'Borrar contenido';
$MSG_ADM_MAILALL_ERROR_BODY = 'El campo del mensaje no puede estar vacio';
$MSG_ADM_MAILALL_ERROR_SUBJECT = 'El campo del adunto no puede estar vacio';
$MSG_ADM_MAILALL_CONFIRM_DEL = '�De verdad quieres borrar este mensaje?';
$MSG_ADM_MAILALL_SHOW = 'Mostrar';
$MSG_ADM_MAILALL_BACK = 'Volver';

$MSG_ADM_MAILALL_RECIEVER = 'Reciever';
$MSG_ADM_MAILALL_ALLUSERS = 'Todos los chatters registrados';
$MSG_ADM_MAILALL_OPERATORS = 'Todos los operadores';
$MSG_ADM_MAILALL_COMODERATORS = 'Todos los co-moderadores';

// -- END new Admin-module ---

/*
** Admin-Tool
*/
$BACK_TO_CHAT		= "volver al chat";
$CHAT_SETUP		= "Administracion del Chat";
$AUTOMATIC_HINTS	= "mensajes automaticos en el chat";
$SETUP_CHANNELS		= "Administracion de canales";
$SETUP_MODERATORS	= "Administracion de abuelos del chat";
$SETUP_COMODERATORS	= "Administracion de co-moderadores";
$SETUP_VIPS		= "Administracion de VIP's";
$SETUP_FORUM       	= "Administrar Foros";
$SAVE_HINTS		= "guardar sugerencias";
$CREATE_CHANNEL		= "crear un nuevo canal";
$MODERATORS		= "Moderadores";
$GODFATHERS		= "Abuelos";
$MODERATOR		= "Moderador";
$COMODERATORS		= "Co-Moderadores";
$VIPS			= "VIP's";
$VIP			= "VIP";
$ADD_REMOVE		= "agregar/eliminar";
$SAVE			= "grabar";
$CLEAR_LINES		= "limpiar el texto del canal";
$CHAT_OVERLOAD		= "Lo siento, la sala de chat esta muy ocupada.";
$REPEAT_LOGIN		= "Intente ingresar otra vez!";
$FEHLER			= "Error";
$ERRORMAIL_SUBJECT 		= 'Error al conectar a la base de datos';
$ERRORMAIL_BODY    		= "the chat was unable to connect to the database.\nif the chat was running ago or is under high load, it seems that he is on his edge with load. try to upgrade something ;-)\n\n if this is a new installtion, you probably have something wrong in the default_inc.php. test if databasehost, databaseuser and datanasepassword are correct and without spaces. test if the database is corerct installed. if you tried to install it via phpMyAdmin, it may has failed. ";
$BEGIN			= 'Volver al inicio';
$ANSWER			= 'Respuesta';
$DELETE			= 'Borrar';
$WROTE    		= 'Escribi�';

$TBL_FIELDS["Id"]	= "";
$TBL_FIELDS["Name"]	= "Nombre del canal";
$TBL_FIELDS["PASSWORD"]	= "Clave";
$TBL_FIELDS["These"]	= "Este";
$TBL_FIELDS["Teilnehmerzahl"]="Numero maximo de usuarios<BR>0=sin limite";
$TBL_FIELDS["BG_Color"]	= "color of de fondo del texto";
$TBL_FIELDS["Logo"]	= "camino al archivo de la imagen file en la pagina de textos";
$TBL_FIELDS["ExitURL"]	= "URL de salida";
$TBL_FIELDS["moderiert"]= "moderado?<BR>[1=si/0=no]";
$TBL_FIELDS["starts_at"]= "el canal se inicia";
$TBL_FIELDS["stops_at"]	= "el canal termina";
$TBL_FIELDS["NICK_COLOR"]="Color del alias";

/*
 * login and registration messages
 */
$message[session_name]="No se puede registrar la sesion.";
$message[error_1]="Este alias ya se encuentra registrado o esta en linea.<BR>Sugerencia: Ingrese la clave solo una vez!";
$message[error_default]="Participation is not possible";
$message[error_2]="Participacion denegada! Clave incorrecta.";
$message[error_3]="Las claves no coinciden. Por favor intente otra vez!";
$message[error_4]="Dos posibilidades solamente! Ingrese una clave o una direccion E-Mail!";
$message[error_5]="Palabras invalidas encontradas en su alias!";
$message[error_6]="Expresion invalida encontrada en su alias!";
$message[error_7]="Lo siento, se alcanzo el numero maximo de usuarios permitidos!<BR>Intentelo mas tarde.";
$message[error_8]="Un color incorrecto se ha detectado.";
$message['error_9'] = 'Nickname has not been activated yet';
$REGISTER_NICK = 'Me quiero registrar!';
$REGISTER_TITLE = 'Inscripcion';
$REGISTER_SUBMIT = 'Registrar';
$REGISTER_SUCCESS_1 = 'Registrado!<br> Registrado en nuestra';
$REGISTER_SUCCESS_2 = ' pagina</a> now.';

/*
 * Forum-Messages
 */
$FORUM[title]		  = "Pizarron";
$FORUM[save_message]	  = "Felicitaciones! Su articulo esta en linea.";
$FORUM[save_message_empty]= "Su articulo esta vacio, no puede ser almacenado.";
$FORUM[save_nickname]	  = "Alias: ";
$FORUM[save_email]	  = "E-mail:";
$FORUM[save_homepage]	  = "Pagina de inicio:";
$FORUM[save_comment]	  = "Comentario:";
$FORUM[save_topic]	  = "al tema ";
$FORUM[our_topics]	  = "Nuestros temas";
$FORUM[save_next]	  = "proximo ";
$FORUM[save_read]	  = "Deseo leer!";
$FORUM[write]		  = "Escriba un articulo";
$FORUM[write_header]	  = "Ahora, puede escribir un nuevo articulo.";
$FORUM[write_topic]	  = "Su tema: ";
$FORUM[write_comment]	  = "Su comentario:";
$FORUM[write_submit]	  = "enviar";
$FORUM[no_frame]	  = "Lo siento, su navegador no soporta frames.";
$FORUM[back_to]		  = "volver a";
$FORUM[article_list]	  = "Lista de todos los articulos";
$FORUM[left_theme]	  = "Tema";
$FORUM[left_refresh]	  = "refrescar";
$FORUM[welcome]	  	  = "	<H3>Click en los temas de la izquierda para obtener la lista de articulos.<BR>Para leer un articulo click en un alias.</H3>				Los articulos mas nuevos estan arriba.<BR>				Que los disfrute!";
$FORUM[wrote]		  = "escribio";
$FORUM[meeting]		  = "Conociendo";
$FORUM[technology]	  = "Tecnologia";
$FORUM[babble_topic]	  = "Tema de charla";
$FORUM[newbees]		  = "Novatos";
$FORUM[all_themes]    = " Lista de temas";
$FORUM[subject]    = "Asunto";

// confirmation page
$CONFIRMATION_TITLE = 'Finish Registration';
$CONFIRMATION_OK_1 = 'Welcome! You are now a member of our online community.<br>Click here';
$CONFIRMATION_OK_2 = 'to login!</a><br>Have fun!';
$CONFIRMATION_FAILED = 'We are sorry, but your nickname could not be activated. Please try again!';

// Operator-Interface
$MSG_OP_TITLE = 'Operator-Function';
$MSG_OP_DESCRIPTION = 'Select a chatter to kick :';
$MSG_OP_INFO = '<b><u>Information :</u></b>';
$MSG_OP_KICKBUTTON = 'kick';
$MSG_OP_INFOBUTTON = 'Info';
$MSG_OP_PERMANENT = 'Kick chatter permanetly';

$MSG_OP_INFOTEXT_GENERAL  = 'Operators cannot be kicked. Therefore, they are not listed here. !';

$MSG_OP_INFOTEXT_INFOABOUT  = "Information about ";
$MSG_OP_INFOTEXT_KICKSSOFAR .= "Kicks so far :";
$MSG_OP_INFOTEXT_KICKCOUNT .= "Kick count :";
$MSG_OP_INFOTEXT_KICKTIME ="New locktime (minutes) :";
$MSG_OP_INFOTEXT_NEXTKICKTIME ="Locktime at next kick (minutes) :";
$MSG_OP_INFOTEXT_KICKED = "has been kicked out of the chat !";
$MSG_OP_INFOTEXT_ALREADYKICKED = "Has already been kicked out of the chat by another operator. !";


//USERPAGE   
$UP_FROM = 'Userpage from';   
$UP_UNKNOWN_USER = 'Don&acute;t know this user';   
$UP_TOPLISTPLACE = 'Toplistplace';   
$UP_SEX = 'Sex';   
$UP_INFO = 'Info about me';   
$UP_HOBBY = 'My hobbies';   
$UP_BIRTHDATE = 'Birthdate';   
$UP_AGE = 'Agfe';   
$UP_HOME = 'Home';   
$UP_FRIENDS = 'My friends at';   
$UP_GB_ERROR = 'You have  to fill in a text at least';   
$UP_GB_SAVED = 'Your guestbookentry was saved';   
$UP_GB_BACK = 'Back to guestbook';   
$UP_GB_SIGNHERE = 'Here you can sign gin into the guestbook';   
$UP_GB_NOTLOGGEDIN = 'To sign into the guestbook you have to login into the chat';   
$UP_GB_MSGCOUNT = 'Count of entries';   
$UP_GB_MOVE = 'Browse the guestbook';   
$UP_GB_WROTE = 'wrote at';   
$UP_GB_CONFIRM_DELETE = 'Shure to delete?';   
$UP_GB_ENTRY ='Sign into the Guestbook';   
$UP_GB_COMMENT = 'Comment';   
$UP_GB_DOIT = 'Save';   
$UP_GB_DELETE = 'delete'; 

//main menu
$MAIN_INFO_REGISTER = 'Register your nickname.';
$MAIN_INFO_PROFILE = 'Modify personal data and create your userpage.';
$MAIN_INFO_CHATMAIL = 'Send and receive mail messages within the chat.';
$MAIN_INFO_INVITE = 'Invite chatters into your own channel or ignore them.';
$MAIN_INFO_FRIENDS = 'Add a chatter to your friends.';
$MAIN_INFO_TOPLIST = 'List of all the chatters that have been here the most und longest.';
$MAIN_INFO_CLICK_UP = 'Click on a nickname to see the chatter\'s userpage.';
$MAIN_INFO_FORUM = 'Here you can communicate with other chatters about specific topics.';
$MAIN_INFO_HELP = 'Here you can find some help for all the chat\'s funtions.';
$MAIN_INFO_FORGOTPWD = 'Have your password sent to you by email.';
?>
