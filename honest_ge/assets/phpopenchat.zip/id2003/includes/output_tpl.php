<?//don't add </body> </html> tags!
echo $html_head?>
<BODY 	bgcolor="<?echo $chanbgcolor?>" 
	text="#66B886" 
	link="<?echo $channickcolor?>" 
	vlink="<?echo $channickcolor?>" 
	leftmargin="3" 
	topmargin="0" 
	marginheight="0" 
	marginwidth="0"
>
