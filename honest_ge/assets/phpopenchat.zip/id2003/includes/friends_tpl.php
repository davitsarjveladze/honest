<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<html>
<head>
<title><?echo$NOTIFY?></title>
<script language="JavaScript" type="text/javascript">
<!--
function OpenUserpage(file) {
  var newWindow;
  newWindow=window.open(file,"userpage","scrollbars=yes,directories=no,width=640,height=480")
  if (newWindow != null && newWindow.opener == null)
    newWindow.opener=window
}
// -->
</script>
<style type="text/css">
<!--
td { font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
-->
</style>
</head>
<body bgcolor="#F4F4F4" TEXT="#000000" LINK="#007b39" VLINK="#007b39" ALINK="#007b39" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="700" height="100%" align="center" cellspacing="0" cellpadding="5" border="0">
  <tr>
    <td align="center" valign="top">	
      <BR>
      <FORM ACTION="friends.<?echo$FILE_EXTENSION?>" METHOD="POST">
	<?echo $search_for_chatter?>
	<?echo $show_search_result?>
	<?echo $add_button?>
      </FORM>
      <?echo$select_of_friends?>
    </td>
  </tr>
</table>
</body>
</html>