<!-- don't add HTML tags like <HTML>, <BODY>, <HEAD>, ... -->
<P style="margin-left: 100px; font-size: 14px;">
  <!-- <?echo $CHANNEL_EXPIRED?><BR> -->
</P>
<P style="margin-top:250px; margin-left: 100px; font-size: 22px; font-face: arial,helvetica;">
  <?echo $CHANNEL_STARTS_AT?>
</P>
<P style="margin-left: 200px; font-size: 32px; font-face: arial,helvetica;">
	<?echo date("j.n.Y H:i",$start)?>h
</P>
<!-- don't add HTML tags like </HTML>, </BODY>, ... -->
