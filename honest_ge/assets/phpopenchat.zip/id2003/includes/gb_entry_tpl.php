<font style="font-size: 12pt;"><b><?=$UP_GB_ENTRY?></b></font>
<BR>
<form action="userpage.php" method="post">
  <input type="hidden" name="action" value="gb_save">
  <input type="hidden" name="user" value="<?echo $user?>">
  <TABLE CELLSPACING=2 CELLPADDING=2 BORDER=0 WIDTH=620>
    <TR>
      <TD VALIGN="top" ALIGN="right" CLASS="text"><?=$UP_GB_COMMENT?>:</TD>
      <TD VALIGN="top" ALIGN="left"><TEXTAREA NAME="text" ROWS=10 COLS=50 WRAP="virtual"></TEXTAREA></TD>
    </TR>
    <TR>
      <TD>&nbsp;</TD>
      <TD VALIGN="top" ALIGN="left"><INPUT TYPE="submit" VALUE="<?=$UP_GB_DOIT?>"></TD>
    </TR>
  </TABLE>
</FORM>
