<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<html>
<head>
<title><?=$MSG_IGNORE?></title>
</head>
<body bgcolor="#F4F4F4" TEXT="#000000" LINK="#007b39" VLINK="#007b39" ALINK="#007b39" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="700" height="100%" align="center" cellspacing="0" cellpadding="5" border="0">
  <tr>
    <td align="center" valign="top">
      <font face="arial,helvetica,sans-serif" size="2">[ <A HREF="invite.<?echo $FILE_EXTENSION.'?nick='.urlencode($nick).'&pruef='.$pruef.'&'.session_name().'='.session_id();?>"><b><?echo $MSG_INVITE?></b></a> | <A HREF="ignore.<?echo $FILE_EXTENSION.'?nick='.urlencode($nick).'&pruef='.$pruef.'&'.session_name().'='.session_id();?>"><b><?echo $MSG_IGNORE?></b></a> ]</font>
      <HR>
      <font face="arial,helvetica,sans-serif" size="2" color="#ff0000"><?echo$paten_msg?></font>
      <font face="arial,helvetica,sans-serif" size="2" color="#ff0000"><?echo$ignore_hint?></font>
      <FORM ACTION="<?echo'ignore.'.$FILE_EXTENSION?>" METHOD="POST">
	<TABLE ALIGN="CENTER" BORDER="0">
	  <TR>
	    <TD ALIGN="CENTER">
	      <font face="arial,helvetica,sans-serif" size="2"><?echo$MSG_IGNORE_LIST?></font>
	    </TD>
	    <TD WIDTH="50"></TD>
	    <TD ALIGN="CENTER">
	      <font face="arial,helvetica,sans-serif" size="2"><?echo$ALL_CHATTER?></font>
	    </TD>
	  </TR>
	  <TR>
	    <TD ALIGN="CENTER">
	      <?echo$permissions?>
	      <?echo$select_of_ignored_chatter?>
	    </TD>
	    <TD ALIGN="CENTER" VALIGN="MIDDLE">
	      <INPUT NAME="add" TYPE="submit" VALUE="� --">
	      <BR>
	      <INPUT NAME="del" TYPE="submit" VALUE="-- �">
	    </TD>
	    <TD ALIGN="CENTER">
	      <?echo$select_of_all_chatters?>
	    </TD>
	  </TR>
	</TABLE>
      </FORM>
    </TD>
  </TR>
  <tr>
    <td align="center" valign="bottom">
      <HR>
      <font face="arial,helvetica,sans-serif" size="2">[ <A HREF="invite.<?echo $FILE_EXTENSION.'?nick='.urlencode($nick).'&pruef='.$pruef.'&'.session_name().'='.session_id();?>"><b><?echo $MSG_INVITE?></b></a> | <A HREF="ignore.<?echo $FILE_EXTENSION.'?nick='.urlencode($nick).'&pruef='.$pruef.'&'.session_name().'='.session_id();?>"><b><?echo $MSG_IGNORE?></b></a> ]</font>
    </td>
  </tr>
</table>
</body>
</html>

